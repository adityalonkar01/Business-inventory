
from services.product_service import get_all_products, update_product


def main():
    """Manually update an active product using console prompts."""

    products = get_all_products()
    if not products:
        print("No products available to update.")
        return

    print("Available Products:")
    print("-" * 50)
    for product in products:
        print(
            f"ID: {product[0]} | "
            f"Name: {product[1]} | "
            f"SKU: {product[2]}"
        )

    try:
        product_id = int(input("\nEnter the product ID to update: "))
    except ValueError:
        print("Please enter a valid numeric product ID.")
        return

    selected_product = next(
        (product for product in products if product[0] == product_id),
        None
    )
    if selected_product is None:
        print("Product not found.")
        return

    print("\nEnter the updated product details.")
    product_name = input(
        f"Product name [{selected_product[1]}]: "
    ).strip() or selected_product[1]
    sku = input(
        f"SKU [{selected_product[2]}]: "
    ).strip() or selected_product[2]
    category = input(
        f"Category [{selected_product[3]}]: "
    ).strip() or selected_product[3]

    try:
        purchase_input = input(
            f"Purchase price [{selected_product[4]}]: "
        ).strip()
        selling_input = input(
            f"Selling price [{selected_product[5]}]: "
        ).strip()
        stock_input = input(
            f"Stock quantity [{selected_product[6]}]: "
        ).strip()
        minimum_input = input(
            f"Minimum stock [{selected_product[7]}]: "
        ).strip()

        purchase_price = float(purchase_input) if purchase_input else selected_product[4]
        selling_price = float(selling_input) if selling_input else selected_product[5]
        stock_quantity = int(stock_input) if stock_input else selected_product[6]
        minimum_stock = int(minimum_input) if minimum_input else selected_product[7]
    except ValueError:
        print("Invalid numeric input. Please try again.")
        return

    success, message = update_product(
        product_id,
        product_name,
        sku,
        category,
        purchase_price,
        selling_price,
        stock_quantity,
        minimum_stock
    )
    print("\nSuccess:", success)
    print("Message:", message)


if __name__ == "__main__":
    main()
