import csv
from datetime import date
import sqlite3
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from services import (
    category_service,
    dashboard_service,
    purchase_service,
    report_service,
    sales_service,
    settings_service,
    supplier_service,
    user_service,
)
from services.auth_service import verify_password
from database.admin_schema import ensure_admin_schema
from database.inventory_schema import ensure_inventory_movement_table
from database.sales_schema import ensure_sales_schema


class AdminModuleTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.database_path = Path(self.temporary.name) / "admin_modules.db"
        connection = sqlite3.connect(self.database_path)
        connection.execute("PRAGMA foreign_keys = ON")
        connection.executescript("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('admin', 'manager', 'salesperson')),
                is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_name TEXT NOT NULL,
                sku TEXT NOT NULL UNIQUE,
                category TEXT NOT NULL,
                purchase_price REAL NOT NULL DEFAULT 0,
                selling_price REAL NOT NULL DEFAULT 0,
                stock_quantity INTEGER NOT NULL DEFAULT 0,
                minimum_stock INTEGER NOT NULL DEFAULT 5,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_number TEXT NOT NULL UNIQUE,
                total_amount REAL NOT NULL DEFAULT 0,
                sold_by INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sold_by) REFERENCES users(id)
            );
            CREATE TABLE sale_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                sku TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK (quantity > 0),
                unit_price REAL NOT NULL CHECK (unit_price >= 0),
                line_total REAL NOT NULL CHECK (line_total >= 0),
                FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
            );
            INSERT INTO users (id, username, password_hash, role) VALUES
                (1, 'admin', 'salt$hash', 'admin'),
                (2, 'manager', 'salt$hash', 'manager'),
                (3, 'seller', 'salt$hash', 'salesperson');
            INSERT INTO products (
                id, product_name, sku, category, purchase_price, selling_price,
                stock_quantity, minimum_stock
            ) VALUES (1, 'Trail Lamp', 'TL-01', 'Outdoor', 8, 20, 5, 2);
            INSERT INTO products (
                id, product_name, sku, category, purchase_price, selling_price,
                stock_quantity, minimum_stock
            ) VALUES (2, 'Camp Stove', 'CS-02', 'Outdoor', 12, 25, 1, 5);
        """)
        connection.commit()
        ensure_sales_schema(connection)
        connection.commit()
        connection.close()

        self.admin = {"id": 1, "username": "admin", "role": "admin"}
        self.manager = {"id": 2, "username": "manager", "role": "manager"}
        self.seller = {"id": 3, "username": "seller", "role": "salesperson"}
        self.stack = ExitStack()
        for module in (
            category_service,
            dashboard_service,
            purchase_service,
            report_service,
            sales_service,
            settings_service,
            supplier_service,
            user_service,
        ):
            self.stack.enter_context(patch.object(
                module,
                "get_connection",
                side_effect=self._connect
            ))

    def tearDown(self):
        self.stack.close()
        self.temporary.cleanup()

    def _connect(self):
        connection = sqlite3.connect(self.database_path)
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def query(self, sql, parameters=()):
        connection = self._connect()
        try:
            return connection.execute(sql, parameters).fetchall()
        finally:
            connection.close()

    def test_user_management_uses_existing_password_hashing_and_guards_last_admin(self):
        success, message = user_service.create_user(
            self.admin, "new.manager", "long-password", "manager"
        )
        self.assertTrue(success, message)
        password_hash = self.query(
            "SELECT password_hash FROM users WHERE username = ?",
            ("new.manager",)
        )[0][0]
        self.assertTrue(verify_password("long-password", password_hash))
        self.assertFalse(verify_password("wrong-password", password_hash))
        self.assertFalse(user_service.create_user(
            self.manager, "unauthorized", "long-password", "admin"
        )[0])
        self.assertFalse(user_service.set_user_active(self.admin, 1, False)[0])
        self.assertFalse(user_service.update_user(self.admin, 1, "admin", "manager")[0])

    def test_category_migration_rename_and_product_protection(self):
        categories = category_service.list_categories(self.admin)
        self.assertEqual([row[1] for row in categories], ["Outdoor"])
        category_id = categories[0][0]
        self.assertFalse(category_service.deactivate_category(self.admin, category_id)[0])
        success, message = category_service.rename_category(
            self.admin, category_id, "Camping"
        )
        self.assertTrue(success, message)
        self.assertEqual(self.query(
            "SELECT category FROM products WHERE id = 1"
        ), [("Camping",)])
        self.assertFalse(category_service.create_category(self.manager, "Other")[0])

    def test_supplier_purchase_receipt_is_atomic_and_cannot_be_repeated(self):
        success, message = supplier_service.save_supplier(
            self.admin,
            {"name": "North Supply", "email": "orders@example.test"}
        )
        self.assertTrue(success, message)
        supplier_id = self.query(
            "SELECT id FROM suppliers WHERE name = 'North Supply'"
        )[0][0]
        success, message, purchase_id = purchase_service.create_purchase(
            self.manager, "PO-001", supplier_id,
            [{"product_id": 1, "quantity": 4, "unit_cost": 9.25}]
        )
        self.assertTrue(success, message)
        self.assertEqual(
            self.query("SELECT stock_quantity FROM products WHERE id = 1")[0][0],
            5
        )
        success, message = purchase_service.receive_purchase(self.manager, purchase_id)
        self.assertTrue(success, message)
        self.assertEqual(
            self.query("SELECT stock_quantity FROM products WHERE id = 1")[0][0],
            9
        )
        self.assertEqual(self.query("""
            SELECT movement_type, quantity, previous_stock, new_stock, performed_by
            FROM inventory_movements
        """), [("receipt", 4, 5, 9, 2)])
        self.assertFalse(purchase_service.receive_purchase(self.manager, purchase_id)[0])
        self.assertFalse(purchase_service.create_purchase(
            self.admin, "PO-001", supplier_id,
            [{"product_id": 1, "quantity": 1, "unit_cost": 1}]
        )[0])
        self.assertEqual(
            self.query("SELECT stock_quantity FROM products WHERE id = 1")[0][0],
            9
        )

    def test_purchase_receipt_rolls_back_stock_when_movement_insert_fails(self):
        supplier_service.save_supplier(self.admin, {"name": "Supplier"})
        supplier_id = self.query(
            "SELECT id FROM suppliers WHERE name = 'Supplier'"
        )[0][0]
        success, message, purchase_id = purchase_service.create_purchase(
            self.admin, "PO-ROLLBACK", supplier_id,
            [{"product_id": 1, "quantity": 3, "unit_cost": 8}]
        )
        self.assertTrue(success, message)
        connection = self._connect()
        connection.execute("""
            CREATE TRIGGER reject_receipt BEFORE INSERT ON inventory_movements
            BEGIN SELECT RAISE(ABORT, 'forced receipt failure'); END
        """)
        connection.commit()
        connection.close()
        success, message = purchase_service.receive_purchase(self.admin, purchase_id)
        self.assertFalse(success)
        self.assertIn("forced receipt failure", message)
        self.assertEqual(
            self.query("SELECT stock_quantity FROM products WHERE id = 1")[0][0],
            5
        )
        self.assertEqual(
            self.query("SELECT status FROM purchases WHERE id = ?", (purchase_id,))[0][0],
            "draft"
        )

    def test_purchase_rejects_invalid_items_and_salesperson_access(self):
        supplier_service.save_supplier(self.admin, {"name": "Supplier"})
        supplier_id = self.query(
            "SELECT id FROM suppliers WHERE name = 'Supplier'"
        )[0][0]
        for item in (
            {"product_id": -1, "quantity": 1, "unit_cost": 2},
            {"product_id": 1, "quantity": 0, "unit_cost": 2},
            {"product_id": 1, "quantity": 1, "unit_cost": -2},
        ):
            self.assertFalse(purchase_service.create_purchase(
                self.admin, "INVALID", supplier_id, [item]
            )[0])
        self.assertFalse(purchase_service.create_purchase(
            self.seller, "FORBIDDEN", supplier_id,
            [{"product_id": 1, "quantity": 1, "unit_cost": 2}]
        )[0])
        self.assertEqual(self.query("SELECT COUNT(*) FROM purchases")[0][0], 0)

    def test_settings_validate_and_persist(self):
        success, message = settings_service.update_settings(
            self.admin,
            {
                "business_name": "Northwind Store",
                "currency_symbol": "$",
                "default_gst_percent": "12.5",
                "invoice_prefix": "NW",
                "minimum_stock_default": "7",
            }
        )
        self.assertTrue(success, message)
        settings = settings_service.get_admin_settings(self.admin)
        self.assertEqual(settings["business_name"], "Northwind Store")
        self.assertEqual(settings["currency_symbol"], "$")
        self.assertEqual(settings["default_gst_percent"], 12.5)
        self.assertEqual(settings["minimum_stock_default"], 7)
        self.assertFalse(settings_service.update_settings(
            self.admin, {"minimum_stock_default": "1.5"}
        )[0])
        self.assertFalse(settings_service.update_settings(
            self.manager, {"business_name": "Not authorized"}
        )[0])

    def test_invoice_prefix_and_business_settings_are_snapshotted(self):
        success, message = settings_service.update_settings(
            self.admin,
            {
                "business_name": "Northwind Store",
                "currency_symbol": "$",
                "invoice_prefix": "NW",
                "default_gst_percent": "7.5",
            }
        )
        self.assertTrue(success, message)
        success, message, invoice = sales_service.create_sale(
            self.admin, [{"product_id": 1, "quantity": 1}]
        )
        self.assertTrue(success, message)
        self.assertTrue(invoice.startswith("NW"))
        saved_invoice = sales_service.get_sale_details(self.admin, invoice)
        self.assertEqual(saved_invoice["business_name"], "Northwind Store")
        self.assertEqual(saved_invoice["currency_symbol"], "$")
        self.assertIn("$20.00", sales_service.render_invoice_html(saved_invoice))
        self.assertFalse(settings_service.update_settings(
            self.admin, {"currency_symbol": "€"}
        )[0])
        success, message = settings_service.update_settings(
            self.admin, {"business_name": "Updated Store"}
        )
        self.assertTrue(success, message)
        saved_invoice = sales_service.get_sale_details(self.admin, invoice)
        self.assertEqual(saved_invoice["business_name"], "Northwind Store")
        self.assertEqual(saved_invoice["currency_symbol"], "$")

    def test_reports_date_range_csv_export_and_role_enforcement(self):
        ensure_settings = settings_service.get_public_settings()
        self.assertEqual(ensure_settings["invoice_prefix"], "INV-")
        current_date = date.today().isoformat()
        connection = self._connect()
        connection.execute("""
            INSERT INTO sales (invoice_number, subtotal, total_amount, sold_by, created_at)
            VALUES ('RPT-001', 40, 42, 3, ?)
        """, (f"{current_date} 12:00:00",))
        sale_id = connection.execute(
            "SELECT id FROM sales WHERE invoice_number = 'RPT-001'"
        ).fetchone()[0]
        connection.execute("""
            INSERT INTO sale_items (
                sale_id, product_id, product_name, sku, quantity, unit_price, line_total
            ) VALUES (?, 1, 'Trail Lamp', 'TL-01', 2, 20, 40)
        """, (sale_id,))
        connection.commit()
        connection.close()
        report = report_service.get_reports(self.admin, current_date, current_date)
        self.assertEqual(report["sales_summary"]["invoice_count"], 1)
        self.assertEqual(report["sales_summary"]["total_amount"], 42)
        self.assertEqual(report["top_products"][0]["quantity_sold"], 2)
        self.assertEqual(
            [(item["sku"], item["stock_quantity"]) for item in report["low_stock"]],
            [("CS-02", 1)]
        )
        self.assertEqual(report["stock_valuation"]["cost_value"], 52)
        with tempfile.TemporaryDirectory() as temp_dir:
            destination = Path(temp_dir) / "daily.csv"
            count = report_service.export_report_csv(
                self.admin, "daily_sales", current_date, current_date, destination
            )
            self.assertEqual(count, 1)
            with destination.open(encoding="utf-8-sig", newline="") as file:
                self.assertEqual(list(csv.DictReader(file))[0]["invoice_count"], "1")
            manager_report = report_service.get_reports(
                self.manager, current_date, current_date
            )
            self.assertEqual(manager_report["sales_summary"]["invoice_count"], 1)
            with tempfile.TemporaryDirectory() as temp_dir:
                destination = Path(temp_dir) / "manager-daily.csv"
                count = report_service.export_report_csv(
                    self.manager, "daily_sales", current_date, current_date, destination
                )
                self.assertEqual(count, 1)
            with self.assertRaises(PermissionError):
                report_service.get_reports(self.seller, current_date, current_date)
            with self.assertRaises(ValueError):
                report_service.get_reports(self.admin, "2025-01-05", "2025-01-01")

    def test_dashboard_statistics_are_database_backed_and_admin_restricted(self):
        connection = self._connect()
        ensure_admin_schema(connection)
        ensure_inventory_movement_table(connection)
        supplier_id = connection.execute(
            "INSERT INTO suppliers (name) VALUES ('North Supply')"
        ).lastrowid
        connection.execute("""
            INSERT INTO purchases (
                purchase_ref, supplier_id, total_amount, created_by
            ) VALUES ('PO-DASH-001', ?, 15, 2)
        """, (supplier_id,))
        connection.execute("""
            INSERT INTO inventory_movements (
                product_id, movement_type, quantity, previous_stock,
                new_stock, performed_by
            ) VALUES (1, 'receipt', 1, 4, 5, 2)
        """)
        connection.execute("""
            INSERT INTO sales (invoice_number, total_amount, sold_by, created_at)
            VALUES ('TODAY-001', 32, 3, datetime('now', 'localtime'))
        """)
        connection.commit()
        connection.close()
        statistics = dashboard_service.get_admin_statistics(self.admin)
        self.assertEqual(statistics["total_products"], 2)
        self.assertEqual(statistics["total_stock"], 6)
        self.assertEqual(statistics["low_stock_items"], 1)
        self.assertEqual(statistics["today_invoice_count"], 1)
        self.assertEqual(statistics["today_sales"], 32)
        with self.assertRaises(PermissionError):
            dashboard_service.get_admin_statistics(self.manager)

        manager_statistics = dashboard_service.get_manager_statistics(self.manager)
        self.assertEqual(manager_statistics["total_active_products"], 2)
        self.assertEqual(manager_statistics["total_stock_quantity"], 6)
        self.assertEqual(manager_statistics["low_stock_product_count"], 1)
        self.assertEqual(manager_statistics["inventory_valuation"], 52)
        self.assertEqual(manager_statistics["today_sales"], 32)
        self.assertEqual(manager_statistics["monthly_sales"], 32)
        self.assertEqual(manager_statistics["recent_transaction_count"], 1)
        self.assertEqual(
            manager_statistics["recent_purchases"][0][:4],
            ("PO-DASH-001", "North Supply", "draft", 15),
        )
        self.assertEqual(
            manager_statistics["recent_stock_movements"][0][:7],
            ("Trail Lamp", "TL-01", "receipt", 1, 4, 5, "manager"),
        )
        self.assertEqual(len(manager_statistics["low_stock_alerts"]), 1)
        self.assertEqual(manager_statistics["currency_symbol"], "₹")

    def test_manager_can_change_only_their_own_password(self):
        success, message = user_service.create_user(
            self.admin, "password.manager", "old-password", "manager"
        )
        self.assertTrue(success, message)
        user_id = self.query(
            "SELECT id FROM users WHERE username = ?", ("password.manager",)
        )[0][0]
        manager = {
            "id": user_id,
            "username": "password.manager",
            "role": "manager",
        }

        success, message = user_service.change_own_password(
            manager, "old-password", "new-password", "new-password"
        )
        self.assertTrue(success, message)
        password_hash = self.query(
            "SELECT password_hash FROM users WHERE id = ?", (user_id,)
        )[0][0]
        self.assertTrue(verify_password("new-password", password_hash))
        self.assertFalse(verify_password("old-password", password_hash))
        self.assertFalse(user_service.change_own_password(
            manager, "wrong-password", "next-password", "next-password"
        )[0])
        self.assertFalse(user_service.change_own_password(
            self.manager, "old-password", "other-password", "other-password"
        )[0])

    def test_salesperson_can_change_only_their_own_password(self):
        success, message = user_service.create_user(
            self.admin, "password.seller", "old-password", "salesperson"
        )
        self.assertTrue(success, message)
        user_id = self.query(
            "SELECT id FROM users WHERE username = ?", ("password.seller",)
        )[0][0]
        salesperson = {
            "id": user_id,
            "username": "password.seller",
            "role": "salesperson",
        }

        success, message = user_service.change_own_password(
            salesperson, "old-password", "new-password", "new-password"
        )
        self.assertTrue(success, message)
        password_hash = self.query(
            "SELECT password_hash FROM users WHERE id = ?", (user_id,)
        )[0][0]
        self.assertTrue(verify_password("new-password", password_hash))
        self.assertFalse(user_service.change_own_password(
            salesperson, "wrong-password", "next-password", "next-password"
        )[0])
        self.assertFalse(user_service.change_own_password(
            salesperson, "new-password", "mismatch-password", "different-password"
        )[0])


if __name__ == "__main__":
    unittest.main()
