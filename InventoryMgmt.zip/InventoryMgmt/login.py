# Import CustomTkinter for building a modern desktop interface.
import customtkinter as ctk

# Import the authentication function.
from services.auth_service import authenticate_user

# Import the temporary dashboard.
from dashboard import Dashboard
from dashboards.admin_dashboard import AdminDashboard
from dashboards.manager_dashboard import ManagerDashboard
from dashboards.salesperson_dashboard import SalespersonDashboard

# Configure the appearance of our application.
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


class LoginApp(ctk.CTk):
    """
    Main login window of our Inventory Management System.
    """

    def __init__(self):
        # Initialize the parent CTk window.
        super().__init__()

        # Configure the window title and dimensions.
        self.title("Inventory Management System - Login")
        self.geometry("900x550")

        # Prevent the window from becoming too small.
        self.minsize(750, 450)

        # Set the background color of the window.
        self.configure(fg_color="#F3F6FB")

        # Build the login interface.
        self.create_login_ui()

    def create_login_ui(self):
        """
        Create the login form and its visual components.
        """

        # Main container holds the two sides of the login window.
        main_frame = ctk.CTkFrame(
            self,
            corner_radius=20,
            fg_color="white"
        )

        # Center the main container inside the window.
        main_frame.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=30
        )

        # --------------------------------------------------
        # LEFT SIDE: Application introduction
        # --------------------------------------------------

        left_frame = ctk.CTkFrame(
            main_frame,
            corner_radius=15,
            fg_color="#1E3A5F",
            width=350
        )

        # Place the left panel inside the main container.
        left_frame.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(15, 8),
            pady=15
        )

        # Prevent the panel from shrinking below its requested width.
        left_frame.pack_propagate(False)

        # Application title.
        ctk.CTkLabel(
            left_frame,
            text="INVENTORY\nMANAGEMENT",
            font=("Segoe UI", 28, "bold"),
            text_color="white",
            justify="left"
        ).pack(
            anchor="w",
            padx=30,
            pady=(100, 15)
        )

        # Short application description.
        ctk.CTkLabel(
            left_frame,
            text=(
                "Manage products, track stock,\n"
                "record sales, and monitor\n"
                "business performance."
            ),
            font=("Segoe UI", 14),
            text_color="#D7E4F5",
            justify="left"
        ).pack(
            anchor="w",
            padx=30
        )

        # --------------------------------------------------
        # RIGHT SIDE: Login form
        # --------------------------------------------------

        right_frame = ctk.CTkFrame(
            main_frame,
            corner_radius=15,
            fg_color="white"
        )

        # Place the login form on the right.
        right_frame.pack(
            side="right",
            fill="both",
            expand=True,
            padx=(8, 15),
            pady=15
        )

        # Login heading.
        ctk.CTkLabel(
            right_frame,
            text="Welcome Back!",
            font=("Segoe UI", 26, "bold"),
            text_color="#1E293B"
        ).pack(
            anchor="w",
            padx=35,
            pady=(75, 5)
        )

        # Supporting text.
        ctk.CTkLabel(
            right_frame,
            text="Sign in to continue",
            font=("Segoe UI", 13),
            text_color="#64748B"
        ).pack(
            anchor="w",
            padx=35,
            pady=(0, 25)
        )

        # Username label.
        ctk.CTkLabel(
            right_frame,
            text="Username",
            font=("Segoe UI", 13, "bold"),
            text_color="#334155"
        ).pack(
            anchor="w",
            padx=35,
            pady=(0, 5)
        )

        # Input field where the user enters their username.
        self.username_entry = ctk.CTkEntry(
            right_frame,
            placeholder_text="Enter your username",
            height=42,
            corner_radius=8
        )

        self.username_entry.pack(
            fill="x",
            padx=35,
            pady=(0, 18)
        )

        # Password label.
        ctk.CTkLabel(
            right_frame,
            text="Password",
            font=("Segoe UI", 13, "bold"),
            text_color="#334155"
        ).pack(
            anchor="w",
            padx=35,
            pady=(0, 5)
        )

        # Input field where the user enters their password.
        # show="*" hides the password characters.
        self.password_entry = ctk.CTkEntry(
            right_frame,
            placeholder_text="Enter your password",
            show="*",
            height=42,
            corner_radius=8
        )

        self.password_entry.pack(
            fill="x",
            padx=35,
            pady=(0, 25)
        )

        # Login button.
        # Authentication will be implemented in a later step.
        ctk.CTkButton(
            right_frame,
            text="Sign In",
            height=44,
            corner_radius=8,
            font=("Segoe UI", 14, "bold"),
            command=self.login
        ).pack(
            fill="x",
            padx=35
        )

        # Label for displaying login errors or other messages.
        self.message_label = ctk.CTkLabel(
            right_frame,
            text="",
            font=("Segoe UI", 12),
            text_color="#DC2626"
        )

        self.message_label.pack(
            padx=35,
            pady=12
        )

    def login(self):
        """
        Authenticate the user and open the appropriate dashboard.
        """

        # Read the username and remove accidental surrounding spaces.
        username = self.username_entry.get().strip()

        # Read the password entered by the user.
        password = self.password_entry.get()

        # Check that neither field is empty.
        if not username or not password:
            self.message_label.configure(
                text="Please enter both username and password."
            )
            return

        # Verify the credentials against our SQLite database.
        user = authenticate_user(username, password)

        # If authentication fails, display an error.
        if user is None:
            self.message_label.configure(
                text="Invalid username or password."
            )
            return

        # Authentication succeeded.
        # Close the login window before opening the dashboard.
        self.destroy()

        # Create the dashboard using the authenticated user's details.
        if user["role"] == "admin":
            dashboard = AdminDashboard(user)
        elif user["role"] == "manager":
            dashboard = ManagerDashboard(user)
        elif user["role"] == "salesperson":
            dashboard = SalespersonDashboard(user)
        else:
            dashboard = Dashboard(user)

        # Start the dashboard's event loop.
        dashboard.mainloop()


# Run the application when this file is executed directly.
if __name__ == "__main__":
    app = LoginApp()

    # Keep the window open and respond to user interactions.
    app.mainloop()