# Import the authentication function we want to test.
from services.auth_service import authenticate_user

# Import getpass so the password isn't displayed while typing.
from getpass import getpass


def main():
    """Test authentication using an existing user account."""

    # Ask for the username.
    username = input("Enter username: ").strip()

    # Ask for the password without displaying it.
    password = getpass("Enter password: ")

    # Check the credentials against our SQLite database.
    user = authenticate_user(username, password)

    # Display the result without revealing the password.
    if user:
        print("\nLogin successful!")
        print("Username:", user["username"])
        print("Role:", user["role"])
    else:
        print("\nLogin failed. Check your credentials.")


# Run the test when this file is executed directly.
if __name__ == "__main__":
    main()