import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from services import inventory_service


class InventoryServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.database_path = Path(self.temp_directory.name) / "inventory_test.db"
        connection = sqlite3.connect(self.database_path)
        try:
            connection.executescript("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE,
                    role TEXT NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_name TEXT NOT NULL,
                    sku TEXT NOT NULL UNIQUE,
                    category TEXT NOT NULL,
                    purchase_price REAL NOT NULL DEFAULT 0,
                    selling_price REAL NOT NULL DEFAULT 0,
                    stock_quantity INTEGER NOT NULL DEFAULT 0,
                    minimum_stock INTEGER NOT NULL DEFAULT 5,
                    is_active INTEGER NOT NULL DEFAULT 1
                );
                INSERT INTO users (id, username, role) VALUES
                    (1, 'admin', 'admin'),
                    (2, 'manager', 'manager'),
                    (3, 'salesperson', 'salesperson');
                INSERT INTO products
                    (id, product_name, sku, category, stock_quantity, minimum_stock)
                VALUES
                    (1, 'Low Item', 'LOW-01', 'Test', 5, 5),
                    (2, 'Available Item', 'OK-02', 'Test', 12, 5),
                    (3, 'Inactive Item', 'OFF-03', 'Test', 0, 5);
                UPDATE products SET is_active = 0 WHERE id = 3;
            """)
        finally:
            connection.close()

        self.connection_patcher = patch.object(
            inventory_service,
            "get_connection",
            side_effect=lambda: sqlite3.connect(self.database_path)
        )
        self.connection_patcher.start()
        self.admin = {"id": 1, "username": "admin", "role": "admin"}
        self.manager = {"id": 2, "username": "manager", "role": "manager"}
        self.salesperson = {"id": 3, "username": "salesperson", "role": "salesperson"}

    def tearDown(self):
        self.connection_patcher.stop()
        self.temp_directory.cleanup()

    def stock(self, product_id):
        connection = sqlite3.connect(self.database_path)
        try:
            return connection.execute(
                "SELECT stock_quantity FROM products WHERE id = ?",
                (product_id,)
            ).fetchone()[0]
        finally:
            connection.close()

    def test_receive_and_adjust_stock_updates_quantity_and_history(self):
        success, message = inventory_service.receive_stock(
            1, 7, self.manager, "Supplier delivery"
        )
        self.assertTrue(success, message)
        self.assertEqual(self.stock(1), 12)

        success, message = inventory_service.adjust_stock(
            1, -4, self.manager, "Damaged goods"
        )
        self.assertTrue(success, message)
        self.assertEqual(self.stock(1), 8)

        success, message = inventory_service.adjust_stock(
            1, 2, self.admin, "Count correction"
        )
        self.assertTrue(success, message)
        self.assertEqual(self.stock(1), 10)

        history = inventory_service.get_stock_movement_history(self.admin, 1)
        self.assertEqual([item["movement_type"] for item in history], [
            "adjustment_in",
            "adjustment_out",
            "receipt"
        ])
        self.assertEqual(
            [(item["previous_stock"], item["new_stock"]) for item in history],
            [(8, 10), (12, 8), (5, 12)]
        )
        self.assertEqual(history[0]["performed_by_username"], "admin")
        self.assertEqual(history[2]["notes"], "Supplier delivery")

    def test_adjustment_cannot_make_stock_negative(self):
        success, message = inventory_service.adjust_stock(1, -6, self.manager)
        self.assertFalse(success)
        self.assertIn("negative", message)
        self.assertEqual(self.stock(1), 5)
        self.assertEqual(inventory_service.get_stock_movement_history(self.admin), [])

    def test_rejects_invalid_quantities_and_product_ids(self):
        for quantity in (0, -1, 1.5, True, "2", 1 << 64):
            with self.subTest(quantity=quantity):
                success, _message = inventory_service.receive_stock(
                    1, quantity, self.admin
                )
                self.assertFalse(success)

        for quantity in (0, 1.5, True, "2"):
            with self.subTest(adjustment=quantity):
                success, _message = inventory_service.adjust_stock(
                    1, quantity, self.admin
                )
                self.assertFalse(success)

        for product_id in (0, -2, 999, True, 1 << 64):
            with self.subTest(product_id=product_id):
                success, _message = inventory_service.receive_stock(
                    product_id, 1, self.admin
                )
                self.assertFalse(success)

        self.assertEqual(self.stock(1), 5)

    def test_summary_search_and_low_stock_use_active_products(self):
        summary = inventory_service.get_inventory_summary(self.manager)
        self.assertEqual(summary, {
            "total_products": 2,
            "total_stock": 17,
            "low_stock_products": 1
        })

        low_stock = inventory_service.get_low_stock_products(self.admin)
        self.assertEqual([product["sku"] for product in low_stock], ["LOW-01"])
        self.assertTrue(low_stock[0]["stock_quantity"] <= low_stock[0]["minimum_stock"])

        search_by_name = inventory_service.get_current_stock(self.manager, "available")
        search_by_sku = inventory_service.get_current_stock(self.manager, "OK-02")
        self.assertEqual([product["id"] for product in search_by_name], [2])
        self.assertEqual([product["id"] for product in search_by_sku], [2])

    def test_salesperson_can_read_but_cannot_change_stock(self):
        self.assertEqual(len(inventory_service.get_current_stock(self.salesperson)), 2)
        success, message = inventory_service.receive_stock(
            1, 1, self.salesperson
        )
        self.assertFalse(success)
        self.assertIn("not authorized", message)
        self.assertEqual(self.stock(1), 5)

    def test_invalid_or_mismatched_user_is_denied(self):
        success, message = inventory_service.adjust_stock(
            1, 1, {"id": 3, "username": "salesperson", "role": "manager"}
        )
        self.assertFalse(success)
        self.assertIn("no longer active or valid", message)

        with self.assertRaises(PermissionError):
            inventory_service.get_current_stock({"id": 999, "role": "admin"})

    def test_movement_insert_failure_rolls_back_stock_update(self):
        inventory_service.get_inventory_summary(self.admin)
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute("""
                CREATE TRIGGER reject_inventory_movement
                BEFORE INSERT ON inventory_movements
                BEGIN
                    SELECT RAISE(ABORT, 'forced movement insert failure');
                END
            """)
            connection.commit()
        finally:
            connection.close()

        success, message = inventory_service.receive_stock(1, 4, self.admin)
        self.assertFalse(success)
        self.assertIn("forced movement insert failure", message)
        self.assertEqual(self.stock(1), 5)

        connection = sqlite3.connect(self.database_path)
        try:
            count = connection.execute(
                "SELECT COUNT(*) FROM inventory_movements"
            ).fetchone()[0]
        finally:
            connection.close()
        self.assertEqual(count, 0)


if __name__ == "__main__":
    unittest.main()
