import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from services import product_service


class ProductServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.database_path = Path(self.temp_directory.name) / "test_inventory.db"
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE,
                    role TEXT NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1
                )
            """)
            connection.executemany(
                "INSERT INTO users (id, username, role) VALUES (?, ?, ?)",
                [(1, "admin", "admin"), (2, "manager", "manager"),
                 (3, "salesperson", "salesperson")]
            )
            connection.execute("""
                CREATE TABLE products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_name TEXT NOT NULL,
                    sku TEXT NOT NULL UNIQUE,
                    category TEXT NOT NULL,
                    purchase_price REAL NOT NULL DEFAULT 0,
                    selling_price REAL NOT NULL DEFAULT 0,
                    stock_quantity INTEGER NOT NULL DEFAULT 0,
                    minimum_stock INTEGER NOT NULL DEFAULT 5,
                    is_active INTEGER NOT NULL DEFAULT 1
                )
            """)
            connection.commit()
        finally:
            connection.close()

        self.connection_patcher = patch.object(
            product_service,
            "get_connection",
            side_effect=lambda: sqlite3.connect(self.database_path)
        )
        self.connection_patcher.start()
        self.manager = {"id": 2, "username": "manager", "role": "manager"}
        self.salesperson = {
            "id": 3, "username": "salesperson", "role": "salesperson"
        }

    def tearDown(self):
        self.connection_patcher.stop()
        self.temp_directory.cleanup()

    def test_add_search_update_and_deactivate_product(self):
        success, message = product_service.add_product(
            "  Trail Lamp  ",
            " tl-01 ",
            "Outdoor",
            12.5,
            24,
            10,
            3
        )
        self.assertTrue(success, message)

        product = product_service.get_all_products()[0]
        self.assertEqual(product[1], "Trail Lamp")
        self.assertEqual(product[2], "TL-01")
        self.assertEqual(len(product_service.search_products("lamp")), 1)
        self.assertEqual(len(product_service.search_products("tl-01")), 1)

        success, message = product_service.update_product(
            product[0],
            "Camp Lantern",
            "cl-02",
            "Lighting",
            15,
            32.5,
            7,
            2
        )
        self.assertTrue(success, message)
        updated_product = product_service.get_all_products()[0]
        self.assertEqual(updated_product[1:4], ("Camp Lantern", "CL-02", "Lighting"))
        self.assertEqual(updated_product[6:], (7, 2))

        success, message = product_service.delete_product(product[0])
        self.assertTrue(success, message)
        self.assertEqual(product_service.get_all_products(), [])
        connection = sqlite3.connect(self.database_path)
        try:
            active = connection.execute(
                "SELECT is_active FROM products WHERE id = ?",
                (product[0],)
            ).fetchone()[0]
        finally:
            connection.close()
        self.assertEqual(active, 0)

    def test_rejects_invalid_numbers_and_duplicate_skus(self):
        success, message = product_service.add_product(
            "Invalid",
            "INV-01",
            "Other",
            1,
            float("nan"),
            0,
            5
        )
        self.assertFalse(success)
        self.assertIn("finite numbers", message)

        success, message = product_service.add_product(
            "Fractional stock",
            "INV-02",
            "Other",
            1,
            2,
            1.5,
            5
        )
        self.assertFalse(success)
        self.assertIn("whole numbers", message)
        self.assertEqual(product_service.get_all_products(), [])

        success, message = product_service.add_product(
            "Valid",
            "INV-03",
            "Other",
            1,
            2,
            1,
            5
        )
        self.assertTrue(success, message)
        success, message = product_service.add_product(
            "Duplicate",
            " inv-03 ",
            "Other",
            1,
            2,
            1,
            5
        )
        self.assertFalse(success)
        self.assertEqual(message, "This SKU already exists.")

    def test_manager_product_view_is_searchable_and_read_only(self):
        product_service.add_product(
            "Trail Lamp", "TL-01", "Outdoor", 12.5, 24, 10, 3
        )
        products = product_service.get_manager_products(self.manager)
        self.assertEqual(len(products), 1)
        self.assertEqual(
            products[0][1:],
            ("Trail Lamp", "TL-01", "Outdoor", 12.5, 24.0, 10, 3)
        )
        self.assertEqual(
            len(product_service.get_manager_products(self.manager, "tl-01")), 1
        )
        self.assertEqual(
            product_service.get_manager_products(self.manager, "missing"), []
        )
        with self.assertRaises(PermissionError):
            product_service.get_manager_products(self.salesperson)
        with self.assertRaises(PermissionError):
            product_service.get_manager_products(
                {"id": 2, "username": "manager", "role": "admin"}
            )


if __name__ == "__main__":
    unittest.main()
