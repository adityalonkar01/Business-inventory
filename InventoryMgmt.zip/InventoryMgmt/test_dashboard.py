from getpass import getpass

from services.auth_service import authenticate_user
from services.dashboard_service import get_admin_statistics


def main():
    """Manually print current administrator dashboard statistics."""

    username = input("Administrator username: ").strip()
    password = getpass("Password: ")
    user = authenticate_user(username, password)
    if user is None or user["role"] != "admin":
        print("An active administrator account is required.")
        return

    statistics = get_admin_statistics(user)
    print("Admin Dashboard Statistics")
    print("--------------------------")
    print("Total Products:", statistics["total_products"])
    print("Total Stock Units:", statistics["total_stock"])
    print("Low Stock Items:", statistics["low_stock_items"])
    print("Total Sales: ₹", statistics["total_sales"])


if __name__ == "__main__":
    main()