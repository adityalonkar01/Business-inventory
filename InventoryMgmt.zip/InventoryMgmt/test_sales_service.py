import csv
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from services import sales_service


class SalesServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.database_path = Path(self.temp_directory.name) / "sales_test.db"
        connection = sqlite3.connect(self.database_path)
        try:
            connection.executescript("""
                PRAGMA foreign_keys = ON;
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE,
                    role TEXT NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_name TEXT NOT NULL,
                    sku TEXT NOT NULL UNIQUE,
                    category TEXT NOT NULL,
                    purchase_price REAL NOT NULL DEFAULT 0,
                    selling_price REAL NOT NULL DEFAULT 0,
                    stock_quantity INTEGER NOT NULL DEFAULT 0,
                    minimum_stock INTEGER NOT NULL DEFAULT 5,
                    is_active INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    invoice_number TEXT NOT NULL UNIQUE,
                    total_amount REAL NOT NULL DEFAULT 0,
                    sold_by INTEGER,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (sold_by) REFERENCES users(id)
                );
                CREATE TABLE sale_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sale_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    product_name TEXT NOT NULL,
                    sku TEXT NOT NULL,
                    quantity INTEGER NOT NULL CHECK (quantity > 0),
                    unit_price REAL NOT NULL CHECK (unit_price >= 0),
                    line_total REAL NOT NULL CHECK (line_total >= 0),
                    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
                    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
                );
                CREATE TABLE inventory_movements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    movement_type TEXT NOT NULL
                        CHECK (movement_type IN ('receipt', 'adjustment_in', 'adjustment_out')),
                    quantity INTEGER NOT NULL CHECK (quantity > 0),
                    previous_stock INTEGER NOT NULL CHECK (previous_stock >= 0),
                    new_stock INTEGER NOT NULL CHECK (new_stock >= 0),
                    notes TEXT NOT NULL DEFAULT '',
                    performed_by INTEGER NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CHECK (
                        (movement_type IN ('receipt', 'adjustment_in')
                            AND new_stock = previous_stock + quantity)
                        OR
                        (movement_type = 'adjustment_out'
                            AND new_stock = previous_stock - quantity)
                    ),
                    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
                    FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE RESTRICT
                );
                INSERT INTO users (id, username, role) VALUES
                    (1, 'admin', 'admin'),
                    (2, 'seller', 'salesperson'),
                    (3, 'other_seller', 'salesperson'),
                    (4, 'manager', 'manager');
                INSERT INTO products
                    (id, product_name, sku, category, selling_price, stock_quantity)
                VALUES
                    (1, 'Trail Lamp', 'TL-01', 'Outdoor', 10.00, 12),
                    (2, 'Camp Stove', 'CS-02', 'Outdoor', 25.50, 2);
                INSERT INTO sales (id, invoice_number, total_amount, sold_by)
                VALUES (1, 'LEGACY-INV-01', 8.5, 1);
                INSERT INTO sale_items (
                    id, sale_id, product_id, product_name, sku, quantity,
                    unit_price, line_total
                )
                VALUES (1, 1, 1, 'Trail Lamp', 'TL-01', 1, 8.5, 8.5);
                INSERT INTO inventory_movements (
                    id, product_id, movement_type, quantity, previous_stock,
                    new_stock, notes, performed_by
                )
                VALUES (1, 1, 'receipt', 2, 10, 12, 'Existing delivery', 1);
            """)
        finally:
            connection.close()

        self.connection_patcher = patch.object(
            sales_service,
            "get_connection",
            side_effect=lambda: sqlite3.connect(self.database_path)
        )
        self.connection_patcher.start()
        self.admin = {"id": 1, "username": "admin", "role": "admin"}
        self.seller = {"id": 2, "username": "seller", "role": "salesperson"}
        self.other_seller = {
            "id": 3,
            "username": "other_seller",
            "role": "salesperson"
        }
        self.manager = {"id": 4, "username": "manager", "role": "manager"}

    def tearDown(self):
        self.connection_patcher.stop()
        self.temp_directory.cleanup()

    def query(self, sql, parameters=()):
        connection = sqlite3.connect(self.database_path)
        try:
            return connection.execute(sql, parameters).fetchall()
        finally:
            connection.close()

    def test_successful_sale_calculates_tax_discount_and_records_stock_movement(self):
        success, message, invoice = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 2}],
            gst_percent=5,
            discount_percent=10
        )
        self.assertTrue(success, message)
        self.assertRegex(invoice, r"^INV-\d{8}-[A-F0-9]{32}$")
        self.assertEqual(self.query(
            "SELECT stock_quantity FROM products WHERE id = 1"
        )[0][0], 10)

        sale = sales_service.get_sale_details(self.seller, invoice)
        self.assertEqual(sale["subtotal"], 20)
        self.assertEqual(sale["discount_amount"], 2)
        self.assertAlmostEqual(sale["gst_amount"], 0.9)
        self.assertAlmostEqual(sale["total_amount"], 18.9)
        self.assertEqual(sale["items"], [{
            "product_id": 1,
            "product_name": "Trail Lamp",
            "sku": "TL-01",
            "quantity": 2,
            "unit_price": 10,
            "discount_amount": 2,
            "tax_rate": 5,
            "tax_amount": 0.9,
            "line_total": 18,
            "tax_rate_recorded": True
        }])
        self.assertEqual(self.query("""
            SELECT movement_type, quantity, previous_stock, new_stock, notes, performed_by
            FROM inventory_movements
            WHERE movement_type = 'sale'
        """), [("sale", 2, 12, 10, f"Invoice {invoice}", 2)])
        self.assertEqual(self.query("""
            SELECT tax_rate_recorded FROM sale_items
            WHERE sale_id = (SELECT id FROM sales WHERE invoice_number = ?)
        """, (invoice,)), [(1,)])
        self.assertIn(invoice, sales_service.render_invoice_html(sale))

    def test_multiple_products_use_individual_tax_rates_and_deduct_stock(self):
        success, message, invoice = sales_service.create_sale(
            self.seller,
            [
                {"product_id": 1, "quantity": 2, "tax_rate": 5},
                {"product_id": 2, "quantity": 1, "tax_rate": 12}
            ]
        )
        self.assertTrue(success, message)
        sale = sales_service.get_sale_details(self.seller, invoice)
        self.assertEqual(sale["subtotal"], 45.5)
        self.assertAlmostEqual(sale["gst_amount"], 4.06)
        self.assertAlmostEqual(sale["total_amount"], 49.56)
        self.assertEqual(
            [(item["tax_rate"], item["tax_amount"], item["line_total"])
             for item in sale["items"]],
            [(5, 1, 20), (12, 3.06, 25.5)]
        )
        self.assertEqual(
            self.query("SELECT stock_quantity FROM products ORDER BY id"),
            [(10,), (1,)]
        )

    def test_generated_invoice_numbers_are_unique(self):
        first = sales_service.create_sale(
            self.seller, [{"product_id": 1, "quantity": 1}]
        )
        second = sales_service.create_sale(
            self.seller, [{"product_id": 1, "quantity": 1}]
        )
        self.assertTrue(first[0], first[1])
        self.assertTrue(second[0], second[1])
        self.assertNotEqual(first[2], second[2])

    def test_product_search_returns_current_price_and_only_available_stock(self):
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute("""
                INSERT INTO products (
                    product_name, sku, category, selling_price, stock_quantity
                )
                VALUES ('Out of Stock', 'ZERO-01', 'Test', 5, 0)
            """)
            connection.commit()
        finally:
            connection.close()
        results = sales_service.search_sellable_products(self.seller, "TL-01")
        self.assertEqual(results, [{
            "id": 1,
            "product_name": "Trail Lamp",
            "sku": "TL-01",
            "category": "Outdoor",
            "selling_price": 10,
            "stock_quantity": 12
        }])
        self.assertEqual(
            sales_service.search_sellable_products(self.seller, "ZERO-01"),
            []
        )

    def test_salesperson_dashboard_and_reports_only_include_their_sales(self):
        own_sale = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 2}],
            gst_percent=5,
            invoice_number="SELLER-DASH-001"
        )
        other_sale = sales_service.create_sale(
            self.other_seller,
            [{"product_id": 2, "quantity": 1}],
            invoice_number="OTHER-DASH-001"
        )
        self.assertTrue(own_sale[0], own_sale[1])
        self.assertTrue(other_sale[0], other_sale[1])
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute("""
                INSERT INTO sales (
                    invoice_number, subtotal, total_amount, sold_by, created_at
                ) VALUES ('SELLER-OLD-001', 5, 5, 2, '2025-01-01 12:00:00')
            """)
            connection.commit()
        finally:
            connection.close()

        dashboard = sales_service.get_salesperson_dashboard_statistics(
            self.seller
        )
        self.assertEqual(dashboard["today_invoice_count"], 1)
        self.assertEqual(dashboard["today_items_sold"], 2)
        self.assertEqual(dashboard["today_sales"], 21)
        self.assertEqual(dashboard["weekly_sales"], 21)
        self.assertEqual(dashboard["monthly_sales"], 21)
        self.assertEqual(
            {row["invoice_number"] for row in dashboard["recent_transactions"]},
            {"SELLER-DASH-001", "SELLER-OLD-001"}
        )
        today = datetime.now().date().isoformat()
        report = sales_service.get_salesperson_report(
            self.seller, today, today
        )
        self.assertEqual(report["summary"]["invoice_count"], 1)
        self.assertEqual(report["summary"]["items_sold"], 2)
        self.assertEqual(report["summary"]["total_amount"], 21)
        self.assertEqual(
            [row["invoice_number"] for row in report["sales_history"]],
            ["SELLER-DASH-001"]
        )
        self.assertEqual(report["top_products"][0]["quantity_sold"], 2)
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "my-sales.csv"
            count = sales_service.export_salesperson_report_csv(
                self.seller, "sales_history", today, today, target
            )
            self.assertEqual(count, 1)
            with target.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.DictReader(file))
            self.assertEqual(rows[0]["invoice_number"], "SELLER-DASH-001")
        with self.assertRaises(PermissionError):
            sales_service.get_salesperson_dashboard_statistics(self.manager)
            other_report = sales_service.get_salesperson_report(
                self.other_seller, today, today
            )
            self.assertEqual(
                [row["invoice_number"] for row in other_report["sales_history"]],
                ["OTHER-DASH-001"]
            )

    def test_sales_history_supports_dates_and_rejects_invalid_ranges(self):
        result = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 1}],
            invoice_number="DATED-SELLER"
        )
        self.assertTrue(result[0], result[1])
        today = datetime.now().date().isoformat()
        self.assertEqual(
            [row["invoice_number"] for row in sales_service.search_sales(
                self.seller, "", today, today
            )],
            ["DATED-SELLER"]
        )
        with self.assertRaises(ValueError):
            sales_service.search_sales(
                self.seller, "", "2026-02-02", "2026-01-01"
            )
        with self.assertRaises(ValueError):
            sales_service.get_salesperson_report(
                self.seller, "not-a-date", today
            )

    def test_insufficient_stock_rejects_entire_multiline_sale(self):
        success, message, invoice = sales_service.create_sale(
            self.admin,
            [
                {"product_id": 1, "quantity": 2},
                {"product_id": 2, "quantity": 3}
            ]
        )
        self.assertFalse(success)
        self.assertIn("Insufficient stock", message)
        self.assertIsNone(invoice)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sales")[0][0], 1)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sale_items")[0][0], 1)
        self.assertEqual(self.query(
            "SELECT stock_quantity FROM products ORDER BY id"
        ), [(12,), (2,)])

    def test_invalid_quantities_percentages_and_product_ids_are_rejected(self):
        for quantity in (0, -1, 1.5, True, "2", 1 << 64):
            with self.subTest(quantity=quantity):
                success, _message, invoice = sales_service.create_sale(
                    self.seller,
                    [{"product_id": 1, "quantity": quantity}]
                )
                self.assertFalse(success)
                self.assertIsNone(invoice)

        for product_id in (0, -1, True, 999, 1 << 64):
            with self.subTest(product_id=product_id):
                success, _message, invoice = sales_service.create_sale(
                    self.seller,
                    [{"product_id": product_id, "quantity": 1}]
                )
                self.assertFalse(success)
                self.assertIsNone(invoice)

        success, _message, _invoice = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 1}],
            gst_percent=101
        )
        self.assertFalse(success)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sales")[0][0], 1)

    def test_duplicate_invoice_number_rolls_back_second_sale(self):
        first = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 1}],
            invoice_number="INV-DUPLICATE"
        )
        second = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 2}],
            invoice_number="INV-DUPLICATE"
        )
        self.assertTrue(first[0], first[1])
        self.assertFalse(second[0])
        self.assertIsNone(second[2])
        self.assertEqual(self.query(
            "SELECT stock_quantity FROM products WHERE id = 1"
        )[0][0], 11)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sales")[0][0], 2)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sale_items")[0][0], 2)

    def test_movement_failure_rolls_back_sale_items_and_stock(self):
        sales_service.search_sellable_products(self.admin)
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute("""
                CREATE TRIGGER reject_sale_movement
                BEFORE INSERT ON inventory_movements
                WHEN NEW.movement_type = 'sale'
                BEGIN
                    SELECT RAISE(ABORT, 'forced movement insert failure');
                END
            """)
            connection.commit()
        finally:
            connection.close()

        success, message, invoice = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 3}]
        )
        self.assertFalse(success)
        self.assertIn("forced movement insert failure", message)
        self.assertIsNone(invoice)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sales")[0][0], 1)
        self.assertEqual(self.query("SELECT COUNT(*) FROM sale_items")[0][0], 1)
        self.assertEqual(self.query(
            "SELECT stock_quantity FROM products WHERE id = 1"
        )[0][0], 12)

    def test_sale_item_snapshots_and_salesperson_history_permissions(self):
        sale = sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 1}],
            invoice_number="INV-SELLER"
        )
        other_sale = sales_service.create_sale(
            self.other_seller,
            [{"product_id": 2, "quantity": 1}],
            invoice_number="INV-OTHER"
        )
        self.assertTrue(sale[0], sale[1])
        self.assertTrue(other_sale[0], other_sale[1])

        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute("""
                UPDATE products SET product_name = 'Renamed Lamp',
                    sku = 'TL-NEW', selling_price = 99 WHERE id = 1
            """)
            connection.commit()
        finally:
            connection.close()

        details = sales_service.get_sale_details(self.seller, "INV-SELLER")
        self.assertEqual(details["items"][0]["product_name"], "Trail Lamp")
        self.assertEqual(details["items"][0]["sku"], "TL-01")
        self.assertEqual(details["items"][0]["unit_price"], 10)
        self.assertIsNone(sales_service.get_sale_details(self.seller, "INV-OTHER"))
        self.assertEqual(
            [row["invoice_number"] for row in sales_service.search_sales(self.seller)],
            ["INV-SELLER"]
        )
        self.assertEqual(
            {row["invoice_number"] for row in sales_service.search_sales(self.admin)},
            {"INV-SELLER", "INV-OTHER", "LEGACY-INV-01"}
        )
        with self.assertRaises(PermissionError):
            sales_service.search_sales(self.manager)
        with self.assertRaises(PermissionError):
            sales_service.get_sale_details(self.manager, "INV-SELLER")
        success, _message, invoice = sales_service.create_sale(
            self.manager,
            [{"product_id": 1, "quantity": 1}]
        )
        self.assertFalse(success)
        self.assertIsNone(invoice)

    def test_manager_can_view_only_aggregate_sales_summary(self):
        sales_service.create_sale(
            self.seller,
            [{"product_id": 1, "quantity": 1}],
            gst_percent=5,
            invoice_number="INV-SUMMARY"
        )
        manager_summary = sales_service.get_sales_summary(self.manager)
        seller_summary = sales_service.get_sales_summary(self.seller)
        self.assertEqual(manager_summary["invoice_count"], 2)
        self.assertEqual(seller_summary["invoice_count"], 1)
        self.assertEqual(manager_summary["subtotal"], 10)
        self.assertEqual(manager_summary["tax_amount"], 0.5)
        self.assertEqual(manager_summary["total_amount"], 19)

    def test_legacy_migrations_preserve_existing_sales_and_movements(self):
        sales_service.search_sellable_products(self.admin)
        self.assertEqual(
            self.query("SELECT invoice_number, total_amount FROM sales WHERE id = 1"),
            [("LEGACY-INV-01", 8.5)]
        )
        self.assertEqual(
            self.query("""
                SELECT id, movement_type, quantity, previous_stock, new_stock, notes
                FROM inventory_movements WHERE id = 1
            """),
            [(1, "receipt", 2, 10, 12, "Existing delivery")]
        )
        columns = {
            row[1] for row in self.query("PRAGMA table_info(sales)")
        }
        self.assertTrue({
            "subtotal", "gst_percent", "gst_amount",
            "discount_percent", "discount_amount"
        }.issubset(columns))
        item_columns = {
            row[1] for row in self.query("PRAGMA table_info(sale_items)")
        }
        self.assertTrue({
            "discount_amount", "tax_rate", "tax_amount", "tax_rate_recorded"
        }.issubset(item_columns))
        legacy_item = self.query("""
            SELECT product_name, sku, quantity, unit_price, line_total,
                   tax_rate, tax_amount
            FROM sale_items
            WHERE id = 1
        """)[0]
        self.assertEqual(
            legacy_item,
            ("Trail Lamp", "TL-01", 1, 8.5, 8.5, None, None)
        )
        legacy_invoice = sales_service.get_sale_details(
            self.admin, "LEGACY-INV-01"
        )
        self.assertIsNone(legacy_invoice["items"][0]["tax_rate"])
        self.assertFalse(legacy_invoice["items"][0]["tax_rate_recorded"])
        self.assertIn("Not recorded", sales_service.render_invoice_html(legacy_invoice))
        movement_sql = self.query("""
            SELECT sql FROM sqlite_master
            WHERE type = 'table' AND name = 'inventory_movements'
        """)[0][0]
        self.assertIn("'sale'", movement_sql)


if __name__ == "__main__":
    unittest.main()
