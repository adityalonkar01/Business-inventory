from services.product_service import get_all_products, delete_product


def main():
    """Manually deactivate an active product after confirmation."""

    products = get_all_products()
    if not products:
        print("No active products available.")
        return

    print("\nActive Products")
    print("-" * 50)
    for product in products:
        print(
            f"ID: {product[0]} | "
            f"Name: {product[1]} | "
            f"SKU: {product[2]}"
        )

    try:
        product_id = int(input("\nEnter the ID of the product to deactivate: "))
    except ValueError:
        print("Please enter a valid numeric product ID.")
        return

    selected_product = next(
        (product for product in products if product[0] == product_id),
        None
    )
    if selected_product is None:
        print("Product not found.")
        return

    confirmation = input(
        f"Deactivate '{selected_product[1]}'? (yes/no): "
    ).strip().lower()
    if confirmation != "yes":
        print("Deactivation cancelled.")
        return

    success, message = delete_product(product_id)
    print("\nSuccess:", success)
    print("Message:", message)

    updated_products = get_all_products()
    print("\nRemaining active products:")
    for product in updated_products:
        print(f"{product[1]} ({product[2]})")


if __name__ == "__main__":
    main()
