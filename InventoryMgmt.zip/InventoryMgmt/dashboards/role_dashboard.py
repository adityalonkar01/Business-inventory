import customtkinter as ctk

from dashboards.inventory_page import InventoryPage
from dashboards.sales_page import SalesPage
from dashboards.sales_summary_page import SalesSummaryPage
from dashboards.admin_module_pages import PurchaseManagementPage, ReportsPage
from dashboards.manager_module_pages import (
    AccountProfilePage,
    ManagerOverviewPage,
    ManagerProductPage,
)
from dashboards.salesperson_module_pages import (
    SalespersonDashboardPage,
    SalespersonReportsPage,
)


class InventoryRoleDashboard(ctk.CTk):
    """Shared role-based dashboard for non-admin users."""

    expected_role = ""
    display_title = "Inventory"

    def __init__(self, user):
        if user.get("role") != self.expected_role:
            raise PermissionError("This dashboard is not available for the supplied role.")

        super().__init__()
        self.user = user
        self.title(f"Inventory Management System | {self.display_title}")
        self.geometry("1200x750")
        self.minsize(1000, 650)
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.configure(fg_color="#F4F7FB")

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        sidebar = ctk.CTkFrame(self, width=230, corner_radius=0, fg_color="#172B4D")
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)

        ctk.CTkLabel(
            sidebar,
            text="INVENTORY",
            font=("Segoe UI", 23, "bold"),
            text_color="#FFFFFF"
        ).pack(pady=(30, 5), padx=20)
        ctk.CTkLabel(
            sidebar,
            text="MANAGEMENT SYSTEM",
            font=("Segoe UI", 10),
            text_color="#B8C7E0"
        ).pack(pady=(0, 35))
        self.navigation_buttons = {}
        navigation_items = ["Inventory"]
        home_page = "Inventory"
        if self.expected_role == "salesperson":
            navigation_items = [
                "Salesperson Dashboard",
                "Sales & Billing",
                "Sales History",
                "Reports",
                "Profile",
            ]
            home_page = "Salesperson Dashboard"
        elif self.expected_role == "manager":
            navigation_items = [
                "Manager Dashboard",
                "Products",
                "Inventory",
                "Sales Summary",
                "Purchases",
                "Reports",
                "Profile",
            ]
            home_page = "Manager Dashboard"
        for item in navigation_items:
            button = ctk.CTkButton(
                sidebar,
                text=f"   {item}",
                height=42,
                corner_radius=8,
                anchor="w",
                font=("Segoe UI", 14),
                fg_color="#29446F" if item == home_page else "transparent",
                hover_color="#29446F",
                text_color="#FFFFFF",
                command=lambda page=item: self.navigate(page)
            )
            button.pack(fill="x", padx=15, pady=4)
            self.navigation_buttons[item] = button
        ctk.CTkButton(
            sidebar,
            text="Logout",
            height=42,
            corner_radius=8,
            fg_color="#C0392B",
            hover_color="#A93226",
            text_color="#FFFFFF",
            command=self.destroy
        ).pack(side="bottom", fill="x", padx=15, pady=25)

        main_area = ctk.CTkFrame(self, corner_radius=0, fg_color="#F4F7FB")
        main_area.grid(row=0, column=1, sticky="nsew")
        main_area.grid_columnconfigure(0, weight=1)
        main_area.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(main_area, height=85, corner_radius=0, fg_color="#FFFFFF")
        header.grid(row=0, column=0, sticky="ew")
        header.grid_propagate(False)
        ctk.CTkLabel(
            header,
            text=f"{self.display_title} Dashboard",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D"
        ).pack(side="left", padx=30)
        ctk.CTkLabel(
            header,
            text=f"{self.display_title}: {user.get('username', '')}",
            font=("Segoe UI", 13),
            text_color="#526581"
        ).pack(side="right", padx=30)

        content = ctk.CTkFrame(main_area, fg_color="#F4F7FB")
        content.grid(row=1, column=0, sticky="nsew", padx=25, pady=20)
        content.grid_columnconfigure(0, weight=1)
        content.grid_rowconfigure(0, weight=1)
        self.content = content
        self.navigate(home_page)

    def navigate(self, page_name):
        """Switch between the pages permitted for the authenticated role."""

        allowed_pages = set(self.navigation_buttons)
        if page_name not in allowed_pages:
            raise PermissionError("This page is not available for the supplied role.")
        for button in self.navigation_buttons.values():
            button.configure(
                fg_color="#29446F" if button.cget("text").strip() == page_name else "transparent"
            )
        self.title(f"Inventory Management System | {self.display_title} | {page_name}")
        for widget in self.content.winfo_children():
            widget.destroy()
        if page_name == "Salesperson Dashboard":
            SalespersonDashboardPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        elif page_name == "Manager Dashboard":
            ManagerOverviewPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        elif page_name == "Products":
            ManagerProductPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        elif page_name == "Reports":
            report_page = (
                SalespersonReportsPage(self.content, self.user)
                if self.expected_role == "salesperson"
                else ReportsPage(self.content, self.user)
            )
            report_page.grid(row=0, column=0, sticky="nsew")
        elif page_name == "Profile":
            AccountProfilePage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        elif page_name in {"Sales & Billing", "Sales History"}:
            sales_page = SalesPage(self.content, self.user)
            sales_page.grid(row=0, column=0, sticky="nsew")
            if page_name == "Sales History":
                sales_page.after_idle(sales_page.show_sales_history)
        elif page_name == "Sales Summary":
            SalesSummaryPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        elif page_name == "Purchases":
            PurchaseManagementPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        else:
            InventoryPage(self.content, self.user).grid(row=0, column=0, sticky="nsew")
