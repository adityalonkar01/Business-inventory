import sqlite3

import customtkinter as ctk

from services.sales_service import get_sales_summary
from services.settings_service import get_public_settings


class SalesSummaryPage(ctk.CTkFrame):
    """Read-only aggregate sales overview for managers."""

    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.grid_columnconfigure(0, weight=1)
        self._build_page()
        self.refresh_summary()

    def _build_page(self):
        heading = ctk.CTkFrame(self, fg_color="transparent")
        heading.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        heading.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            heading,
            text="Sales Summary",
            font=("Segoe UI", 23, "bold"),
            text_color="#172B4D"
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(
            heading,
            text="Refresh",
            width=95,
            height=36,
            command=self.refresh_summary
        ).grid(row=0, column=1, sticky="e")
        self.status_label = ctk.CTkLabel(
            self,
            text="",
            font=("Segoe UI", 12),
            text_color="#526581",
            anchor="w"
        )
        self.status_label.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        self.cards = ctk.CTkFrame(self, fg_color="transparent")
        self.cards.grid(row=2, column=0, sticky="new")
        for column in range(2):
            self.cards.grid_columnconfigure(column, weight=1, uniform="sales_summary")

    def refresh_summary(self):
        try:
            summary = get_sales_summary(self.user)
            currency = get_public_settings()["currency_symbol"]
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.status_label.configure(
                text=f"Unable to load sales summary: {error}",
                text_color="#DC2626"
            )
            return
        for widget in self.cards.winfo_children():
            widget.destroy()
        values = (
            ("Invoices", f"{summary['invoice_count']:,}", "#2563EB"),
            ("Subtotal", f"{currency}{summary['subtotal']:,.2f}", "#0891B2"),
            ("Discounts", f"{currency}{summary['discount_amount']:,.2f}", "#D97706"),
            ("GST Collected", f"{currency}{summary['tax_amount']:,.2f}", "#7C3AED"),
            ("Total Sales", f"{currency}{summary['total_amount']:,.2f}", "#15803D")
        )
        for index, (title, amount, accent) in enumerate(values):
            card = ctk.CTkFrame(
                self.cards,
                fg_color="#FFFFFF",
                corner_radius=10,
                border_width=1,
                border_color="#E2E8F0"
            )
            card.grid(
                row=index // 2,
                column=index % 2,
                sticky="ew",
                padx=6,
                pady=6
            )
            ctk.CTkFrame(
                card,
                height=4,
                fg_color=accent,
                corner_radius=2
            ).pack(fill="x", padx=12, pady=(12, 7))
            ctk.CTkLabel(
                card,
                text=title,
                font=("Segoe UI", 12),
                text_color="#718096"
            ).pack(anchor="w", padx=15, pady=(3, 2))
            ctk.CTkLabel(
                card,
                text=amount,
                font=("Segoe UI", 22, "bold"),
                text_color="#172B4D"
            ).pack(anchor="w", padx=15, pady=(0, 14))
        self.status_label.configure(
            text="Read-only summary across recorded sales.",
            text_color="#526581"
        )
