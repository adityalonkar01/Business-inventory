import math
import sqlite3
import webbrowser
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services.sales_service import (
    create_sale,
    get_sale_details,
    render_invoice_html,
    search_sales,
    search_sellable_products
)
from services.settings_service import get_public_settings


CENT = Decimal("0.01")


class SalesPage(ctk.CTkFrame):
    """Product checkout and sales history interface for authorized roles."""

    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.cart = {}
        try:
            self.settings = get_public_settings()
            self.settings_error = ""
        except sqlite3.Error as error:
            self.settings = {
                "currency_symbol": "₹",
                "default_gst_percent": 0
            }
            self.settings_error = f"Could not load application settings: {error}"
        self.currency_symbol = self.settings["currency_symbol"]
        self.grid_columnconfigure((0, 1), weight=1, uniform="sales_columns")
        self.grid_rowconfigure(1, weight=1)
        self._build_page()
        self.refresh_products()
        self._refresh_cart()

    def _build_page(self):
        heading = ctk.CTkFrame(self, fg_color="transparent")
        heading.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 14))
        heading.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            heading,
            text="Sales & Billing",
            font=("Segoe UI", 23, "bold"),
            text_color="#172B4D"
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(
            heading,
            text="Sales History",
            width=130,
            height=36,
            command=self.show_sales_history
        ).grid(row=0, column=1, sticky="e")

        catalog = ctk.CTkFrame(
            self,
            fg_color="#FFFFFF",
            corner_radius=10,
            border_width=1,
            border_color="#E2E8F0"
        )
        catalog.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        catalog.grid_columnconfigure(0, weight=1)
        catalog.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(
            catalog,
            text="Available Products",
            font=("Segoe UI", 17, "bold"),
            text_color="#172B4D"
        ).grid(row=0, column=0, sticky="w", padx=14, pady=(14, 8))

        search_row = ctk.CTkFrame(catalog, fg_color="transparent")
        search_row.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 8))
        search_row.grid_columnconfigure(0, weight=1)
        self.product_search = ctk.CTkEntry(
            search_row,
            height=36,
            placeholder_text="Search name or SKU"
        )
        self.product_search.grid(row=0, column=0, sticky="ew")
        self.product_search.bind("<Return>", lambda _event: self.refresh_products())
        ctk.CTkButton(
            search_row,
            text="Search",
            width=75,
            height=36,
            command=self.refresh_products
        ).grid(row=0, column=1, padx=(6, 0))
        self.product_status = ctk.CTkLabel(
            catalog,
            text="",
            anchor="w",
            font=("Segoe UI", 11),
            text_color="#526581"
        )
        self.product_status.grid(row=2, column=0, sticky="new", padx=14, pady=(0, 4))
        self.product_rows = ctk.CTkScrollableFrame(catalog, fg_color="#FFFFFF")
        self.product_rows.grid(row=3, column=0, sticky="nsew", padx=8, pady=(0, 8))
        self.product_rows.grid_columnconfigure(0, weight=1)
        catalog.grid_rowconfigure(3, weight=1)

        bill = ctk.CTkFrame(
            self,
            fg_color="#FFFFFF",
            corner_radius=10,
            border_width=1,
            border_color="#E2E8F0"
        )
        bill.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        bill.grid_columnconfigure(0, weight=1)
        bill.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(
            bill,
            text="Current Bill",
            font=("Segoe UI", 17, "bold"),
            text_color="#172B4D"
        ).grid(row=0, column=0, sticky="w", padx=14, pady=(14, 8))
        self.cart_rows = ctk.CTkScrollableFrame(bill, fg_color="#FFFFFF")
        self.cart_rows.grid(row=1, column=0, sticky="nsew", padx=8)
        self.cart_rows.grid_columnconfigure(0, weight=1)

        adjustments = ctk.CTkFrame(bill, fg_color="#F8FAFC", corner_radius=8)
        adjustments.grid(row=2, column=0, sticky="ew", padx=12, pady=10)
        adjustments.grid_columnconfigure((1, 3), weight=1)
        ctk.CTkLabel(
            adjustments, text="GST %", font=("Segoe UI", 12, "bold")
        ).grid(row=0, column=0, padx=(10, 5), pady=9)
        self.gst_entry = ctk.CTkEntry(adjustments, width=75, height=32)
        self.gst_entry.insert(0, str(self.settings["default_gst_percent"]))
        self.gst_entry.grid(row=0, column=1, sticky="w", pady=9)
        self.gst_entry.bind("<KeyRelease>", lambda _event: self._preview_totals())
        ctk.CTkLabel(
            adjustments, text="Discount %", font=("Segoe UI", 12, "bold")
        ).grid(row=0, column=2, padx=(8, 5), pady=9)
        self.discount_entry = ctk.CTkEntry(adjustments, width=75, height=32)
        self.discount_entry.insert(0, "0")
        self.discount_entry.grid(row=0, column=3, sticky="w", pady=9)
        self.discount_entry.bind("<KeyRelease>", lambda _event: self._preview_totals())
        ctk.CTkLabel(
            bill,
            text="Default GST for new items; edit GST per line in the bill.",
            font=("Segoe UI", 10),
            text_color="#718096",
            anchor="w"
        ).grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 2))

        self.totals_label = ctk.CTkLabel(
            bill,
            text=(
                f"Subtotal: {self.currency_symbol}0.00\n"
                f"Discount: - {self.currency_symbol}0.00\n"
                f"GST: {self.currency_symbol}0.00\n"
                f"Total: {self.currency_symbol}0.00"
            ),
            justify="right",
            anchor="e",
            font=("Segoe UI", 13),
            text_color="#334155"
        )
        self.totals_label.grid(row=4, column=0, sticky="ew", padx=16, pady=(0, 8))
        self.bill_status = ctk.CTkLabel(
            bill,
            text=self.settings_error,
            anchor="w",
            wraplength=420,
            font=("Segoe UI", 11),
            text_color="#DC2626"
        )
        self.bill_status.grid(row=5, column=0, sticky="ew", padx=14, pady=(0, 4))
        ctk.CTkButton(
            bill,
            text="Complete Sale",
            height=40,
            font=("Segoe UI", 13, "bold"),
            command=self.complete_sale
        ).grid(row=6, column=0, sticky="ew", padx=14, pady=(4, 14))

    def refresh_products(self):
        try:
            products = search_sellable_products(self.user, self.product_search.get())
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.product_status.configure(
                text=f"Unable to load products: {error}",
                text_color="#DC2626"
            )
            return

        for widget in self.product_rows.winfo_children():
            widget.destroy()
        if not products:
            ctk.CTkLabel(
                self.product_rows,
                text="No matching active products.",
                font=("Segoe UI", 12),
                text_color="#718096"
            ).grid(row=0, column=0, sticky="ew", pady=20)
        for row, product in enumerate(products):
            card = ctk.CTkFrame(
                self.product_rows,
                fg_color="#F8FAFC" if row % 2 == 0 else "#FFFFFF",
                corner_radius=6
            )
            card.grid(row=row, column=0, sticky="ew", padx=3, pady=3)
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(
                card,
                text=f"{product['product_name']}  ·  {product['sku']}",
                font=("Segoe UI", 12, "bold"),
                text_color="#172B4D",
                anchor="w"
            ).grid(row=0, column=0, sticky="ew", padx=8, pady=(7, 0))
            ctk.CTkLabel(
                card,
                text=(
                    f"{product.get('category', '')}  |  "
                    f"{self.currency_symbol}{product['selling_price']:,.2f}  |  "
                    f"Stock: {product['stock_quantity']}"
                ),
                font=("Segoe UI", 11),
                text_color="#526581",
                anchor="w"
            ).grid(row=1, column=0, sticky="ew", padx=8, pady=(1, 7))
            ctk.CTkButton(
                card,
                text="Add",
                width=58,
                height=30,
                command=lambda item=product: self.add_to_cart(item)
            ).grid(row=0, column=1, rowspan=2, padx=8, pady=6)
        self.product_status.configure(
            text=f"{len(products)} active product(s).",
            text_color="#526581"
        )

    def add_to_cart(self, product):
        self._sync_cart_entries()
        item = self.cart.get(product["id"])
        quantity = (item["quantity"] if item else 0) + 1
        if quantity > product["stock_quantity"]:
            self.bill_status.configure(
                text=f"Only {product['stock_quantity']} unit(s) are currently available."
            )
            return
        try:
            default_tax_rate = Decimal(self.gst_entry.get().strip() or "0")
            if not default_tax_rate.is_finite() or not 0 <= default_tax_rate <= 100:
                raise ValueError
        except (InvalidOperation, ValueError):
            self.bill_status.configure(text="Default GST must be between 0 and 100%.")
            return
        self.cart[product["id"]] = {
            **product,
            "quantity": quantity,
            "tax_rate": item["tax_rate"] if item else default_tax_rate
        }
        self.bill_status.configure(text="")
        self._refresh_cart()

    def _refresh_cart(self):
        if not hasattr(self, "cart_rows"):
            return
        self._sync_cart_entries()
        for widget in self.cart_rows.winfo_children():
            widget.destroy()

        self.quantity_entries = {}
        self.tax_rate_entries = {}
        if not self.cart:
            ctk.CTkLabel(
                self.cart_rows,
                text="Add products from the catalog to start a bill.",
                font=("Segoe UI", 12),
                text_color="#718096"
            ).grid(row=0, column=0, sticky="ew", pady=20)
        for row, (product_id, item) in enumerate(self.cart.items()):
            card = ctk.CTkFrame(self.cart_rows, fg_color="#F8FAFC", corner_radius=6)
            card.grid(row=row, column=0, sticky="ew", padx=3, pady=3)
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(
                card,
                text=f"{item['product_name']} · {item['sku']}",
                font=("Segoe UI", 12, "bold"),
                text_color="#172B4D",
                anchor="w"
            ).grid(row=0, column=0, sticky="ew", padx=8, pady=(6, 0))
            ctk.CTkLabel(
                card,
                text=f"{self.currency_symbol}{item['selling_price']:,.2f} each",
                font=("Segoe UI", 11),
                text_color="#526581",
                anchor="w"
            ).grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 6))
            ctk.CTkLabel(
                card,
                text="Qty",
                font=("Segoe UI", 9),
                text_color="#718096"
            ).grid(row=0, column=1, padx=5, pady=(3, 0))
            quantity = ctk.CTkEntry(card, width=62, height=30)
            quantity.insert(0, str(item["quantity"]))
            quantity.grid(row=1, column=1, padx=5, pady=(0, 6))
            quantity.bind(
                "<KeyRelease>",
                lambda _event, identifier=product_id: self._cart_field_changed(identifier)
            )
            self.quantity_entries[product_id] = quantity
            ctk.CTkLabel(
                card,
                text="GST %",
                font=("Segoe UI", 9),
                text_color="#718096"
            ).grid(row=0, column=2, padx=5, pady=(3, 0))
            tax_rate = ctk.CTkEntry(card, width=62, height=30)
            tax_rate.insert(0, str(item["tax_rate"]))
            tax_rate.grid(row=1, column=2, padx=5, pady=(0, 6))
            tax_rate.bind(
                "<KeyRelease>",
                lambda _event, identifier=product_id: self._cart_field_changed(identifier)
            )
            self.tax_rate_entries[product_id] = tax_rate
            ctk.CTkButton(
                card,
                text="Remove",
                width=65,
                height=30,
                fg_color="#64748B",
                hover_color="#475569",
                command=lambda identifier=product_id: self.remove_from_cart(identifier)
            ).grid(row=0, column=3, rowspan=2, padx=(0, 7), pady=6)
        self._preview_totals()

    def _sync_cart_entries(self):
        for product_id, item in self.cart.items():
            quantity_entry = getattr(self, "quantity_entries", {}).get(product_id)
            tax_entry = getattr(self, "tax_rate_entries", {}).get(product_id)
            if quantity_entry is None or tax_entry is None:
                continue
            try:
                quantity = int(quantity_entry.get().strip())
                tax_rate = Decimal(tax_entry.get().strip())
                if (
                    quantity < 1
                    or quantity > item["stock_quantity"]
                    or not tax_rate.is_finite()
                    or tax_rate < 0
                    or tax_rate > 100
                ):
                    continue
            except (ValueError, InvalidOperation):
                continue
            item["quantity"] = quantity
            item["tax_rate"] = tax_rate

    def _cart_field_changed(self, product_id):
        item = self.cart.get(product_id)
        if item is not None:
            try:
                quantity = int(self.quantity_entries[product_id].get().strip())
                tax_rate = Decimal(self.tax_rate_entries[product_id].get().strip())
                if 1 <= quantity <= item["stock_quantity"]:
                    item["quantity"] = quantity
                if tax_rate.is_finite() and 0 <= tax_rate <= 100:
                    item["tax_rate"] = tax_rate
            except (ValueError, InvalidOperation):
                pass
        self._preview_totals()

    def remove_from_cart(self, product_id):
        self.cart.pop(product_id, None)
        self.bill_status.configure(text="")
        self._refresh_cart()

    def _preview_totals(self):
        try:
            discount = Decimal(self.discount_entry.get().strip() or "0")
            if (
                not discount.is_finite()
                or discount < 0 or discount > 100
            ):
                raise ValueError
            subtotal = Decimal("0")
            line_subtotals = []
            for product_id, item in self.cart.items():
                quantity = int(self.quantity_entries[product_id].get().strip())
                tax_rate = Decimal(self.tax_rate_entries[product_id].get().strip())
                if quantity < 1 or quantity > item["stock_quantity"]:
                    raise ValueError
                if not tax_rate.is_finite() or tax_rate < 0 or tax_rate > 100:
                    raise ValueError
                unit_price = Decimal(str(item["selling_price"])).quantize(
                    CENT,
                    rounding=ROUND_HALF_UP
                )
                line_subtotal = (unit_price * quantity).quantize(
                    CENT,
                    rounding=ROUND_HALF_UP
                )
                line_subtotals.append((line_subtotal, tax_rate))
                subtotal += line_subtotal
            subtotal = subtotal.quantize(CENT, rounding=ROUND_HALF_UP)
            discount_amount = (subtotal * discount / 100).quantize(
                CENT, rounding=ROUND_HALF_UP
            )
            remaining_discount = discount_amount
            gst_amount = Decimal("0.00")
            for index, (line_subtotal, tax_rate) in enumerate(line_subtotals):
                if index == len(line_subtotals) - 1:
                    line_discount = remaining_discount
                elif subtotal:
                    line_discount = (
                        discount_amount * line_subtotal / subtotal
                    ).quantize(CENT, rounding=ROUND_HALF_UP)
                    remaining_discount -= line_discount
                else:
                    line_discount = Decimal("0.00")
                taxable_line = line_subtotal - line_discount
                gst_amount += (
                    taxable_line * tax_rate / Decimal("100")
                ).quantize(CENT, rounding=ROUND_HALF_UP)
            total = subtotal - discount_amount + gst_amount
            self.totals_label.configure(
                text=(
                    f"Subtotal: {self.currency_symbol}{subtotal:,.2f}\n"
                    f"Discount: - {self.currency_symbol}{discount_amount:,.2f}\n"
                    f"GST: {self.currency_symbol}{gst_amount:,.2f}\n"
                    f"Total: {self.currency_symbol}{total:,.2f}"
                ),
                text_color="#334155"
            )
            self.bill_status.configure(text="")
        except (InvalidOperation, ValueError):
            self.totals_label.configure(
                text="Enter valid tax/discount percentages and whole-number quantities.",
                text_color="#DC2626"
            )

    def complete_sale(self):
        if not self.cart:
            self.bill_status.configure(text="Add at least one product to the bill.")
            return
        try:
            fresh_products = {
                product["id"]: product
                for product in search_sellable_products(self.user)
            }
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.bill_status.configure(
                text=f"Unable to refresh stock before checkout: {error}"
            )
            return

        for product_id, item in tuple(self.cart.items()):
            current_product = fresh_products.get(product_id)
            if current_product is None:
                self.bill_status.configure(
                    text=f"{item['product_name']} is no longer available."
                )
                self.refresh_products()
                return
            try:
                quantity = int(self.quantity_entries[product_id].get().strip())
                tax_rate = Decimal(
                    self.tax_rate_entries[product_id].get().strip()
                )
            except (ValueError, InvalidOperation):
                self.bill_status.configure(
                    text="Enter valid whole-number quantities and GST rates."
                )
                return
            if quantity < 1:
                self.bill_status.configure(text="Sale quantities must be positive.")
                return
            if quantity > current_product["stock_quantity"]:
                self.bill_status.configure(
                    text=(
                        f"Only {current_product['stock_quantity']} unit(s) of "
                        f"{current_product['product_name']} are currently available."
                    )
                )
                self.refresh_products()
                return
            if not tax_rate.is_finite() or not 0 <= tax_rate <= 100:
                self.bill_status.configure(text="GST must be between 0 and 100%.")
                return
            self.cart[product_id] = {
                **current_product,
                "quantity": quantity,
                "tax_rate": tax_rate,
            }
        self._refresh_cart()

        try:
            items = [
                {
                    "product_id": product_id,
                    "quantity": int(self.quantity_entries[product_id].get().strip()),
                    "tax_rate": float(
                        self.tax_rate_entries[product_id].get().strip()
                    )
                }
                for product_id in self.cart
            ]
            discount = float(self.discount_entry.get().strip() or "0")
            if not math.isfinite(discount) or not all(
                math.isfinite(item["tax_rate"]) for item in items
            ):
                raise ValueError
            if not 0 <= discount <= 100 or any(
                not 0 <= item["tax_rate"] <= 100 for item in items
            ):
                raise ValueError
        except (ValueError, OverflowError):
            self.bill_status.configure(
                text="Enter valid whole-number quantities and percentage values."
            )
            return

        if not messagebox.askyesno(
            "Confirm sale",
            f"Complete this sale?\n\n{self.totals_label.cget('text')}",
            parent=self,
        ):
            return

        success, message, invoice_number = create_sale(
            self.user,
            items,
            discount_percent=discount
        )
        if not success:
            self.bill_status.configure(text=message)
            self.refresh_products()
            return

        self.cart.clear()
        self.refresh_products()
        self._refresh_cart()
        messagebox.showinfo("Sale completed", message, parent=self)
        self.show_invoice(invoice_number)

    def show_sales_history(self):
        dialog = ctk.CTkToplevel(self)
        dialog.title("Sales History")
        dialog.geometry("1050x560")
        dialog.minsize(850, 450)
        dialog.transient(self.winfo_toplevel())

        ctk.CTkLabel(
            dialog,
            text="Sales History",
            font=("Segoe UI", 21, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=20, pady=(18, 10))
        search_row = ctk.CTkFrame(dialog, fg_color="transparent")
        search_row.pack(fill="x", padx=20, pady=(0, 10))
        query = ctk.CTkEntry(
            search_row,
            height=36,
            placeholder_text="Search invoice number"
        )
        query.pack(side="left", fill="x", expand=True)
        start_date = ctk.CTkEntry(
            search_row,
            width=125,
            height=36,
            placeholder_text="From YYYY-MM-DD",
        )
        start_date.pack(side="left", padx=(8, 0))
        end_date = ctk.CTkEntry(
            search_row,
            width=125,
            height=36,
            placeholder_text="To YYYY-MM-DD",
        )
        end_date.pack(side="left", padx=(8, 0))
        table = ctk.CTkScrollableFrame(dialog, fg_color="#FFFFFF")
        table.pack(fill="both", expand=True, padx=20, pady=(0, 18))

        def refresh():
            for widget in table.winfo_children():
                widget.destroy()
            try:
                invoices = search_sales(
                    self.user,
                    query.get(),
                    start_date.get().strip() or None,
                    end_date.get().strip() or None,
                )
            except (sqlite3.Error, PermissionError, ValueError) as error:
                messagebox.showerror("Sales history", str(error), parent=dialog)
                return
            for column, title in enumerate(("Invoice", "Date", "Sold by", "Items", "Total", "")):
                ctk.CTkLabel(
                    table,
                    text=title,
                    font=("Segoe UI", 12, "bold"),
                    text_color="#526581",
                    anchor="w"
                ).grid(row=0, column=column, sticky="ew", padx=7, pady=8)
            for row, invoice in enumerate(invoices, start=1):
                values = (
                    invoice["invoice_number"],
                    invoice["created_at"],
                    invoice["sold_by_username"] or "",
                    invoice["item_count"],
                    f"{invoice.get('currency_symbol', self.currency_symbol)}"
                    f"{invoice['total_amount']:,.2f}"
                )
                for column, value in enumerate(values):
                    ctk.CTkLabel(
                        table,
                        text=str(value),
                        font=("Segoe UI", 11),
                        text_color="#334155",
                        anchor="w"
                    ).grid(row=row, column=column, sticky="ew", padx=7, pady=6)
                ctk.CTkButton(
                    table,
                    text="View",
                    width=62,
                    height=28,
                    command=lambda number=invoice["invoice_number"]: self.show_invoice(number)
                ).grid(row=row, column=5, padx=5, pady=4)
            if not invoices:
                ctk.CTkLabel(
                    table,
                    text="No matching invoices.",
                    text_color="#718096"
                ).grid(row=1, column=0, columnspan=6, pady=20)

        ctk.CTkButton(
            search_row, text="Search", width=85, height=36, command=refresh
        ).pack(side="left", padx=(8, 0))
        query.bind("<Return>", lambda _event: refresh())
        refresh()

    def show_invoice(self, invoice_number):
        try:
            invoice = get_sale_details(self.user, invoice_number)
        except (sqlite3.Error, PermissionError, ValueError) as error:
            messagebox.showerror("Invoice", str(error), parent=self)
            return
        if invoice is None:
            messagebox.showerror("Invoice", "Invoice was not found.", parent=self)
            return

        dialog = ctk.CTkToplevel(self)
        dialog.title(f"Invoice {invoice_number}")
        dialog.geometry("720x540")
        dialog.minsize(600, 420)
        dialog.transient(self.winfo_toplevel())
        ctk.CTkLabel(
            dialog,
            text=f"Invoice {invoice['invoice_number']}",
            font=("Segoe UI", 21, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=20, pady=(18, 4))
        ctk.CTkLabel(
            dialog,
            text=f"{invoice['created_at']}  ·  Sold by {invoice['sold_by_username'] or ''}",
            font=("Segoe UI", 12),
            text_color="#526581"
        ).pack(anchor="w", padx=20, pady=(0, 10))
        lines = ctk.CTkScrollableFrame(dialog, fg_color="#FFFFFF")
        lines.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        for row, item in enumerate(invoice["items"]):
            tax_display = (
                "GST not recorded"
                if item["tax_rate"] is None
                else f"GST {item['tax_rate']:g}% "
                f"({self.currency_symbol}{item['tax_amount']:,.2f})"
            )
            ctk.CTkLabel(
                lines,
                text=(
                    f"{item['product_name']} ({item['sku']})  ·  "
                    f"{item['quantity']} × {self.currency_symbol}{item['unit_price']:,.2f}  "
                    f"· {tax_display}  ·  "
                    f"{self.currency_symbol}{item['line_total']:,.2f} before tax"
                ),
                anchor="w",
                text_color="#334155"
            ).grid(row=row, column=0, sticky="ew", padx=8, pady=6)
        ctk.CTkLabel(
            dialog,
            text=(
                f"Subtotal {self.currency_symbol}{invoice['subtotal']:,.2f}  ·  "
                f"Discount {self.currency_symbol}{invoice['discount_amount']:,.2f}  ·  "
                f"GST {self.currency_symbol}{invoice['gst_amount']:,.2f}  ·  "
                f"Total {self.currency_symbol}{invoice['total_amount']:,.2f}"
            ),
            font=("Segoe UI", 12, "bold"),
            text_color="#172B4D"
        ).pack(anchor="e", padx=20, pady=(0, 12))

        def save_print_ready():
            target = filedialog.asksaveasfilename(
                parent=dialog,
                title="Save print-ready invoice",
                defaultextension=".html",
                initialfile=f"{invoice_number}.html",
                filetypes=(("HTML invoice", "*.html"),)
            )
            if not target:
                return
            try:
                path = Path(target)
                path.write_text(render_invoice_html(invoice), encoding="utf-8")
                webbrowser.open(path.resolve().as_uri())
            except (OSError, ValueError) as error:
                messagebox.showerror("Invoice", f"Unable to save invoice: {error}", parent=dialog)

        ctk.CTkButton(
            dialog,
            text="Save / Print Invoice",
            height=36,
            command=save_print_ready
        ).pack(anchor="e", padx=20, pady=(0, 16))
