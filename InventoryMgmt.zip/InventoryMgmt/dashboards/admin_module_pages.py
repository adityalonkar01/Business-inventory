from datetime import date, timedelta
import sqlite3
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services.category_service import (
    create_category,
    deactivate_category,
    list_categories,
    rename_category,
    set_category_active,
)
from services.product_service import get_all_products, get_manager_products
from services.purchase_service import (
    create_purchase,
    get_purchase_details,
    list_purchases,
    receive_purchase,
)
from services.report_service import export_report_csv, get_reports
from services.settings_service import (
    get_admin_settings,
    get_public_settings,
    update_settings,
)
from services.supplier_service import (
    list_purchase_suppliers,
    list_suppliers,
    save_supplier,
    set_supplier_active,
)
from services.user_service import (
    create_user,
    list_users,
    reset_user_password,
    set_user_active,
    update_user,
)


NAVY = "#172B4D"
MUTED = "#526581"
RED = "#DC2626"
GREEN = "#15803D"


class _AdminPage(ctk.CTkFrame):
    def __init__(self, master, user, title):
        super().__init__(master, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self.user = user
        heading = ctk.CTkFrame(
            self, height=48, fg_color="transparent"
        )
        heading.grid(row=0, column=0, sticky="ew", pady=(4, 10))
        heading.grid_propagate(False)
        heading.grid_columnconfigure(0, weight=1)
        self.heading = ctk.CTkLabel(
            heading, text=title, font=("Segoe UI", 23, "bold"), text_color=NAVY
        )
        self.heading.pack(side="left")
        self.action_area = ctk.CTkFrame(
            heading, width=1, height=1, fg_color="transparent"
        )
        self.action_area.pack(side="right", anchor="center")
        self.status = ctk.CTkLabel(
            self, text="", font=("Segoe UI", 12), text_color=MUTED, anchor="w"
        )
        self.status.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        self.body = ctk.CTkScrollableFrame(
            self, fg_color="#FFFFFF", corner_radius=10,
            border_width=1, border_color="#E2E8F0"
        )
        self.body.grid(row=2, column=0, sticky="nsew")
        self.body.grid_columnconfigure(0, weight=1)

    def set_status(self, text, success=False):
        self.status.configure(text=text, text_color=GREEN if success else RED)

    def make_table(self, parent, headings, rows, empty_text="No records found."):
        table = ctk.CTkFrame(parent, fg_color="transparent")
        table.pack(fill="x", padx=12, pady=10)
        for column in range(len(headings)):
            table.grid_columnconfigure(column, weight=1)
        for column, title in enumerate(headings):
            ctk.CTkLabel(
                table, text=title, font=("Segoe UI", 11, "bold"),
                text_color=MUTED, anchor="w"
            ).grid(row=0, column=column, sticky="ew", padx=7, pady=(8, 10))
        if not rows:
            ctk.CTkLabel(
                table, text=empty_text, font=("Segoe UI", 12), text_color=MUTED
            ).grid(row=1, column=0, columnspan=len(headings), sticky="w", padx=7, pady=18)
        else:
            for row_number, values in enumerate(rows, 1):
                for column, value in enumerate(values):
                    ctk.CTkLabel(
                        table, text=str(value), font=("Segoe UI", 11),
                        text_color="#334155", anchor="w",
                        fg_color="#F8FAFC" if row_number % 2 == 0 else "transparent"
                    ).grid(row=row_number, column=column, sticky="ew", padx=5, pady=4, ipady=5)
        return table

    def open_dialog(self, title, size="520x480"):
        dialog = ctk.CTkToplevel(self)
        dialog.title(title)
        dialog.geometry(size)
        dialog.minsize(430, 340)
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        return dialog

    @staticmethod
    def add_entry(parent, label, value="", show=None):
        ctk.CTkLabel(
            parent, text=label, font=("Segoe UI", 12, "bold"), text_color="#334155"
        ).pack(anchor="w", pady=(8, 3))
        entry = ctk.CTkEntry(parent, height=36, show=show)
        entry.pack(fill="x")
        if value not in (None, ""):
            entry.insert(0, str(value))
        return entry


class UserManagementPage(_AdminPage):
    def __init__(self, master, user):
        super().__init__(master, user, "User Management")
        ctk.CTkButton(
            self.action_area, text="+ Add User", command=self.open_user_form
        ).pack(side="right")
        self.refresh()

    def refresh(self):
        for child in self.body.winfo_children():
            child.destroy()
        try:
            users = list_users(self.user)
        except (sqlite3.Error, PermissionError) as error:
            self.set_status(f"Could not load users: {error}")
            return
        for account in users:
            actions = ctk.CTkFrame(self.body, fg_color="transparent")
            actions.pack(fill="x", padx=12, pady=2)
            ctk.CTkLabel(
                actions,
                text=f"{account['username']}  ·  {account['role']}  ·  "
                     f"{'Active' if account['is_active'] else 'Inactive'}",
                text_color="#334155", anchor="w"
            ).pack(side="left", expand=True, fill="x")
            ctk.CTkButton(
                actions, text="Edit", width=60,
                command=lambda item=account: self.open_user_form(item)
            ).pack(side="right", padx=3)
            ctk.CTkButton(
                actions, text="Password", width=80, fg_color="#64748B",
                command=lambda item=account: self.open_password_form(item)
            ).pack(side="right", padx=3)
            ctk.CTkButton(
                actions, text="Deactivate" if account["is_active"] else "Activate",
                width=90, fg_color="#B45309" if account["is_active"] else GREEN,
                command=lambda item=account: self.toggle_active(item)
            ).pack(side="right", padx=3)
        if not users:
            ctk.CTkLabel(self.body, text="No user accounts found.").pack(pady=25)
        self.set_status(f"{len(users)} user account(s) loaded.", True)

    def open_user_form(self, account=None):
        dialog = self.open_dialog("Edit User" if account else "Add User", "500x480")
        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=22, pady=16)
        username = self.add_entry(form, "Username", account["username"] if account else "")
        role_label = ctk.CTkLabel(form, text="Role", text_color="#334155")
        role_label.pack(anchor="w", pady=(10, 3))
        role = ctk.CTkOptionMenu(form, values=["admin", "manager", "salesperson"])
        role.set(account["role"] if account else "salesperson")
        role.pack(fill="x")
        password = None
        if not account:
            password = self.add_entry(form, "Initial password (minimum 8 characters)", show="*")
        error = ctk.CTkLabel(form, text="", text_color=RED, wraplength=430)
        error.pack(fill="x", pady=10)

        def save():
            if account:
                success, message = update_user(
                    self.user, account["id"], username.get(), role.get()
                )
            else:
                success, message = create_user(
                    self.user, username.get(), password.get(), role.get()
                )
            if not success:
                error.configure(text=message)
                return
            dialog.destroy()
            self.refresh()
            self.set_status(message, True)

        ctk.CTkButton(form, text="Save User", command=save).pack(anchor="e", pady=12)

    def open_password_form(self, account):
        dialog = self.open_dialog("Reset Password", "460x300")
        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=22, pady=18)
        ctk.CTkLabel(form, text=f"Set a new password for {account['username']}").pack(anchor="w")
        password = self.add_entry(form, "New password (minimum 8 characters)", show="*")
        error = ctk.CTkLabel(form, text="", text_color=RED)
        error.pack(anchor="w", pady=8)

        def save():
            success, message = reset_user_password(
                self.user, account["id"], password.get()
            )
            if not success:
                error.configure(text=message)
                return
            dialog.destroy()
            self.set_status(message, True)

        ctk.CTkButton(form, text="Update Password", command=save).pack(anchor="e")

    def toggle_active(self, account):
        active = not account["is_active"]
        success, message = set_user_active(self.user, account["id"], active)
        if success:
            self.refresh()
            self.set_status(message, True)
        else:
            self.set_status(message)

    def show_purchase(self, purchase_id):
        try:
            purchase = get_purchase_details(self.user, purchase_id)
            currency = get_public_settings()["currency_symbol"]
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.set_status(f"Could not load purchase details: {error}")
            return
        if purchase is None:
            self.set_status("Purchase no longer exists.")
            return
        dialog = self.open_dialog(
            f"Purchase {purchase['purchase_ref']}", "650x520"
        )
        ctk.CTkLabel(
            dialog,
            text=f"{purchase['purchase_ref']}  ·  {purchase['supplier']}  ·  "
                 f"{purchase['status'].upper()}",
            font=("Segoe UI", 18, "bold"), text_color=NAVY
        ).pack(anchor="w", padx=20, pady=(18, 6))
        ctk.CTkLabel(
            dialog,
            text=f"Created: {purchase['created_at']}  ·  Received: "
                 f"{purchase['received_at'] or 'Not received'}\n{purchase['notes']}",
            justify="left", text_color=MUTED, anchor="w"
        ).pack(fill="x", padx=20, pady=(0, 10))
        self.make_table(
            dialog,
            ("Product", "SKU", "Qty", "Unit cost", "Line total"),
            [
                (
                    item["product_name"], item["sku"], item["quantity"],
                    f"{currency}{item['unit_cost']:,.2f}",
                    f"{currency}{item['line_total']:,.2f}"
                )
                for item in purchase["items"]
            ]
        )
        ctk.CTkLabel(
            dialog, text=f"Total: {currency}{purchase['total_amount']:,.2f}",
            font=("Segoe UI", 14, "bold"), text_color=NAVY
        ).pack(anchor="e", padx=20, pady=10)


class CategoryManagementPage(_AdminPage):
    def __init__(self, master, user):
        super().__init__(master, user, "Categories")
        ctk.CTkButton(
            self.action_area, text="+ Add Category", command=self.add_category
        ).pack(side="right")
        self.refresh()

    def refresh(self):
        for child in self.body.winfo_children():
            child.destroy()
        try:
            categories = list_categories(self.user, include_inactive=True)
        except (sqlite3.Error, PermissionError) as error:
            self.set_status(f"Could not load categories: {error}")
            return
        for category_id, name, active in categories:
            row = ctk.CTkFrame(self.body, fg_color="#F8FAFC", corner_radius=6)
            row.pack(fill="x", padx=12, pady=4)
            ctk.CTkLabel(row, text=name, text_color="#334155", anchor="w").pack(
                side="left", expand=True, fill="x", padx=10, pady=8
            )
            if active:
                ctk.CTkButton(
                    row, text="Rename", width=80,
                    command=lambda cid=category_id, value=name: self.rename(cid, value)
                ).pack(side="right", padx=4)
            ctk.CTkButton(
                row, text="Deactivate" if active else "Activate", width=90,
                fg_color="#B45309" if active else GREEN,
                command=lambda cid=category_id, state=not active: self.toggle(cid, state)
            ).pack(side="right", padx=4)
        if not categories:
            ctk.CTkLabel(self.body, text="No categories found.").pack(pady=20)
        self.set_status(f"{len(categories)} active category(s).", True)

    def add_category(self):
        dialog = self.open_dialog("Add Category", "420x250")
        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=22, pady=18)
        entry = self.add_entry(form, "Category name")
        error = ctk.CTkLabel(form, text="", text_color=RED)
        error.pack(anchor="w", pady=5)

        def save():
            success, message = create_category(self.user, entry.get())
            if success:
                dialog.destroy()
                self.refresh()
                self.set_status(message, True)
            else:
                error.configure(text=message)

        ctk.CTkButton(form, text="Save Category", command=save).pack(anchor="e")

    def rename(self, category_id, current_name):
        dialog = self.open_dialog("Rename Category", "420x250")
        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=22, pady=18)
        entry = self.add_entry(form, "Category name", current_name)
        error = ctk.CTkLabel(form, text="", text_color=RED)
        error.pack(anchor="w", pady=5)

        def save():
            success, message = rename_category(self.user, category_id, entry.get())
            if success:
                dialog.destroy()
                self.refresh()
                self.set_status(message, True)
            else:
                error.configure(text=message)

        ctk.CTkButton(form, text="Save", command=save).pack(anchor="e")

    def deactivate(self, category_id):
        if not messagebox.askyesno("Deactivate category", "Deactivate this category?", parent=self):
            return
        success, message = deactivate_category(self.user, category_id)
        if success:
            self.refresh()
            self.set_status(message, True)
        else:
            self.set_status(message)

    def toggle(self, category_id, active):
        if not active and not messagebox.askyesno(
            "Deactivate category", "Deactivate this category?", parent=self
        ):
            return
        success, message = set_category_active(self.user, category_id, active)
        if success:
            self.refresh()
            self.set_status(message, True)
        else:
            self.set_status(message)


class SupplierManagementPage(_AdminPage):
    def __init__(self, master, user):
        super().__init__(master, user, "Suppliers")
        ctk.CTkButton(
            self.action_area, text="+ Add Supplier", command=self.open_supplier_form
        ).pack(side="right")
        self.refresh()

    def refresh(self):
        for child in self.body.winfo_children():
            child.destroy()
        try:
            suppliers = list_purchase_suppliers(self.user)
        except (sqlite3.Error, PermissionError) as error:
            self.set_status(f"Could not load suppliers: {error}")
            return
        for supplier in suppliers:
            row = ctk.CTkFrame(self.body, fg_color="#F8FAFC", corner_radius=6)
            row.pack(fill="x", padx=12, pady=4)
            text = f"{supplier['name']}  ·  {supplier['contact_name']}  ·  {supplier['phone']}  ·  {supplier['email']}"
            if not supplier["is_active"]:
                text += "  ·  INACTIVE"
            ctk.CTkLabel(row, text=text, anchor="w", text_color="#334155").pack(
                side="left", expand=True, fill="x", padx=10, pady=8
            )
            ctk.CTkButton(
                row, text="Edit", width=60,
                command=lambda item=supplier: self.open_supplier_form(item)
            ).pack(side="right", padx=4)
            ctk.CTkButton(
                row,
                text="Deactivate" if supplier["is_active"] else "Activate",
                width=90, fg_color="#B45309" if supplier["is_active"] else GREEN,
                command=lambda sid=supplier["id"], state=not supplier["is_active"]:
                    self.toggle_supplier(sid, state)
            ).pack(side="right", padx=4)
        if not suppliers:
            ctk.CTkLabel(self.body, text="No suppliers found.").pack(pady=20)
        self.set_status(f"{len(suppliers)} active supplier(s).", True)

    def open_supplier_form(self, supplier=None):
        dialog = self.open_dialog("Edit Supplier" if supplier else "Add Supplier", "520x600")
        form = ctk.CTkScrollableFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=18, pady=12)
        fields = {}
        for field, label in (
            ("name", "Supplier name"), ("contact_name", "Contact name"),
            ("phone", "Phone"), ("email", "Email"), ("address", "Address")
        ):
            fields[field] = self.add_entry(
                form, label, supplier[field] if supplier else ""
            )
        error = ctk.CTkLabel(form, text="", text_color=RED, wraplength=450)
        error.pack(anchor="w", pady=8)

        def save():
            values = {field: entry.get() for field, entry in fields.items()}
            success, message = save_supplier(
                self.user, values, supplier["id"] if supplier else None
            )
            if success:
                dialog.destroy()
                self.refresh()
                self.set_status(message, True)
            else:
                error.configure(text=message)

        ctk.CTkButton(form, text="Save Supplier", command=save).pack(anchor="e")

    def toggle_supplier(self, supplier_id, active):
        success, message = set_supplier_active(self.user, supplier_id, active)
        if success:
            self.refresh()
            self.set_status(message, True)
        else:
            self.set_status(message)


class PurchaseManagementPage(_AdminPage):
    def __init__(self, master, user):
        super().__init__(master, user, "Purchases & Stock Receiving")
        ctk.CTkButton(
            self.action_area, text="+ New Purchase", command=self.open_purchase_form
        ).pack(side="right")
        self.search = ctk.CTkEntry(
            self, height=36, placeholder_text="Search purchase reference or supplier"
        )
        self.search.pack(fill="x", pady=(0, 8))
        self.search.bind("<Return>", lambda _event: self.refresh())
        self.refresh()

    def refresh(self):
        for child in self.body.winfo_children():
            child.destroy()
        try:
            purchases = list_purchases(self.user, self.search.get())
            currency = get_public_settings()["currency_symbol"]
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.set_status(f"Could not load purchases: {error}")
            return
        for purchase in purchases:
            row = ctk.CTkFrame(self.body, fg_color="#F8FAFC", corner_radius=6)
            row.pack(fill="x", padx=12, pady=4)
            info = (
                f"{purchase['purchase_ref']}  ·  {purchase['supplier']}  ·  "
                f"{purchase['status'].upper()}  ·  {currency}{purchase['total_amount']:,.2f}"
            )
            ctk.CTkLabel(row, text=info, anchor="w", text_color="#334155").pack(
                side="left", expand=True, fill="x", padx=10, pady=8
            )
            if purchase["status"] == "draft":
                ctk.CTkButton(
                    row, text="Receive", width=80, fg_color=GREEN,
                    command=lambda pid=purchase["id"]: self.receive(pid)
                ).pack(side="right", padx=4)
                ctk.CTkButton(
                    row, text="Details", width=70, fg_color="#64748B",
                    command=lambda pid=purchase["id"]: self.show_purchase(pid)
                ).pack(side="right", padx=4)
        if not purchases:
            ctk.CTkLabel(self.body, text="No purchases found.").pack(pady=20)
        self.set_status(f"{len(purchases)} purchase record(s).", True)

    def open_purchase_form(self):
        try:
            suppliers = list_purchase_suppliers(self.user)
            products = (
                get_manager_products(self.user)
                if self.user.get("role") == "manager"
                else get_all_products()
            )
        except (sqlite3.Error, PermissionError) as error:
            self.set_status(f"Could not load purchase form data: {error}")
            return
        if not suppliers or not products:
            self.set_status("Add at least one active supplier and product before creating a purchase.")
            return
        dialog = self.open_dialog("New Purchase", "700x700")
        form = ctk.CTkScrollableFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=18, pady=12)
        reference = self.add_entry(form, "Purchase reference")
        supplier_names = [f"{s['id']} · {s['name']}" for s in suppliers]
        ctk.CTkLabel(form, text="Supplier", text_color="#334155").pack(anchor="w", pady=(8, 3))
        supplier_menu = ctk.CTkOptionMenu(form, values=supplier_names)
        supplier_menu.pack(fill="x")
        ctk.CTkLabel(form, text="Product", text_color="#334155").pack(anchor="w", pady=(8, 3))
        product_map = {
            f"{product[0]} · {product[1]} ({product[2]})": product
            for product in products
        }
        product_menu = ctk.CTkOptionMenu(form, values=list(product_map))
        product_menu.pack(fill="x")
        item_row = ctk.CTkFrame(form, fg_color="transparent")
        item_row.pack(fill="x", pady=8)
        quantity = self.add_entry(item_row, "Quantity", "1")
        quantity.pack_configure(side="left", expand=True, fill="x", padx=(0, 8))
        unit_cost = self.add_entry(item_row, "Unit cost", "0")
        unit_cost.pack_configure(side="left", expand=True, fill="x")
        cart = {}
        cart_label = ctk.CTkLabel(form, text="No items added.", anchor="w", justify="left")
        cart_label.pack(fill="x", pady=10)
        error = ctk.CTkLabel(form, text="", text_color=RED, wraplength=600)
        error.pack(fill="x", pady=5)

        def add_item():
            try:
                selected = product_map[product_menu.get()]
                qty = int(quantity.get().strip())
                cost = float(unit_cost.get().strip())
                if qty <= 0 or cost < 0:
                    raise ValueError
                if selected[0] in cart:
                    raise ValueError("This product is already in the purchase.")
            except (KeyError, TypeError, ValueError):
                error.configure(text="Enter a positive whole quantity and a non-negative unit cost; do not add the same product twice.")
                return
            cart[selected[0]] = {
                "product_id": selected[0],
                "quantity": qty,
                "unit_cost": cost,
                "name": selected[1],
                "sku": selected[2],
            }
            cart_label.configure(text="\n".join(
                f"{item['name']} ({item['sku']}): {item['quantity']} × ₹{item['unit_cost']:,.2f}"
                for item in cart.values()
            ))
            error.configure(text="")

        ctk.CTkButton(form, text="Add Product to Purchase", command=add_item).pack(anchor="w")
        notes = self.add_entry(form, "Notes")

        def save():
            if not cart:
                error.configure(text="Add at least one product.")
                return
            try:
                supplier_id = int(supplier_menu.get().split(" · ", 1)[0])
            except (ValueError, IndexError):
                error.configure(text="Choose a valid supplier.")
                return
            items = [
                {key: item[key] for key in ("product_id", "quantity", "unit_cost")}
                for item in cart.values()
            ]
            success, message, _ = create_purchase(
                self.user, reference.get(), supplier_id, items, notes.get()
            )
            if not success:
                error.configure(text=message)
                return
            dialog.destroy()
            self.refresh()
            self.set_status(message, True)

        ctk.CTkButton(form, text="Save Purchase Draft", command=save).pack(anchor="e", pady=12)

    def receive(self, purchase_id):
        if not messagebox.askyesno(
            "Receive purchase",
            "Confirm goods received? Stock will be increased and cannot be received again.",
            parent=self
        ):
            return
        success, message = receive_purchase(self.user, purchase_id)
        if success:
            self.refresh()
            self.set_status(message, True)
        else:
            self.set_status(message)


class SettingsPage(_AdminPage):
    def __init__(self, master, user):
        super().__init__(master, user, "Application Settings")
        self.fields = {}
        self.field_specs = (
            ("business_name", "Business name"),
            ("business_address", "Business address"),
            ("business_phone", "Business phone"),
            ("business_email", "Business email"),
            ("currency_symbol", "Currency symbol"),
            ("default_gst_percent", "Default GST (%)"),
            ("invoice_prefix", "Invoice prefix"),
            ("minimum_stock_default", "Default minimum stock"),
        )
        self.refresh()

    def refresh(self):
        for child in self.body.winfo_children():
            child.destroy()
        self.fields.clear()
        try:
            settings = get_admin_settings(self.user)
        except (sqlite3.Error, PermissionError) as error:
            self.set_status(f"Could not load settings: {error}")
            return
        form = ctk.CTkFrame(self.body, fg_color="transparent")
        form.pack(fill="x", padx=24, pady=20)
        for key, label in self.field_specs:
            self.fields[key] = self.add_entry(form, label, settings[key])
        error = ctk.CTkLabel(form, text="", text_color=RED, wraplength=600)
        error.pack(fill="x", pady=10)

        def save():
            values = {key: field.get() for key, field in self.fields.items()}
            success, message = update_settings(self.user, values)
            if success:
                self.set_status(message, True)
            else:
                error.configure(text=message)

        ctk.CTkButton(form, text="Save Settings", command=save).pack(anchor="e", pady=10)


class ReportsPage(_AdminPage):
    _EXPORTS = (
        ("daily_sales", "Daily sales"),
        ("top_products", "Top products"),
        ("low_stock", "Low stock"),
        ("purchases", "Purchases"),
        ("categories", "Category summary"),
    )

    def __init__(self, master, user):
        super().__init__(master, user, "Reports & Analytics")
        range_row = ctk.CTkFrame(self.action_area, fg_color="transparent")
        range_row.pack(side="right")
        today = date.today()
        self.start_date = ctk.CTkEntry(range_row, width=105, placeholder_text="YYYY-MM-DD")
        self.start_date.insert(0, today.replace(day=1).isoformat())
        self.start_date.pack(side="left", padx=3)
        self.end_date = ctk.CTkEntry(range_row, width=105, placeholder_text="YYYY-MM-DD")
        self.end_date.insert(0, today.isoformat())
        self.end_date.pack(side="left", padx=3)
        for label, days in (("Today", 0), ("Week", 7), ("Month", 30)):
            ctk.CTkButton(
                range_row, text=label, width=55,
                command=lambda span=days: self.set_date_range(span)
            ).pack(side="left", padx=2)
        ctk.CTkButton(
            range_row, text="Run", width=55, command=self.refresh
        ).pack(side="left", padx=3)
        self.refresh()

    def set_date_range(self, period_days):
        today = date.today()
        if period_days == 0:
            start = end = today
        elif period_days == 7:
            start = today - timedelta(days=today.weekday())
            end = today
        else:
            start = today.replace(day=1)
            end = today
        self.start_date.delete(0, "end")
        self.start_date.insert(0, start.isoformat())
        self.end_date.delete(0, "end")
        self.end_date.insert(0, end.isoformat())
        self.refresh()

    def refresh(self):
        for child in self.body.winfo_children():
            child.destroy()
        try:
            report = get_reports(
                self.user, self.start_date.get().strip(), self.end_date.get().strip()
            )
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.set_status(f"Could not build report: {error}")
            return
        summary = report["sales_summary"]
        valuation = report["stock_valuation"]
        currency = report["currency_symbol"]
        cards = (
            ("Invoices", summary["invoice_count"]),
            ("Sales total", f"{currency}{summary['total_amount']:,.2f}"),
            ("GST collected", f"{currency}{summary['tax_amount']:,.2f}"),
            ("Stock cost value", f"{currency}{valuation['cost_value']:,.2f}"),
        )
        card_row = ctk.CTkFrame(self.body, fg_color="transparent")
        card_row.pack(fill="x", padx=12, pady=(12, 3))
        for title, value in cards:
            card = ctk.CTkFrame(card_row, fg_color="#F4F7FB", corner_radius=8)
            card.pack(side="left", expand=True, fill="x", padx=4)
            ctk.CTkLabel(card, text=title, text_color=MUTED).pack(anchor="w", padx=12, pady=(10, 3))
            ctk.CTkLabel(card, text=str(value), text_color=NAVY, font=("Segoe UI", 17, "bold")).pack(
                anchor="w", padx=12, pady=(0, 10)
            )
        datasets = (
            ("Daily sales", "daily_sales", ("Date", "Invoices", "Total"),
             lambda r: (r["date"], r["invoice_count"], f"{currency}{r['total_amount']:,.2f}")),
            ("Top products", "top_products", ("Product", "SKU", "Qty sold", "Sales total"),
             lambda r: (r["product_name"], r["sku"], r["quantity_sold"], f"{currency}{r['sales_total']:,.2f}")),
            ("Low-stock products", "low_stock", ("Product", "SKU", "Stock", "Minimum"),
             lambda r: (r["product_name"], r["sku"], r["stock_quantity"], r["minimum_stock"])),
            ("Purchases", "purchases", ("Reference", "Supplier", "Status", "Total"),
             lambda r: (r["purchase_ref"], r["supplier"], r["status"], f"{currency}{r['total_amount']:,.2f}")),
            ("Category summary", "categories", ("Category", "Active products"),
             lambda r: (r["name"], r["product_count"])),
        )
        for title, key, headings, convert in datasets:
            section = ctk.CTkFrame(self.body, fg_color="#FFFFFF")
            section.pack(fill="x", padx=10, pady=4)
            top = ctk.CTkFrame(section, fg_color="transparent")
            top.pack(fill="x", padx=5, pady=(5, 0))
            ctk.CTkLabel(top, text=title, text_color=NAVY, font=("Segoe UI", 15, "bold")).pack(side="left")
            ctk.CTkButton(
                top, text="Export CSV", width=90,
                command=lambda report_type=key, report_name=title: self.export(report_type, report_name)
            ).pack(side="right")
            self.make_table(section, headings, [convert(row) for row in report[key]])
        self.set_status(
            f"Reports for {report['start_date']} through {report['end_date']}. "
            f"Inventory: {valuation['product_count']} active products, "
            f"{valuation['stock_quantity']} units; selling value {currency}{valuation['selling_value']:,.2f}.",
            True
        )

    def export(self, report_type, title):
        destination = filedialog.asksaveasfilename(
            parent=self, title=f"Export {title}",
            defaultextension=".csv", filetypes=[("CSV files", "*.csv")]
        )
        if not destination:
            return
        try:
            count = export_report_csv(
                self.user, report_type, self.start_date.get().strip(),
                self.end_date.get().strip(), destination
            )
        except (OSError, sqlite3.Error, PermissionError, ValueError) as error:
            self.set_status(f"CSV export failed: {error}")
            return
        self.set_status(f"Exported {count} {title.lower()} row(s) to {destination}.", True)
