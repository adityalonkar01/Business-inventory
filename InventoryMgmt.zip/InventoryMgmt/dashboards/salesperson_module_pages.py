import sqlite3
from datetime import date
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services.sales_service import (
    export_salesperson_report_csv,
    get_salesperson_dashboard_statistics,
    get_salesperson_report,
)


class SalespersonDashboardPage(ctk.CTkFrame):
    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        heading = ctk.CTkFrame(self, fg_color="transparent")
        heading.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        heading.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            heading,
            text="Salesperson Dashboard",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D",
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(
            heading,
            text="Refresh",
            width=90,
            command=self.refresh,
        ).grid(row=0, column=1, sticky="e")
        self.content = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.content.grid(row=1, column=0, sticky="nsew")
        for column in range(4):
            self.content.grid_columnconfigure(column, weight=1)
        self.refresh()

    def refresh(self):
        for widget in self.content.winfo_children():
            widget.destroy()
        try:
            statistics = get_salesperson_dashboard_statistics(self.user)
        except (sqlite3.Error, PermissionError, ValueError) as error:
            ctk.CTkLabel(
                self.content,
                text=f"Unable to load sales dashboard: {error}",
                text_color="#B42318",
                wraplength=700,
            ).grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=10)
            return

        currency = statistics["currency_symbol"]
        values = (
            ("Today's sales", f'{currency}{statistics["today_sales"]:,.2f}'),
            ("Invoices today", f'{statistics["today_invoice_count"]:,}'),
            ("Items sold today", f'{statistics["today_items_sold"]:,}'),
            ("Sales this week", f'{currency}{statistics["weekly_sales"]:,.2f}'),
            ("Sales this month", f'{currency}{statistics["monthly_sales"]:,.2f}'),
        )
        for index, (title, value) in enumerate(values):
            row, column = divmod(index, 4)
            card = ctk.CTkFrame(
                self.content,
                fg_color="#FFFFFF",
                corner_radius=10,
                border_width=1,
                border_color="#E2E8F0",
            )
            card.grid(row=row, column=column, sticky="ew", padx=5, pady=5)
            ctk.CTkLabel(
                card,
                text=title,
                font=("Segoe UI", 12),
                text_color="#526581",
                anchor="w",
            ).pack(fill="x", padx=14, pady=(12, 3))
            ctk.CTkLabel(
                card,
                text=value,
                font=("Segoe UI", 20, "bold"),
                text_color="#172B4D",
                anchor="w",
            ).pack(fill="x", padx=14, pady=(0, 12))

        self._add_section(
            self.content,
            "Recent transactions",
            [
                (
                    f"{sale['invoice_number']}  |  {sale['created_at']}  |  "
                    f"{sale['item_count']} item(s)  |  "
                    f"{sale['currency_symbol']}{sale['total_amount']:,.2f}"
                )
                for sale in statistics["recent_transactions"]
            ],
            row=2,
            column=0,
        )
        self._add_section(
            self.content,
            "Low-stock products",
            [
                (
                    f"{item['product_name']} ({item['sku']})  |  "
                    f"{item['stock_quantity']} available / "
                    f"minimum {item['minimum_stock']}"
                )
                for item in statistics["low_stock"]
            ],
            row=2,
            column=2,
        )

    @staticmethod
    def _add_section(master, title, items, row, column):
        section = ctk.CTkFrame(master, fg_color="#FFFFFF", corner_radius=10)
        section.grid(
            row=row,
            column=column,
            columnspan=2,
            sticky="nsew",
            padx=5,
            pady=8,
        )
        ctk.CTkLabel(
            section,
            text=title,
            font=("Segoe UI", 15, "bold"),
            text_color="#172B4D",
        ).pack(anchor="w", padx=14, pady=(12, 6))
        if not items:
            items = ["No records to display."]
        for item in items:
            ctk.CTkLabel(
                section,
                text=item,
                font=("Segoe UI", 11),
                text_color="#526581",
                anchor="w",
                justify="left",
                wraplength=520,
            ).pack(fill="x", padx=14, pady=3)
        ctk.CTkFrame(section, height=8, fg_color="transparent").pack()


class SalespersonReportsPage(ctk.CTkFrame):
    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(
            self,
            text="My Sales Reports",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D",
        ).grid(row=0, column=0, sticky="w", padx=8, pady=(4, 12))

        filters = ctk.CTkFrame(self, fg_color="transparent")
        filters.grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 10))
        filters.grid_columnconfigure(1, weight=1)
        filters.grid_columnconfigure(3, weight=1)
        today = date.today()
        month_start = today.replace(day=1).isoformat()
        self.start_date = ctk.CTkEntry(
            filters, placeholder_text="Start date (YYYY-MM-DD)", height=36
        )
        self.start_date.insert(0, month_start)
        self.start_date.grid(row=0, column=0, columnspan=2, sticky="ew", padx=(0, 6))
        self.end_date = ctk.CTkEntry(
            filters, placeholder_text="End date (YYYY-MM-DD)", height=36
        )
        self.end_date.insert(0, today.isoformat())
        self.end_date.grid(row=0, column=2, columnspan=2, sticky="ew", padx=6)
        ctk.CTkButton(
            filters, text="Load", width=80, command=self.refresh
        ).grid(row=0, column=4, padx=6)

        self.content = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.content.grid(row=2, column=0, sticky="nsew")
        self.content.grid_columnconfigure(0, weight=1)
        self.status = ctk.CTkLabel(self, text="", anchor="w")
        self.status.grid(row=3, column=0, sticky="ew", padx=8, pady=(6, 0))
        self.refresh()

    def refresh(self):
        try:
            report = get_salesperson_report(
                self.user,
                self.start_date.get().strip(),
                self.end_date.get().strip(),
            )
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.status.configure(
                text=f"Unable to load report: {error}",
                text_color="#B42318",
            )
            return

        for widget in self.content.winfo_children():
            widget.destroy()
        summary = report["summary"]
        currency = report["currency_symbol"]
        cards = (
            ("Invoices", summary["invoice_count"]),
            ("Items sold", summary["items_sold"]),
            ("Discounts", f'{currency}{summary["discount_amount"]:,.2f}'),
            ("GST", f'{currency}{summary["tax_amount"]:,.2f}'),
            ("Net sales", f'{currency}{summary["total_amount"]:,.2f}'),
        )
        card_row = ctk.CTkFrame(self.content, fg_color="transparent")
        card_row.grid(row=0, column=0, sticky="ew")
        for column in range(len(cards)):
            card_row.grid_columnconfigure(column, weight=1)
        for column, (title, value) in enumerate(cards):
            card = ctk.CTkFrame(card_row, fg_color="#FFFFFF", corner_radius=9)
            card.grid(row=0, column=column, sticky="ew", padx=4, pady=4)
            ctk.CTkLabel(
                card,
                text=title,
                font=("Segoe UI", 11),
                text_color="#526581",
            ).pack(anchor="w", padx=10, pady=(10, 3))
            ctk.CTkLabel(
                card,
                text=f"{value:,}" if isinstance(value, int) else str(value),
                font=("Segoe UI", 16, "bold"),
                text_color="#172B4D",
            ).pack(anchor="w", padx=10, pady=(0, 10))

        exports = ctk.CTkFrame(self.content, fg_color="transparent")
        exports.grid(row=1, column=0, sticky="ew", pady=(4, 8))
        for report_type, label in (
            ("daily_sales", "Export daily sales"),
            ("top_products", "Export best sellers"),
            ("sales_history", "Export invoice history"),
        ):
            ctk.CTkButton(
                exports,
                text=label,
                command=lambda kind=report_type: self.export(kind),
            ).pack(side="left", padx=(0, 8))

        self._add_table(
            self.content,
            "Daily sales",
            ("Date", "Invoices", "Total"),
            [
                (row["date"], row["invoice_count"],
                 f'{currency}{row["total_amount"]:,.2f}')
                for row in report["daily_sales"]
            ],
            row=2,
        )
        self._add_table(
            self.content,
            "Best-selling products",
            ("Product", "SKU", "Units", "Sales"),
            [
                (
                    row["product_name"],
                    row["sku"],
                    row["quantity_sold"],
                    f'{currency}{row["sales_total"]:,.2f}',
                )
                for row in report["top_products"]
            ],
            row=3,
        )
        self._add_table(
            self.content,
            "My invoice history",
            ("Invoice", "Date", "Items", "Total"),
            [
                (
                    row["invoice_number"],
                    row["created_at"],
                    row["item_count"],
                    f'{row["currency_symbol"]}{row["total_amount"]:,.2f}',
                )
                for row in report["sales_history"]
            ],
            row=4,
        )
        self.status.configure(
            text=f"Showing your sales from {report['start_date']} to {report['end_date']}.",
            text_color="#526581",
        )

    def export(self, report_type):
        target = filedialog.asksaveasfilename(
            parent=self,
            title="Export my sales report",
            defaultextension=".csv",
            filetypes=(("CSV file", "*.csv"),),
        )
        if not target:
            return
        try:
            count = export_salesperson_report_csv(
                self.user,
                report_type,
                self.start_date.get().strip(),
                self.end_date.get().strip(),
                target,
            )
        except (OSError, PermissionError, ValueError, sqlite3.Error) as error:
            messagebox.showerror("Sales report", str(error), parent=self)
            return
        messagebox.showinfo(
            "Sales report",
            f"Exported {count} record(s).",
            parent=self,
        )

    @staticmethod
    def _add_table(master, title, headers, rows, row):
        table = ctk.CTkFrame(master, fg_color="#FFFFFF", corner_radius=9)
        table.grid(row=row, column=0, sticky="ew", padx=4, pady=6)
        for column in range(len(headers)):
            table.grid_columnconfigure(column, weight=1)
        ctk.CTkLabel(
            table,
            text=title,
            font=("Segoe UI", 14, "bold"),
            text_color="#172B4D",
        ).grid(
            row=0,
            column=0,
            columnspan=len(headers),
            sticky="w",
            padx=10,
            pady=(10, 6),
        )
        for column, header in enumerate(headers):
            ctk.CTkLabel(
                table,
                text=header,
                font=("Segoe UI", 11, "bold"),
                text_color="#526581",
                anchor="w",
            ).grid(row=1, column=column, sticky="ew", padx=10, pady=5)
        if not rows:
            ctk.CTkLabel(
                table,
                text="No records for this date range.",
                text_color="#718096",
            ).grid(
                row=2,
                column=0,
                columnspan=len(headers),
                sticky="w",
                padx=10,
                pady=8,
            )
        for row_index, values in enumerate(rows, start=2):
            for column, value in enumerate(values):
                ctk.CTkLabel(
                    table,
                    text=str(value),
                    text_color="#334155",
                    anchor="w",
                ).grid(
                    row=row_index,
                    column=column,
                    sticky="ew",
                    padx=10,
                    pady=4,
                )
