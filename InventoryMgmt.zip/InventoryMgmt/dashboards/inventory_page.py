import sqlite3

import customtkinter as ctk

from services.inventory_service import (
    adjust_stock,
    can_manage_inventory,
    get_current_stock,
    get_inventory_summary,
    get_stock_movement_history,
    receive_stock
)


class InventoryPage(ctk.CTkFrame):
    """Shared inventory view for admin, manager, and read-only salesperson use."""

    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.can_manage = can_manage_inventory(user)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self._build_page()
        self.refresh_inventory()

    def _build_page(self):
        heading = ctk.CTkFrame(self, fg_color="transparent")
        heading.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        heading.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            heading,
            text="Inventory Overview",
            font=("Segoe UI", 23, "bold"),
            text_color="#172B4D"
        ).grid(row=0, column=0, sticky="w")

        ctk.CTkButton(
            heading,
            text="Stock Movement History",
            width=190,
            height=36,
            command=self.show_movement_history
        ).grid(row=0, column=1, sticky="e")

        self.summary_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.summary_frame.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        for column in range(3):
            self.summary_frame.grid_columnconfigure(column, weight=1, uniform="inventory_cards")

        self.alert_label = ctk.CTkLabel(
            self,
            text="",
            height=36,
            corner_radius=8,
            font=("Segoe UI", 13, "bold"),
            text_color="#92400E",
            fg_color="#FEF3C7",
            anchor="w"
        )
        self.alert_label.grid(row=2, column=0, sticky="ew", pady=(0, 10))

        search_row = ctk.CTkFrame(self, fg_color="transparent")
        search_row.grid(row=3, column=0, sticky="nsew")
        search_row.grid_columnconfigure(0, weight=1)
        search_row.grid_rowconfigure(2, weight=1)

        self.search_entry = ctk.CTkEntry(
            search_row,
            placeholder_text="Search inventory by product name or SKU",
            height=38
        )
        self.search_entry.grid(row=0, column=0, sticky="ew")
        self.search_entry.bind("<Return>", lambda _event: self.refresh_inventory())

        ctk.CTkButton(
            search_row,
            text="Search",
            width=90,
            height=38,
            command=self.refresh_inventory
        ).grid(row=0, column=1, padx=(8, 0))
        ctk.CTkButton(
            search_row,
            text="Clear",
            width=75,
            height=38,
            fg_color="#64748B",
            hover_color="#475569",
            command=self.clear_search
        ).grid(row=0, column=2, padx=(8, 0))

        self.status_label = ctk.CTkLabel(
            search_row,
            text="",
            anchor="w",
            font=("Segoe UI", 12),
            text_color="#526581"
        )
        self.status_label.grid(row=1, column=0, columnspan=3, sticky="ew", pady=7)

        self.table = ctk.CTkFrame(
            search_row,
            corner_radius=10,
            fg_color="#FFFFFF",
            border_width=1,
            border_color="#E2E8F0"
        )
        self.table.grid(row=2, column=0, columnspan=3, sticky="nsew")

        self.columns = [
            ("Product", 3),
            ("SKU", 2),
            ("Category", 2),
            ("Current Stock", 1),
            ("Minimum", 1),
            ("Status", 2)
        ]
        if self.can_manage:
            self.columns.append(("Stock Actions", 2))

        for column, (title, weight) in enumerate(self.columns):
            self.table.grid_columnconfigure(column, weight=weight, uniform="inventory_table")
            ctk.CTkLabel(
                self.table,
                text=title,
                font=("Segoe UI", 12, "bold"),
                text_color="#526581",
                anchor="w"
            ).grid(row=0, column=column, sticky="ew", padx=9, pady=12)

        self.rows_frame = ctk.CTkScrollableFrame(
            self.table,
            fg_color="#FFFFFF",
            corner_radius=0
        )
        for column, (_title, weight) in enumerate(self.columns):
            self.rows_frame.grid_columnconfigure(
                column,
                weight=weight,
                uniform="inventory_table"
            )
        self.rows_frame.grid(
            row=1,
            column=0,
            columnspan=len(self.columns),
            sticky="nsew",
            padx=4,
            pady=(0, 4)
        )
        self.table.grid_rowconfigure(1, weight=1)

    def clear_search(self):
        self.search_entry.delete(0, "end")
        self.refresh_inventory()

    def refresh_inventory(self, status_message=None):
        try:
            summary = get_inventory_summary(self.user)
            products = get_current_stock(self.user, self.search_entry.get())
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.status_label.configure(
                text=f"Unable to load inventory: {error}",
                text_color="#DC2626"
            )
            return

        for widget in self.summary_frame.winfo_children():
            widget.destroy()

        summaries = (
            ("Active Products", summary["total_products"], "#2563EB"),
            ("Total Stock Quantity", summary["total_stock"], "#0891B2"),
            ("Low-Stock Products", summary["low_stock_products"], "#D97706")
        )
        for column, (title, value, accent) in enumerate(summaries):
            card = ctk.CTkFrame(
                self.summary_frame,
                corner_radius=10,
                fg_color="#FFFFFF",
                border_width=1,
                border_color="#E2E8F0"
            )
            card.grid(row=0, column=column, padx=(0 if column == 0 else 7, 7), sticky="ew")
            ctk.CTkFrame(card, height=4, fg_color=accent, corner_radius=2).pack(
                fill="x",
                padx=12,
                pady=(12, 8)
            )
            ctk.CTkLabel(
                card,
                text=title,
                font=("Segoe UI", 12),
                text_color="#718096"
            ).pack(anchor="w", padx=15, pady=(4, 3))
            ctk.CTkLabel(
                card,
                text=str(value),
                font=("Segoe UI", 23, "bold"),
                text_color="#172B4D"
            ).pack(anchor="w", padx=15, pady=(0, 13))

        low_stock_count = summary["low_stock_products"]
        self.alert_label.configure(
            text=(
                f"  Low-stock warning: {low_stock_count} product(s) are at or below minimum stock."
                if low_stock_count
                else "  Stock levels are above minimum thresholds."
            ),
            text_color="#92400E" if low_stock_count else "#166534",
            fg_color="#FEF3C7" if low_stock_count else "#DCFCE7"
        )

        for widget in self.rows_frame.winfo_children():
            widget.destroy()

        if not products:
            ctk.CTkLabel(
                self.rows_frame,
                text="No matching inventory items found.",
                font=("Segoe UI", 14),
                text_color="#718096"
            ).grid(row=0, column=0, columnspan=len(self.columns), pady=35)
        else:
            for row_index, product in enumerate(products):
                row_color = "#F8FAFC" if row_index % 2 else "#FFFFFF"
                status = (
                    "LOW STOCK"
                    if product["is_low_stock"]
                    else "In Stock"
                )
                values = (
                    product["product_name"],
                    product["sku"],
                    product["category"],
                    product["stock_quantity"],
                    product["minimum_stock"],
                    status
                )
                for column, value in enumerate(values):
                    ctk.CTkLabel(
                        self.rows_frame,
                        text=str(value),
                        font=("Segoe UI", 12, "bold" if column == 5 and product["is_low_stock"] else "normal"),
                        text_color="#B45309" if column == 5 and product["is_low_stock"] else "#334155",
                        fg_color=row_color,
                        corner_radius=4,
                        anchor="w"
                    ).grid(row=row_index, column=column, sticky="ew", padx=4, pady=3, ipady=8)

                if self.can_manage:
                    actions = ctk.CTkFrame(self.rows_frame, fg_color=row_color)
                    actions.grid(row=row_index, column=6, sticky="ew", padx=4, pady=3)
                    actions.grid_columnconfigure((0, 1), weight=1)
                    ctk.CTkButton(
                        actions,
                        text="Receive",
                        width=70,
                        height=30,
                        command=lambda item=product: self.open_stock_form(item, "receipt")
                    ).grid(row=0, column=0, padx=3, pady=4)
                    ctk.CTkButton(
                        actions,
                        text="Adjust",
                        width=70,
                        height=30,
                        fg_color="#64748B",
                        hover_color="#475569",
                        command=lambda item=product: self.open_stock_form(item, "adjustment")
                    ).grid(row=0, column=1, padx=3, pady=4)

        self.status_label.configure(
            text=status_message or f"Showing {len(products)} active product(s).",
            text_color="#15803D" if status_message else "#526581"
        )

    def open_stock_form(self, product, action):
        if not self.can_manage:
            self.status_label.configure(
                text="Your role is not authorized to manage inventory.",
                text_color="#DC2626"
            )
            return

        receiving = action == "receipt"
        dialog = ctk.CTkToplevel(self)
        dialog.title("Receive Stock" if receiving else "Stock Adjustment")
        dialog.geometry("470x330")
        dialog.minsize(430, 310)
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        ctk.CTkLabel(
            dialog,
            text="Receive stock" if receiving else "Adjust stock",
            font=("Segoe UI", 21, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=24, pady=(22, 4))
        ctk.CTkLabel(
            dialog,
            text=f"{product['product_name']}  ·  {product['sku']}  ·  Current: {product['stock_quantity']}",
            font=("Segoe UI", 12),
            text_color="#526581"
        ).pack(anchor="w", padx=24, pady=(0, 15))

        ctk.CTkLabel(
            dialog,
            text="Quantity" if receiving else "Adjustment (+ to increase, - to decrease)",
            font=("Segoe UI", 12, "bold"),
            text_color="#334155"
        ).pack(anchor="w", padx=24, pady=(0, 5))
        quantity_entry = ctk.CTkEntry(dialog, height=38)
        quantity_entry.pack(fill="x", padx=24)
        quantity_entry.focus_set()

        ctk.CTkLabel(
            dialog,
            text="Notes (optional)",
            font=("Segoe UI", 12, "bold"),
            text_color="#334155"
        ).pack(anchor="w", padx=24, pady=(13, 5))
        notes_entry = ctk.CTkEntry(dialog, height=38, placeholder_text="Reason or reference")
        notes_entry.pack(fill="x", padx=24)

        error_label = ctk.CTkLabel(
            dialog,
            text="",
            font=("Segoe UI", 12),
            text_color="#DC2626"
        )
        error_label.pack(fill="x", padx=24, pady=(4, 0))

        def save():
            try:
                quantity = int(quantity_entry.get().strip())
            except ValueError:
                error_label.configure(text="Enter a whole-number quantity.")
                return

            if receiving:
                result = receive_stock(product["id"], quantity, self.user, notes_entry.get())
            else:
                result = adjust_stock(product["id"], quantity, self.user, notes_entry.get())

            success, message = result
            if not success:
                error_label.configure(text=message)
                return
            dialog.destroy()
            self.refresh_inventory(message)

        buttons = ctk.CTkFrame(dialog, fg_color="transparent")
        buttons.pack(fill="x", padx=24, pady=(10, 18))
        ctk.CTkButton(
            buttons,
            text="Cancel",
            width=95,
            height=36,
            fg_color="#64748B",
            hover_color="#475569",
            command=dialog.destroy
        ).pack(side="right", padx=(8, 0))
        ctk.CTkButton(
            buttons,
            text="Save",
            width=95,
            height=36,
            command=save
        ).pack(side="right")

    def show_movement_history(self):
        try:
            movements = get_stock_movement_history(self.user)
        except (sqlite3.Error, PermissionError, ValueError) as error:
            self.status_label.configure(
                text=f"Unable to load stock history: {error}",
                text_color="#DC2626"
            )
            return

        dialog = ctk.CTkToplevel(self)
        dialog.title("Stock Movement History")
        dialog.geometry("1050x560")
        dialog.minsize(850, 450)
        dialog.transient(self.winfo_toplevel())

        ctk.CTkLabel(
            dialog,
            text="Stock Movement History",
            font=("Segoe UI", 21, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=20, pady=(18, 12))

        columns = [
            ("Date", 2),
            ("Product / SKU", 3),
            ("Movement", 2),
            ("Qty", 1),
            ("Before → After", 2),
            ("Performed by", 2),
            ("Notes", 3)
        ]
        table = ctk.CTkFrame(dialog, fg_color="#FFFFFF", border_width=1, border_color="#E2E8F0")
        table.pack(fill="both", expand=True, padx=20, pady=(0, 18))
        for column, (title, weight) in enumerate(columns):
            table.grid_columnconfigure(column, weight=weight, uniform="history")
            ctk.CTkLabel(
                table,
                text=title,
                font=("Segoe UI", 12, "bold"),
                text_color="#526581",
                anchor="w"
            ).grid(row=0, column=column, sticky="ew", padx=8, pady=10)

        rows = ctk.CTkScrollableFrame(table, fg_color="#FFFFFF")
        for column, (_title, weight) in enumerate(columns):
            rows.grid_columnconfigure(column, weight=weight, uniform="history")
        rows.grid(row=1, column=0, columnspan=len(columns), sticky="nsew")
        table.grid_rowconfigure(1, weight=1)

        if not movements:
            ctk.CTkLabel(
                rows,
                text="No stock movements have been recorded.",
                font=("Segoe UI", 13),
                text_color="#718096"
            ).grid(row=0, column=0, columnspan=len(columns), pady=30)
        else:
            for row_index, movement in enumerate(movements):
                values = (
                    movement["created_at"],
                    f'{movement["product_name"]}\n{movement["sku"]}',
                    (
                        "Sale"
                        if movement["movement_type"] == "sale"
                        else movement["movement_type"].replace("_", " ").title()
                    ),
                    movement["quantity"],
                    f'{movement["previous_stock"]} → {movement["new_stock"]}',
                    movement["performed_by_username"],
                    movement["notes"] or "—"
                )
                for column, value in enumerate(values):
                    ctk.CTkLabel(
                        rows,
                        text=str(value),
                        font=("Segoe UI", 11),
                        text_color="#334155",
                        anchor="w",
                        justify="left"
                    ).grid(row=row_index, column=column, sticky="ew", padx=6, pady=5, ipady=5)
