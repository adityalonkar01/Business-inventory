import sqlite3

import customtkinter as ctk

from services.dashboard_service import get_manager_statistics
from services.product_service import get_manager_products
from services.user_service import change_own_password


class ManagerOverviewPage(ctk.CTkFrame):
    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(
            self,
            text="Manager Dashboard",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D",
        ).grid(row=0, column=0, sticky="w", padx=8, pady=(4, 16))
        content = ctk.CTkScrollableFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew")
        for column in range(4):
            content.grid_columnconfigure(column, weight=1)

        try:
            statistics = get_manager_statistics(user)
        except (sqlite3.Error, PermissionError) as error:
            ctk.CTkLabel(
                content,
                text=f"Could not load manager dashboard data: {error}",
                text_color="#B42318",
                wraplength=700,
            ).grid(row=0, column=0, columnspan=4, sticky="w", padx=12, pady=12)
            return

        currency_symbol = statistics["currency_symbol"]
        cards = (
            ("Active products", statistics["total_active_products"]),
            ("Units in stock", f'{statistics["total_stock_quantity"]:,}'),
            ("Low-stock products", statistics["low_stock_product_count"]),
            (
                "Inventory valuation",
                f'{currency_symbol}{statistics["inventory_valuation"]:,.2f}',
            ),
            (
                "Today's sales",
                f'{currency_symbol}{statistics["today_sales"]:,.2f}',
            ),
            (
                "This month's sales",
                f'{currency_symbol}{statistics["monthly_sales"]:,.2f}',
            ),
            ("Transactions (7 days)", statistics["recent_transaction_count"]),
        )
        for index, (label, value) in enumerate(cards):
            row, column = divmod(index, 4)
            card = ctk.CTkFrame(content, corner_radius=12, fg_color="#FFFFFF")
            card.grid(
                row=row + 1,
                column=column,
                sticky="nsew",
                padx=6,
                pady=6,
            )
            ctk.CTkLabel(
                card,
                text=label,
                text_color="#526581",
                font=("Segoe UI", 12),
            ).pack(anchor="w", padx=14, pady=(12, 4))
            ctk.CTkLabel(
                card,
                text=str(value),
                text_color="#172B4D",
                font=("Segoe UI", 21, "bold"),
            ).pack(anchor="w", padx=14, pady=(0, 12))

        self._add_list(
            content,
            "Low-stock alerts",
            [
                f"{name} ({sku}) - {stock} in stock / minimum {minimum}"
                for _product_id, name, sku, stock, minimum
                in statistics["low_stock_alerts"]
            ],
            row=3,
            column=0,
        )
        self._add_list(
            content,
            "Recent purchases",
            [
                f"{reference} - {supplier} - {status} - {currency_symbol}{total:,.2f}"
                for reference, supplier, status, total, _created_at
                in statistics["recent_purchases"]
            ],
            row=3,
            column=2,
        )
        self._add_list(
            content,
            "Recent stock movements",
            [
                f"{name} ({sku}) - {movement} {quantity}: "
                f"{previous} -> {current} by {username}"
                for (
                    name,
                    sku,
                    movement,
                    quantity,
                    previous,
                    current,
                    username,
                    _created_at,
                ) in statistics["recent_stock_movements"]
            ],
            row=4,
            column=0,
            columnspan=4,
        )

    @staticmethod
    def _add_list(master, title, items, row, column, columnspan=2):
        section = ctk.CTkFrame(master, corner_radius=12, fg_color="#FFFFFF")
        section.grid(
            row=row,
            column=column,
            columnspan=columnspan,
            sticky="nsew",
            padx=6,
            pady=6,
        )
        ctk.CTkLabel(
            section,
            text=title,
            font=("Segoe UI", 15, "bold"),
            text_color="#172B4D",
        ).pack(anchor="w", padx=14, pady=(12, 6))
        if not items:
            items = ["No recent records."]
        for item in items:
            ctk.CTkLabel(
                section,
                text=item,
                font=("Segoe UI", 12),
                text_color="#526581",
                anchor="w",
                justify="left",
                wraplength=700,
            ).pack(fill="x", padx=14, pady=3)
        ctk.CTkFrame(section, height=8, fg_color="transparent").pack()


class ManagerProductPage(ctk.CTkFrame):
    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        ctk.CTkLabel(
            self,
            text="Products",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D",
        ).grid(row=0, column=0, sticky="w", padx=8, pady=(4, 14))
        self.search_entry = ctk.CTkEntry(
            self,
            placeholder_text="Search by product name or SKU",
            height=38,
        )
        self.search_entry.grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 10))
        self.search_entry.bind("<KeyRelease>", self.refresh)
        self.status = ctk.CTkLabel(self, text="", anchor="w")
        self.status.grid(row=3, column=0, sticky="ew", padx=8, pady=(8, 0))

        self.table = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        self.table.grid(row=2, column=0, sticky="nsew", padx=8)
        for column, weight in enumerate((1, 3, 2, 2, 2, 1, 1, 1)):
            self.table.grid_columnconfigure(column, weight=weight)
        self.refresh()

    def refresh(self, _event=None):
        for widget in self.table.winfo_children():
            widget.destroy()
        headers = (
            "ID",
            "Product",
            "SKU",
            "Category",
            "Purchase price",
            "Selling price",
            "Stock",
            "Minimum",
        )
        for column, label in enumerate(headers):
            ctk.CTkLabel(
                self.table,
                text=label,
                font=("Segoe UI", 12, "bold"),
                text_color="#172B4D",
                anchor="w",
            ).grid(row=0, column=column, sticky="ew", padx=8, pady=10)
        try:
            products = get_manager_products(self.user, self.search_entry.get())
        except (sqlite3.Error, PermissionError) as error:
            self.status.configure(
                text=f"Could not load products: {error}",
                text_color="#B42318",
            )
            return
        for row, product in enumerate(products, start=1):
            values = (
                product[0],
                product[1],
                product[2],
                product[3],
                f"{product[4]:,.2f}",
                f"{product[5]:,.2f}",
                product[6],
                product[7],
            )
            for column, value in enumerate(values):
                ctk.CTkLabel(
                    self.table,
                    text=str(value),
                    anchor="w",
                    text_color="#334155",
                ).grid(row=row, column=column, sticky="ew", padx=8, pady=6)
        self.status.configure(
            text=f"{len(products)} product(s)" if products else "No products found.",
            text_color="#526581",
        )


class AccountProfilePage(ctk.CTkFrame):
    def __init__(self, master, user):
        super().__init__(master, fg_color="transparent")
        self.user = user
        self.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self,
            text="My Profile",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D",
        ).grid(row=0, column=0, sticky="w", padx=8, pady=(4, 16))
        details = ctk.CTkFrame(self, corner_radius=12, fg_color="#FFFFFF")
        details.grid(row=1, column=0, sticky="ew", padx=8)
        ctk.CTkLabel(
            details,
            text=(
                f"Username: {user.get('username', '')}\n"
                f"Role: {user.get('role', '').title()}"
            ),
            justify="left",
            anchor="w",
            text_color="#334155",
        ).pack(fill="x", padx=18, pady=16)
        form = ctk.CTkFrame(self, corner_radius=12, fg_color="#FFFFFF")
        form.grid(row=2, column=0, sticky="ew", padx=8, pady=12)
        self.current_password = self._password_entry(form, "Current password")
        self.new_password = self._password_entry(form, "New password")
        self.confirm_password = self._password_entry(form, "Confirm new password")
        self.status = ctk.CTkLabel(form, text="", anchor="w")
        self.status.pack(fill="x", padx=18, pady=(4, 0))
        ctk.CTkButton(
            form,
            text="Change password",
            command=self.change_password,
        ).pack(anchor="w", padx=18, pady=16)

    @staticmethod
    def _password_entry(master, placeholder):
        entry = ctk.CTkEntry(
            master,
            placeholder_text=placeholder,
            show="*",
            height=38,
        )
        entry.pack(fill="x", padx=18, pady=(16, 0))
        return entry

    def change_password(self):
        success, message = change_own_password(
            self.user,
            self.current_password.get(),
            self.new_password.get(),
            self.confirm_password.get(),
        )
        self.status.configure(
            text=message,
            text_color="#15803D" if success else "#B42318",
        )
        if success:
            self.current_password.delete(0, "end")
            self.new_password.delete(0, "end")
            self.confirm_password.delete(0, "end")
