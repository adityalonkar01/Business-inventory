from dashboards.role_dashboard import InventoryRoleDashboard


class SalespersonDashboard(InventoryRoleDashboard):
    expected_role = "salesperson"
    display_title = "Salesperson"