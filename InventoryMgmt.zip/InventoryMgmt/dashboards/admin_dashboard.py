import customtkinter as ctk
import sqlite3
from tkinter import messagebox

from services.dashboard_service import get_admin_statistics
from services.product_service import (
    add_product,
    delete_product,
    get_all_products,
    search_products,
    update_product
)
from dashboards.inventory_page import InventoryPage
from dashboards.sales_page import SalesPage
from dashboards.admin_module_pages import (
    CategoryManagementPage,
    PurchaseManagementPage,
    ReportsPage,
    SettingsPage,
    SupplierManagementPage,
    UserManagementPage,
)
from services.category_service import list_categories
from services.settings_service import get_public_settings

class AdminDashboard(ctk.CTk):
    """
    Main window for the administrator.
    """

    def __init__(self, user):
        super().__init__()

        # Store the currently logged-in administrator.
        self.user = user

        # Window configuration.
        self.title("Inventory Management System | Admin")
        self.geometry("1200x750")
        self.minsize(1000, 650)

        # Application theme.
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")

        # Main background color.
        self.configure(fg_color="#F4F7FB")

        # Create the dashboard sections.
        self.create_sidebar()
        self.create_main_area()
        self.navigate("Dashboard")

    # --------------------------------------------------
    # SIDEBAR
    # --------------------------------------------------

    def create_sidebar(self):

        # The sidebar stays on the left side of the window.
        self.sidebar = ctk.CTkFrame(
            self,
            width=230,
            corner_radius=0,
            fg_color="#172B4D"
        )

        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # Application branding.
        ctk.CTkLabel(
            self.sidebar,
            text="INVENTORY",
            font=("Segoe UI", 23, "bold"),
            text_color="#FFFFFF"
        ).pack(pady=(30, 5), padx=20)

        ctk.CTkLabel(
            self.sidebar,
            text="MANAGEMENT SYSTEM",
            font=("Segoe UI", 10),
            text_color="#B8C7E0"
        ).pack(pady=(0, 35))

        navigation_frame = ctk.CTkScrollableFrame(
            self.sidebar, fg_color="transparent", corner_radius=0
        )
        navigation_frame.pack(fill="both", expand=True)

        # Sidebar navigation options.
        menu_items = [
            "Dashboard",
            "Products",
            "Inventory",
            "Sales & Billing",
            "Categories",
            "Suppliers",
            "Purchases",
            "Reports",
            "User Management",
            "Settings"
        ]

        self.navigation_buttons = {}
        for item in menu_items:

            button = ctk.CTkButton(
                navigation_frame,
                text=f"   {item}",
                height=42,
                corner_radius=8,
                anchor="w",
                font=("Segoe UI", 14),
                fg_color="#29446F" if item == "Dashboard" else "transparent",
                hover_color="#29446F",
                text_color="#FFFFFF",
                command=lambda name=item: self.navigate(name)
            )

            button.pack(fill="x", padx=15, pady=4)
            self.navigation_buttons[item] = button

        # Keep the logout button near the bottom.
        ctk.CTkButton(
            self.sidebar,
            text="Logout",
            height=42,
            corner_radius=8,
            fg_color="#C0392B",
            hover_color="#A93226",
            text_color="#FFFFFF",
            command=self.logout
        ).pack(side="bottom", fill="x", padx=15, pady=25)

    # --------------------------------------------------
    # MAIN CONTENT AREA
    # --------------------------------------------------

    def create_main_area(self):

        # This frame occupies the remaining window space.
        self.main_area = ctk.CTkFrame(
            self,
            corner_radius=0,
            fg_color="#F4F7FB"
        )

        self.main_area.pack(
            side="left",
            fill="both",
            expand=True
        )
        self.main_area.grid_columnconfigure(0, weight=1)
        self.main_area.grid_rowconfigure(1, weight=1)

        # Header at the top of the main area.
        header = ctk.CTkFrame(
            self.main_area,
            height=85,
            corner_radius=0,
            fg_color="#FFFFFF"
        )

        header.grid(row=0, column=0, sticky="ew")
        header.pack_propagate(False)

        # Dashboard heading.
        self.page_title = ctk.CTkLabel(
            header,
            text="Admin Dashboard",
            font=("Segoe UI", 25, "bold"),
            text_color="#172B4D"
        )
        self.page_title.pack(side="left", padx=30)

        # Display the current username.
        username = self.user.get("username", "Admin")

        ctk.CTkLabel(
            header,
            text=f"Administrator: {username}",
            font=("Segoe UI", 13),
            text_color="#526581"
        ).pack(side="right", padx=30)

        # Pages occupy a normal resizable host; report/settings pages provide
        # their own scroll area so nested canvases cannot constrain their height.
        self.page_host = ctk.CTkFrame(
            self.main_area,
            fg_color="#F4F7FB"
        )

        self.page_host.grid(
            row=1,
            column=0,
            sticky="nsew",
            padx=25,
            pady=20
        )
        self.page_host.grid_columnconfigure(0, weight=1)
        self.page_host.grid_rowconfigure(0, weight=1)
        self.content = self.page_host

    def show_dashboard(self):
        """Render the administrator overview."""

        self.clear_content()
        self.content = ctk.CTkScrollableFrame(
            self.page_host,
            fg_color="#F4F7FB"
        )
        self.content.grid(row=0, column=0, sticky="nsew")
        username = self.user.get("username", "Admin")

        # Welcome section.
        ctk.CTkLabel(
            self.content,
            text=f"Welcome back, {username}!",
            font=("Segoe UI", 23, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", pady=(5, 5))

        ctk.CTkLabel(
            self.content,
            text="Here is an overview of your inventory business.",
            font=("Segoe UI", 13),
            text_color="#718096"
        ).pack(anchor="w", pady=(0, 25))

        try:
            statistics = get_admin_statistics(self.user)
            currency = get_public_settings()["currency_symbol"]
        except (sqlite3.Error, PermissionError) as error:
            ctk.CTkLabel(
                self.content,
                text=f"Could not load dashboard data: {error}",
                font=("Segoe UI", 13),
                text_color="#DC2626"
            ).pack(anchor="w", pady=12)
            return
        self.create_summary_cards(statistics, currency)
        self.create_dashboard_table(
            "Recent Sales",
            ("Invoice", "Amount", "Date", "Sold by"),
            [
                (invoice, f"{currency}{amount:,.2f}", created_at, username or "")
                for invoice, amount, created_at, username in statistics["recent_sales"]
            ]
        )
        self.create_dashboard_table(
            "Best-Selling Products",
            ("Product", "SKU", "Units sold"),
            statistics["best_sellers"]
        )
        self.create_dashboard_table(
            "Low-Stock Warnings",
            ("Product", "SKU", "Stock", "Minimum"),
            statistics["low_stock_products"]
        )

    def create_dashboard_table(self, title, headers, rows):
        section = ctk.CTkFrame(
            self.content, fg_color="#FFFFFF", corner_radius=10,
            border_width=1, border_color="#E2E8F0"
        )
        section.pack(fill="x", pady=8)
        ctk.CTkLabel(
            section, text=title, font=("Segoe UI", 16, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=16, pady=(14, 5))
        table = ctk.CTkFrame(section, fg_color="transparent")
        table.pack(fill="x", padx=10, pady=(0, 12))
        for column in range(len(headers)):
            table.grid_columnconfigure(column, weight=1)
        for column, label in enumerate(headers):
            ctk.CTkLabel(
                table, text=label, font=("Segoe UI", 11, "bold"),
                text_color="#526581", anchor="w"
            ).grid(row=0, column=column, sticky="ew", padx=5, pady=5)
        if not rows:
            ctk.CTkLabel(
                table, text="No data available yet.", text_color="#718096"
            ).grid(row=1, column=0, columnspan=len(headers), sticky="w", padx=5, pady=8)
        for row_index, row in enumerate(rows, start=1):
            for column, value in enumerate(row):
                ctk.CTkLabel(
                    table, text=str(value), font=("Segoe UI", 11),
                    text_color="#334155", anchor="w"
                ).grid(row=row_index, column=column, sticky="ew", padx=5, pady=4)

    def clear_content(self):
        for widget in self.page_host.winfo_children():
            widget.destroy()
        self.content = self.page_host

    def show_products_page(self):
        """Render product search, listing, and management actions."""

        self.clear_content()

        heading = ctk.CTkFrame(self.content, fg_color="transparent")
        heading.pack(fill="x", pady=(5, 16))

        ctk.CTkLabel(
            heading,
            text="Product Management",
            font=("Segoe UI", 23, "bold"),
            text_color="#172B4D"
        ).pack(side="left")

        ctk.CTkButton(
            heading,
            text="+ Add Product",
            width=140,
            height=38,
            command=self.open_product_form
        ).pack(side="right")

        search_row = ctk.CTkFrame(self.content, fg_color="transparent")
        search_row.pack(fill="x", pady=(0, 10))

        self.product_search = ctk.CTkEntry(
            search_row,
            placeholder_text="Search by product name or SKU",
            height=38
        )
        self.product_search.pack(side="left", fill="x", expand=True)
        self.product_search.bind(
            "<Return>",
            lambda _event: self.refresh_products()
        )

        ctk.CTkButton(
            search_row,
            text="Search",
            width=90,
            height=38,
            command=self.refresh_products
        ).pack(side="left", padx=(8, 0))

        ctk.CTkButton(
            search_row,
            text="Clear",
            width=75,
            height=38,
            fg_color="#64748B",
            hover_color="#475569",
            command=self.clear_product_search
        ).pack(side="left", padx=(8, 0))

        self.product_status = ctk.CTkLabel(
            self.content,
            text="",
            font=("Segoe UI", 12),
            text_color="#526581",
            anchor="w"
        )
        self.product_status.pack(fill="x", pady=(0, 8))

        table = ctk.CTkFrame(
            self.content,
            corner_radius=10,
            fg_color="#FFFFFF",
            border_width=1,
            border_color="#E2E8F0"
        )
        table.pack(fill="both", expand=True)

        columns = [
            ("ID", 1),
            ("Product", 3),
            ("SKU", 2),
            ("Category", 2),
            ("Selling Price", 2),
            ("Stock", 1),
            ("Min. Stock", 1),
            ("Actions", 2)
        ]
        for column, (label, weight) in enumerate(columns):
            table.grid_columnconfigure(column, weight=weight, uniform="product_columns")
            ctk.CTkLabel(
                table,
                text=label,
                font=("Segoe UI", 12, "bold"),
                text_color="#526581",
                anchor="w"
            ).grid(
                row=0,
                column=column,
                sticky="ew",
                padx=8,
                pady=12
            )

        self.products_table = ctk.CTkScrollableFrame(
            table,
            fg_color="#FFFFFF",
            corner_radius=0
        )
        for column, (_label, weight) in enumerate(columns):
            self.products_table.grid_columnconfigure(
                column,
                weight=weight,
                uniform="product_columns"
            )
        self.products_table.grid(
            row=1,
            column=0,
            columnspan=len(columns),
            sticky="nsew",
            padx=4,
            pady=(0, 5)
        )
        table.grid_rowconfigure(1, weight=1)

        self.refresh_products()

    def clear_product_search(self):
        self.product_search.delete(0, "end")
        self.refresh_products()

    def refresh_products(self, status_message=None, status_color="#526581"):
        """Reload active products using the existing service functions."""

        search_text = self.product_search.get().strip()
        try:
            products = (
                search_products(search_text)
                if search_text
                else get_all_products()
            )
            currency = get_public_settings()["currency_symbol"]
        except sqlite3.Error as error:
            self.product_status.configure(
                text=f"Could not load products: {error}",
                text_color="#DC2626"
            )
            return

        for widget in self.products_table.winfo_children():
            widget.destroy()

        if not products:
            ctk.CTkLabel(
                self.products_table,
                text="No matching products found." if search_text else "No active products yet.",
                font=("Segoe UI", 14),
                text_color="#718096"
            ).grid(row=0, column=0, columnspan=8, pady=35)
        else:
            for row_index, product in enumerate(products):
                product_id, name, sku, category, _purchase, price, stock, minimum = product
                row_color = "#F8FAFC" if row_index % 2 else "#FFFFFF"
                values = (
                    product_id,
                    name,
                    sku,
                    category,
                    f"{currency}{price:,.2f}",
                    stock,
                    minimum
                )
                for column, value in enumerate(values):
                    ctk.CTkLabel(
                        self.products_table,
                        text=str(value),
                        font=("Segoe UI", 12),
                        text_color="#334155",
                        anchor="w",
                        fg_color=row_color,
                        corner_radius=4
                    ).grid(
                        row=row_index,
                        column=column,
                        sticky="ew",
                        padx=4,
                        pady=3,
                        ipady=8
                    )

                actions = ctk.CTkFrame(
                    self.products_table,
                    fg_color=row_color
                )
                actions.grid(row=row_index, column=7, sticky="ew", padx=4, pady=3)
                actions.grid_columnconfigure((0, 1), weight=1)

                ctk.CTkButton(
                    actions,
                    text="Edit",
                    width=55,
                    height=30,
                    command=lambda item=product: self.open_product_form(item)
                ).grid(row=0, column=0, padx=3, pady=4)

                ctk.CTkButton(
                    actions,
                    text="Deactivate",
                    width=85,
                    height=30,
                    fg_color="#DC2626",
                    hover_color="#B91C1C",
                    command=lambda item=product: self.confirm_deactivate(item)
                ).grid(row=0, column=1, padx=3, pady=4)

        self.product_status.configure(
            text=status_message or f"{len(products)} active product(s)",
            text_color=status_color
        )

    def open_product_form(self, product=None):
        """Open the add or edit form for a product."""

        editing = product is not None
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Product" if editing else "Add Product")
        dialog.geometry("620x500")
        dialog.minsize(560, 470)
        dialog.transient(self)
        dialog.grab_set()

        ctk.CTkLabel(
            dialog,
            text="Edit product" if editing else "Add a product",
            font=("Segoe UI", 22, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=25, pady=(22, 4))

        ctk.CTkLabel(
            dialog,
            text=(
                "Stock changes are managed from Inventory."
                if editing
                else "Enter the product details below."
            ),
            font=("Segoe UI", 12),
            text_color="#718096"
        ).pack(anchor="w", padx=25, pady=(0, 14))

        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=25)
        form.grid_columnconfigure((0, 1), weight=1, uniform="product_form")

        try:
            default_minimum_stock = get_public_settings()["minimum_stock_default"]
        except sqlite3.Error as error:
            default_minimum_stock = 5
            self.product_status.configure(
                text=f"Could not load settings; using minimum stock 5: {error}",
                text_color="#DC2626"
            )

        fields = [
            ("Product name", "product_name", 0, 0, product[1] if editing else ""),
            ("SKU", "sku", 0, 1, product[2] if editing else ""),
            ("Category", "category", 1, 0, product[3] if editing else ""),
            ("Purchase price", "purchase_price", 1, 1, product[4] if editing else "0"),
            ("Selling price", "selling_price", 2, 0, product[5] if editing else ""),
            (
                "Stock quantity (use Inventory to change)" if editing else "Stock quantity",
                "stock_quantity",
                2,
                1,
                product[6] if editing else "0"
            ),
            (
                "Minimum stock", "minimum_stock", 3, 0,
                product[7] if editing else str(default_minimum_stock)
            )
        ]
        entries = {}
        for label, field, row, column, value in fields:
            cell = ctk.CTkFrame(form, fg_color="transparent")
            cell.grid(
                row=row,
                column=column,
                sticky="ew",
                padx=(0, 10) if column == 0 else (10, 0),
                pady=6
            )
            ctk.CTkLabel(
                cell,
                text=label,
                font=("Segoe UI", 12, "bold"),
                text_color="#334155"
            ).pack(anchor="w", pady=(0, 4))
            if field == "category":
                try:
                    category_options = [
                        name for _category_id, name, _active
                        in list_categories(self.user)
                    ]
                except (sqlite3.Error, PermissionError) as error:
                    category_options = []
                    self.product_status.configure(
                        text=f"Could not load categories: {error}",
                        text_color="#DC2626"
                    )
                entry = ctk.CTkComboBox(
                    cell, height=36, values=category_options
                )
            else:
                entry = ctk.CTkEntry(cell, height=36)
            entry.pack(fill="x")
            if value != "":
                if field == "category":
                    entry.set(str(value))
                else:
                    entry.insert(0, str(value))
            if editing and field == "stock_quantity":
                entry.configure(state="disabled")
            entries[field] = entry

        error_label = ctk.CTkLabel(
            dialog,
            text="",
            font=("Segoe UI", 12),
            text_color="#DC2626"
        )
        error_label.pack(fill="x", padx=25, pady=(3, 0))

        buttons = ctk.CTkFrame(dialog, fg_color="transparent")
        buttons.pack(fill="x", padx=25, pady=(8, 20))

        def save_product():
            try:
                purchase_price = float(entries["purchase_price"].get().strip())
                selling_price = float(entries["selling_price"].get().strip())
                stock_quantity = int(entries["stock_quantity"].get().strip())
                minimum_stock = int(entries["minimum_stock"].get().strip())
            except ValueError:
                error_label.configure(
                    text="Enter valid numeric prices and whole-number stock quantities."
                )
                return

            values = (
                entries["product_name"].get(),
                entries["sku"].get(),
                entries["category"].get(),
                purchase_price,
                selling_price,
                stock_quantity,
                minimum_stock
            )
            if editing:
                success, message = update_product(product[0], *values)
            else:
                success, message = add_product(*values)

            if not success:
                error_label.configure(text=message)
                return

            dialog.destroy()
            if not editing:
                self.product_search.delete(0, "end")
            self.refresh_products(message, "#15803D")

        ctk.CTkButton(
            buttons,
            text="Cancel",
            width=100,
            height=38,
            fg_color="#64748B",
            hover_color="#475569",
            command=dialog.destroy
        ).pack(side="right", padx=(8, 0))
        ctk.CTkButton(
            buttons,
            text="Save Product",
            width=130,
            height=38,
            command=save_product
        ).pack(side="right")

    def confirm_deactivate(self, product):
        """Ask for confirmation before safely deactivating a product."""

        if not messagebox.askyesno(
            "Deactivate product",
            f"Deactivate '{product[1]}' ({product[2]})? It will no longer appear in active product lists.",
            parent=self
        ):
            return

        success, message = delete_product(product[0])
        if success:
            self.refresh_products(message, "#15803D")
        else:
            self.product_status.configure(text=message, text_color="#DC2626")

    # --------------------------------------------------
    # SUMMARY CARDS
    # --------------------------------------------------

    def create_summary_cards(self, statistics, currency):

        # Prepare the values that will appear on the cards.
        cards = [
            (
                "Total Products",
                str(statistics["total_products"]),
                "#2563EB"
            ),
            (
                "Total Stock Units",
                str(statistics["total_stock"]),
                "#0891B2"
            ),
            (
                "Low Stock Items",
                str(statistics["low_stock_items"]),
                "#D97706"
            ),
            (
                "Total Sales",
                f"{currency}{statistics['total_sales']:,.2f}",
                "#16A34A"
            ),
            (
                "Today's Sales",
                f"{currency}{statistics['today_sales']:,.2f}",
                "#7C3AED"
            ),
            (
                "Today's Invoices",
                str(statistics["today_invoice_count"]),
                "#475569"
            ),
            (
                "Inventory Cost Value",
                f"{currency}{statistics['inventory_cost_value']:,.2f}",
                "#0F766E"
            )
        ]

        # Create a container for the four cards.
        cards_frame = ctk.CTkFrame(
            self.content,
            fg_color="transparent"
        )

        cards_frame.pack(
            fill="x",
            pady=(0, 25)
        )

        # Give each card an equal amount of horizontal space.
        for column in range(4):
            cards_frame.grid_columnconfigure(
                column,
                weight=1,
                uniform="cards"
            )

        # Create the individual summary cards.
        for index, (title, value, accent) in enumerate(cards):

            card = ctk.CTkFrame(
                cards_frame,
                corner_radius=12,
                fg_color="#FFFFFF",
                border_width=1,
                border_color="#E2E8F0"
            )

            card.grid(
                row=index // 4,
                column=index % 4,
                padx=7,
                pady=5,
                sticky="nsew"
            )

            # Colored accent bar at the top of each card.
            ctk.CTkFrame(
                card,
                height=4,
                corner_radius=2,
                fg_color=accent
            ).pack(
                fill="x",
                padx=12,
                pady=(12, 8)
            )

            # Card title.
            ctk.CTkLabel(
                card,
                text=title,
                font=("Segoe UI", 12),
                text_color="#718096",
                wraplength=150
            ).pack(
                anchor="w",
                padx=15,
                pady=(5, 8)
            )

            # Actual value retrieved from the database.
            ctk.CTkLabel(
                card,
                text=value,
                font=("Segoe UI", 25, "bold"),
                text_color="#172B4D"
            ).pack(
                anchor="w",
                padx=15,
                pady=(0, 18)
            )

    # --------------------------------------------------
    # PLACEHOLDER SECTIONS
    # --------------------------------------------------

    def create_placeholder(self, title, description):

        section = ctk.CTkFrame(
            self.content,
            corner_radius=12,
            fg_color="#FFFFFF",
            border_width=1,
            border_color="#E2E8F0"
        )

        section.pack(fill="x", pady=10)

        ctk.CTkLabel(
            section,
            text=title,
            font=("Segoe UI", 17, "bold"),
            text_color="#172B4D"
        ).pack(anchor="w", padx=20, pady=(20, 8))

        ctk.CTkLabel(
            section,
            text=description,
            font=("Segoe UI", 13),
            text_color="#718096"
        ).pack(anchor="w", padx=20, pady=(0, 25))

    # --------------------------------------------------
    # NAVIGATION
    # --------------------------------------------------

    def navigate(self, page_name):

        if page_name not in self.navigation_buttons:
            raise ValueError(f"Unknown admin page: {page_name}")

        self.page_title.configure(text=page_name if page_name != "Dashboard" else "Admin Dashboard")
        for name, button in self.navigation_buttons.items():
            button.configure(
                fg_color="#29446F" if name == page_name else "transparent"
            )

        if page_name == "Dashboard":
            self.show_dashboard()
        elif page_name == "Products":
            self.show_products_page()
        elif page_name == "Inventory":
            self.clear_content()
            InventoryPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        elif page_name == "Sales & Billing":
            self.clear_content()
            SalesPage(self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )
        else:
            pages = {
                "Categories": CategoryManagementPage,
                "Suppliers": SupplierManagementPage,
                "Purchases": PurchaseManagementPage,
                "Reports": ReportsPage,
                "User Management": UserManagementPage,
                "Settings": SettingsPage,
            }
            self.clear_content()
            pages[page_name](self.content, self.user).grid(
                row=0, column=0, sticky="nsew"
            )

    # --------------------------------------------------
    # LOGOUT
    # --------------------------------------------------

    def logout(self):

        # Close the dashboard for now.
        # We will connect this to the login screen in a later step.
        self.destroy()


# Allow this dashboard to be tested independently.
if __name__ == "__main__":

    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")

    demo_user = {
        "id": 1,
        "username": "admin",
        "role": "admin"
    }

    app = AdminDashboard(demo_user)
    app.mainloop()