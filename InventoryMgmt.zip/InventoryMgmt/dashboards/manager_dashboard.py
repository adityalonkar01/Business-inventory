from dashboards.role_dashboard import InventoryRoleDashboard


class ManagerDashboard(InventoryRoleDashboard):
    expected_role = "manager"
    display_title = "Manager"