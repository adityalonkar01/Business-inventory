# Import CustomTkinter for creating the dashboard window.
import customtkinter as ctk


class Dashboard(ctk.CTk):
    """
    A temporary dashboard that displays the logged-in user's role.

    Later, we'll replace this with our complete dashboards.
    """

    def __init__(self, user):
        # Initialize the main application window.
        super().__init__()

        # Save the logged-in user's information.
        self.user = user

        # Set the window title.
        self.title("Inventory Management System")

        # Set the window size.
        self.geometry("900x550")

        # Use a light appearance.
        self.configure(fg_color="#F3F6FB")

        # Display the dashboard for the current user.
        self.create_dashboard()

    def create_dashboard(self):
        """Display the user's information and role."""

        # Display a heading based on the user's role.
        role_titles = {
            "admin": "Admin Dashboard",
            "manager": "Inventory Manager Dashboard",
            "salesperson": "Salesperson Dashboard"
        }

        # Get the appropriate heading.
        title = role_titles.get(
            self.user["role"],
            "Dashboard"
        )

        # Display the heading.
        ctk.CTkLabel(
            self,
            text=title,
            font=("Segoe UI", 28, "bold"),
            text_color="#1E3A5F"
        ).pack(pady=(100, 20))

        # Display the logged-in username.
        ctk.CTkLabel(
            self,
            text=f"Welcome, {self.user['username']}!",
            font=("Segoe UI", 18),
            text_color="#334155"
        ).pack(pady=10)

        # Display a temporary message.
        ctk.CTkLabel(
            self,
            text="Authentication successful!",
            font=("Segoe UI", 14),
            text_color="#16A34A"
        ).pack(pady=10)