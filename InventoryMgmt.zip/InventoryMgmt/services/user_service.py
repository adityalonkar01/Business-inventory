import hashlib
import re
import secrets
import sqlite3

from database.db_connection import get_connection
from services.admin_access import require_admin, require_roles
from services.auth_service import verify_password


ROLES = frozenset({"admin", "manager", "salesperson"})
PBKDF2_ITERATIONS = 600_000
_USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{3,40}$")


def _password_hash(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS
    )
    return f"{salt.hex()}${digest.hex()}"


def _validate_password(password):
    if not isinstance(password, str) or len(password) < 8 or len(password) > 1024:
        raise ValueError("Password must contain at least 8 characters.")


def _validate_user_fields(username, role, password=None):
    if not isinstance(username, str) or not _USERNAME_PATTERN.fullmatch(username.strip()):
        raise ValueError("Username must be 3–40 letters, numbers, dots, underscores, or hyphens.")
    if not isinstance(role, str) or role not in ROLES:
        raise ValueError("Choose admin, manager, or salesperson.")
    if password is not None:
        _validate_password(password)
    return username.strip()


def list_users(actor):
    connection = get_connection()
    try:
        require_admin(connection, actor)
        rows = connection.execute("""
            SELECT id, username, role, is_active, created_at
            FROM users
            ORDER BY username COLLATE NOCASE
        """).fetchall()
        return [
            {
                "id": row[0],
                "username": row[1],
                "role": row[2],
                "is_active": bool(row[3]),
                "created_at": row[4],
            }
            for row in rows
        ]
    finally:
        connection.close()


def create_user(actor, username, password, role):
    try:
        username = _validate_user_fields(username, role, password)
    except ValueError as error:
        return False, str(error)
    connection = None
    try:
        connection = get_connection()
        require_admin(connection, actor)
        connection.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            (username, _password_hash(password), role)
        )
        connection.commit()
        return True, "User account created."
    except sqlite3.IntegrityError:
        if connection is not None:
            connection.rollback()
        return False, "That username already exists."
    except (sqlite3.Error, PermissionError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def update_user(actor, user_id, username, role):
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id < 1:
        return False, "A valid user is required."
    try:
        username = _validate_user_fields(username, role)
    except ValueError as error:
        return False, str(error)
    connection = None
    try:
        connection = get_connection()
        connection.execute("BEGIN IMMEDIATE")
        actor_id = require_admin(connection, actor)
        target = connection.execute(
            "SELECT role, is_active FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if target is None:
            raise ValueError("User not found.")
        if actor_id == user_id and role != "admin":
            raise ValueError("You cannot remove your own administrator role.")
        if target[0] == "admin" and target[1] and role != "admin":
            active_admins = connection.execute(
                "SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_active = 1"
            ).fetchone()[0]
            if active_admins <= 1:
                raise ValueError("The last active administrator cannot be demoted.")
        connection.execute(
            "UPDATE users SET username = ?, role = ? WHERE id = ?",
            (username, role, user_id)
        )
        connection.commit()
        return True, "User updated."
    except sqlite3.IntegrityError:
        if connection is not None:
            connection.rollback()
        return False, "That username already exists."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def set_user_active(actor, user_id, is_active):
    if (
        isinstance(user_id, bool) or not isinstance(user_id, int) or user_id < 1
        or not isinstance(is_active, bool)
    ):
        return False, "A valid user and activation state are required."
    connection = None
    try:
        connection = get_connection()
        connection.execute("BEGIN IMMEDIATE")
        actor_id = require_admin(connection, actor)
        target = connection.execute(
            "SELECT role, is_active FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if target is None:
            raise ValueError("User not found.")
        if actor_id == user_id and not is_active:
            raise ValueError("You cannot deactivate your own administrator account.")
        if target[0] == "admin" and target[1] and not is_active:
            active_admins = connection.execute(
                "SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_active = 1"
            ).fetchone()[0]
            if active_admins <= 1:
                raise ValueError("The last active administrator cannot be deactivated.")
        connection.execute(
            "UPDATE users SET is_active = ? WHERE id = ?",
            (int(is_active), user_id)
        )
        connection.commit()
        return True, "User activated." if is_active else "User deactivated."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def reset_user_password(actor, user_id, password):
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id < 1:
        return False, "A valid user is required."
    try:
        _validate_user_fields("valid_user", "admin", password)
    except ValueError as error:
        return False, str(error)
    connection = None
    try:
        connection = get_connection()
        require_admin(connection, actor)
        cursor = connection.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (_password_hash(password), user_id)
        )
        if cursor.rowcount != 1:
            raise ValueError("User not found.")
        connection.commit()
        return True, "Password updated."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def change_own_password(actor, current_password, new_password, confirmation):
    if not isinstance(current_password, str) or len(current_password) > 1024:
        return False, "Enter a valid current password."
    if new_password != confirmation:
        return False, "The new password and confirmation do not match."
    try:
        _validate_password(new_password)
    except ValueError as error:
        return False, str(error)

    connection = None
    try:
        connection = get_connection()
        connection.execute("BEGIN IMMEDIATE")
        user_id = require_roles(connection, actor, {"manager", "salesperson"})
        row = connection.execute(
            "SELECT password_hash FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
        if row is None:
            raise ValueError("Account not found.")
        try:
            current_password_matches = verify_password(current_password, row[0])
        except (TypeError, ValueError) as error:
            raise ValueError("The stored password could not be verified.") from error
        if not current_password_matches:
            raise ValueError("Current password is incorrect.")
        try:
            new_password_matches = verify_password(new_password, row[0])
        except (TypeError, ValueError) as error:
            raise ValueError("The stored password could not be verified.") from error
        if new_password_matches:
            raise ValueError("Choose a password different from the current one.")
        cursor = connection.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (_password_hash(new_password), user_id)
        )
        if cursor.rowcount != 1:
            raise ValueError("Account not found.")
        connection.commit()
        return True, "Password updated."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()
