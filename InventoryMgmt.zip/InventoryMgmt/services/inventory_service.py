import sqlite3
from collections.abc import Mapping

from database.db_connection import get_connection
from database.inventory_schema import ensure_inventory_movement_table


MANAGE_INVENTORY_ROLES = frozenset({"admin", "manager"})
READ_INVENTORY_ROLES = frozenset({"admin", "manager", "salesperson"})
MAX_SQLITE_INTEGER = (1 << 63) - 1


def _connect():
    """Open the configured application database and apply the safe migration."""

    connection = get_connection()
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        ensure_inventory_movement_table(connection)
        connection.commit()
        return connection
    except sqlite3.Error:
        connection.close()
        raise


def _validate_user(connection, user, *, can_manage=False):
    if not isinstance(user, Mapping):
        raise PermissionError("A valid authenticated user is required.")

    user_id = user.get("id")
    role = user.get("role")
    if (
        isinstance(user_id, bool)
        or not isinstance(user_id, int)
        or not 1 <= user_id <= MAX_SQLITE_INTEGER
    ):
        raise PermissionError("A valid authenticated user is required.")

    allowed_roles = MANAGE_INVENTORY_ROLES if can_manage else READ_INVENTORY_ROLES
    if not isinstance(role, str) or role not in allowed_roles:
        if can_manage:
            raise PermissionError("Your role is not authorized to manage inventory.")
        raise PermissionError("Your role is not authorized to view inventory.")

    account = connection.execute(
        "SELECT role, is_active FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()
    if account is None or not account[1] or account[0] != role:
        raise PermissionError("The authenticated account is no longer active or valid.")

    return user_id


def can_manage_inventory(user):
    """Return whether the supplied authenticated role may change stock."""

    if not isinstance(user, Mapping):
        return False
    role = user.get("role")
    return isinstance(role, str) and role in MANAGE_INVENTORY_ROLES


def _validate_search_text(search_text):
    if not isinstance(search_text, str):
        raise ValueError("Inventory search text must be text.")
    return search_text.strip()


def get_inventory_summary(user):
    """Return active product count, total stock, and low-stock product count."""

    connection = _connect()
    try:
        _validate_user(connection, user)
        row = connection.execute("""
            SELECT
                COUNT(*),
                COALESCE(SUM(stock_quantity), 0),
                COALESCE(SUM(
                    CASE WHEN stock_quantity <= minimum_stock THEN 1 ELSE 0 END
                ), 0)
            FROM products
            WHERE is_active = 1
        """).fetchone()
        return {
            "total_products": row[0],
            "total_stock": row[1],
            "low_stock_products": row[2]
        }
    finally:
        connection.close()


def get_current_stock(user, search_text=""):
    """Return active stock rows, optionally searched by product name or SKU."""

    search_text = _validate_search_text(search_text)
    connection = _connect()
    try:
        _validate_user(connection, user)
        query = """
            SELECT
                id,
                product_name,
                sku,
                category,
                stock_quantity,
                minimum_stock,
                stock_quantity <= minimum_stock AS is_low_stock
            FROM products
            WHERE is_active = 1
        """
        parameters = ()
        if search_text:
            pattern = f"%{search_text}%"
            query += " AND (product_name LIKE ? OR sku LIKE ?)"
            parameters = (pattern, pattern)
        query += " ORDER BY product_name COLLATE NOCASE, id"
        rows = connection.execute(query, parameters).fetchall()
        return [
            {
                "id": row[0],
                "product_name": row[1],
                "sku": row[2],
                "category": row[3],
                "stock_quantity": row[4],
                "minimum_stock": row[5],
                "is_low_stock": bool(row[6])
            }
            for row in rows
        ]
    finally:
        connection.close()


def get_low_stock_products(user):
    """Return active products at or below their configured minimum stock."""

    connection = _connect()
    try:
        _validate_user(connection, user)
        rows = connection.execute("""
            SELECT id, product_name, sku, category, stock_quantity, minimum_stock
            FROM products
            WHERE is_active = 1
              AND stock_quantity <= minimum_stock
            ORDER BY stock_quantity ASC, product_name COLLATE NOCASE
        """).fetchall()
        return [
            {
                "id": row[0],
                "product_name": row[1],
                "sku": row[2],
                "category": row[3],
                "stock_quantity": row[4],
                "minimum_stock": row[5]
            }
            for row in rows
        ]
    finally:
        connection.close()


def get_stock_movement_history(user, product_id=None, limit=100):
    """Return recent stock movements, newest first."""

    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 500:
        raise ValueError("History limit must be between 1 and 500.")
    if product_id is not None and (
        isinstance(product_id, bool)
        or not isinstance(product_id, int)
        or not 1 <= product_id <= MAX_SQLITE_INTEGER
    ):
        raise ValueError("Product ID must be a positive whole number.")

    connection = _connect()
    try:
        _validate_user(connection, user)
        query = """
            SELECT
                m.id,
                m.product_id,
                p.product_name,
                p.sku,
                m.movement_type,
                m.quantity,
                m.previous_stock,
                m.new_stock,
                m.notes,
                u.username,
                m.created_at
            FROM inventory_movements AS m
            JOIN products AS p ON p.id = m.product_id
            JOIN users AS u ON u.id = m.performed_by
        """
        parameters = ()
        if product_id is not None:
            query += " WHERE m.product_id = ?"
            parameters = (product_id,)
        query += " ORDER BY m.created_at DESC, m.id DESC LIMIT ?"
        parameters += (limit,)
        rows = connection.execute(query, parameters).fetchall()
        fields = (
            "id",
            "product_id",
            "product_name",
            "sku",
            "movement_type",
            "quantity",
            "previous_stock",
            "new_stock",
            "notes",
            "performed_by_username",
            "created_at"
        )
        return [dict(zip(fields, row)) for row in rows]
    finally:
        connection.close()


def receive_stock(product_id, quantity, user, notes=""):
    """Receive a positive quantity and atomically record the stock movement."""

    return _change_stock(
        product_id,
        quantity,
        user,
        notes,
        movement_type="receipt"
    )


def adjust_stock(product_id, quantity_change, user, notes=""):
    """Apply a signed stock adjustment; negative adjustments cannot overdraw stock."""

    return _change_stock(
        product_id,
        quantity_change,
        user,
        notes,
        movement_type=None
    )


def _change_stock(product_id, quantity, user, notes, *, movement_type):
    if (
        isinstance(product_id, bool)
        or not isinstance(product_id, int)
        or not 1 <= product_id <= MAX_SQLITE_INTEGER
    ):
        return False, "Product ID must be a positive whole number."
    if isinstance(quantity, bool) or not isinstance(quantity, int):
        return False, "Quantity must be a whole number."
    if abs(quantity) > MAX_SQLITE_INTEGER:
        return False, "Quantity exceeds the supported stock range."
    if (movement_type is not None and quantity <= 0) or (
        movement_type is None and quantity == 0
    ):
        return False, (
            "Quantity must be a positive whole number."
            if movement_type is not None
            else "Adjustment quantity cannot be zero."
        )
    if not isinstance(notes, str):
        return False, "Notes must be text."
    notes = notes.strip()
    if len(notes) > 500:
        return False, "Notes cannot exceed 500 characters."

    if movement_type is None:
        delta = quantity
        resolved_type = "adjustment_in" if delta > 0 else "adjustment_out"
    else:
        delta = quantity
        resolved_type = movement_type

    connection = None
    try:
        connection = _connect()
        connection.execute("BEGIN IMMEDIATE")
        user_id = _validate_user(connection, user, can_manage=True)
        product = connection.execute(
            """
            SELECT stock_quantity
            FROM products
            WHERE id = ? AND is_active = 1
            """,
            (product_id,)
        ).fetchone()
        if product is None:
            connection.rollback()
            return False, "Active product not found."

        previous_stock = product[0]
        new_stock = previous_stock + delta
        if new_stock < 0:
            connection.rollback()
            return False, "Stock adjustment cannot make available stock negative."
        if new_stock > MAX_SQLITE_INTEGER:
            connection.rollback()
            return False, "Stock quantity exceeds the supported range."

        updated = connection.execute(
            """
            UPDATE products
            SET stock_quantity = ?
            WHERE id = ? AND is_active = 1 AND stock_quantity = ?
            """,
            (new_stock, product_id, previous_stock)
        )
        if updated.rowcount != 1:
            connection.rollback()
            return False, "Stock changed concurrently. Refresh inventory and try again."

        connection.execute(
            """
            INSERT INTO inventory_movements (
                product_id,
                movement_type,
                quantity,
                previous_stock,
                new_stock,
                notes,
                performed_by
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                product_id,
                resolved_type,
                abs(delta),
                previous_stock,
                new_stock,
                notes,
                user_id
            )
        )
        connection.commit()
        return True, "Stock received successfully." if movement_type else "Stock adjusted successfully."
    except PermissionError as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    except sqlite3.Error as error:
        if connection is not None:
            connection.rollback()
        return False, f"Unable to change stock: {error}"
    finally:
        if connection is not None:
            connection.close()
