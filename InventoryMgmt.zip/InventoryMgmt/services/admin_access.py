from collections.abc import Mapping


def require_admin(connection, user):
    if not isinstance(user, Mapping):
        raise PermissionError("A valid authenticated administrator is required.")
    user_id = user.get("id")
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id < 1:
        raise PermissionError("A valid authenticated administrator is required.")
    row = connection.execute(
        "SELECT role, is_active FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()
    if row is None or row[0] != "admin" or not row[1] or user.get("role") != "admin":
        raise PermissionError("Administrator access is required.")
    return user_id


def require_roles(connection, user, allowed_roles):
    if not isinstance(user, Mapping):
        raise PermissionError("A valid authenticated user is required.")
    user_id = user.get("id")
    role = user.get("role")
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id < 1:
        raise PermissionError("A valid authenticated user is required.")
    row = connection.execute(
        "SELECT role, is_active FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()
    if (
        row is None
        or not row[1]
        or not isinstance(role, str)
        or row[0] != role
        or role not in allowed_roles
    ):
        raise PermissionError("Your role is not authorized to perform this action.")
    return user_id
