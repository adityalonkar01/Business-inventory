import csv
import sqlite3
from datetime import date
from pathlib import Path

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from database.sales_schema import ensure_sales_schema
from services.admin_access import require_roles


def _validated_dates(start_date, end_date):
    try:
        start = date.fromisoformat(start_date)
        end = date.fromisoformat(end_date)
    except (TypeError, ValueError):
        raise ValueError("Enter dates in YYYY-MM-DD format.") from None
    if start.isoformat() != start_date or end.isoformat() != end_date:
        raise ValueError("Enter dates in YYYY-MM-DD format.")
    if end < start:
        raise ValueError("End date must be on or after start date.")
    return start_date, end_date


def _connect_reports(user):
    connection = get_connection()
    try:
        require_roles(connection, user, {"admin", "manager"})
        ensure_admin_schema(connection)
        ensure_sales_schema(connection)
        return connection
    except (sqlite3.Error, PermissionError):
        connection.close()
        raise


def get_reports(user, start_date, end_date):
    start_date, end_date = _validated_dates(start_date, end_date)
    connection = _connect_reports(user)
    try:
        sales_summary = connection.execute("""
            SELECT COUNT(*), COALESCE(SUM(subtotal), 0),
                   COALESCE(SUM(discount_amount), 0),
                   COALESCE(SUM(gst_amount), 0),
                   COALESCE(SUM(total_amount), 0)
            FROM sales WHERE date(created_at) BETWEEN ? AND ?
        """, (start_date, end_date)).fetchone()
        daily_sales = connection.execute("""
            SELECT date(created_at), COUNT(*), COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE date(created_at) BETWEEN ? AND ?
            GROUP BY date(created_at)
            ORDER BY date(created_at)
        """, (start_date, end_date)).fetchall()
        top_products = connection.execute("""
            SELECT si.product_name, si.sku, SUM(si.quantity),
                   SUM(si.line_total + COALESCE(si.tax_amount, 0))
            FROM sale_items AS si
            JOIN sales AS s ON s.id = si.sale_id
            WHERE date(s.created_at) BETWEEN ? AND ?
            GROUP BY si.product_id, si.product_name, si.sku
            ORDER BY SUM(si.quantity) DESC, SUM(si.line_total) DESC
            LIMIT 20
        """, (start_date, end_date)).fetchall()
        low_stock = connection.execute("""
            SELECT product_name, sku, stock_quantity, minimum_stock
            FROM products
            WHERE is_active = 1 AND stock_quantity <= minimum_stock
            ORDER BY stock_quantity, product_name COLLATE NOCASE
        """).fetchall()
        stock_valuation = connection.execute("""
            SELECT COUNT(*), COALESCE(SUM(stock_quantity), 0),
                   COALESCE(SUM(stock_quantity * purchase_price), 0),
                   COALESCE(SUM(stock_quantity * selling_price), 0)
            FROM products WHERE is_active = 1
        """).fetchone()
        purchases = connection.execute("""
            SELECT p.purchase_ref, s.name, p.status, p.total_amount, p.created_at
            FROM purchases AS p
            JOIN suppliers AS s ON s.id = p.supplier_id
            WHERE date(p.created_at) BETWEEN ? AND ?
            ORDER BY p.created_at DESC, p.id DESC
        """, (start_date, end_date)).fetchall()
        category_summary = connection.execute("""
            SELECT c.name, COUNT(p.id)
            FROM categories AS c
            LEFT JOIN products AS p ON p.category = c.name COLLATE NOCASE
                AND p.is_active = 1
            WHERE c.is_active = 1
            GROUP BY c.id, c.name
            ORDER BY c.name COLLATE NOCASE
        """).fetchall()
        currency_symbol = connection.execute(
            "SELECT setting_value FROM app_settings WHERE setting_key = 'currency_symbol'"
        ).fetchone()[0]
        connection.commit()
        return {
            "start_date": start_date,
            "end_date": end_date,
            "currency_symbol": currency_symbol,
            "sales_summary": {
                "invoice_count": sales_summary[0],
                "subtotal": sales_summary[1],
                "discount_amount": sales_summary[2],
                "tax_amount": sales_summary[3],
                "total_amount": sales_summary[4],
            },
            "daily_sales": [
                {"date": row[0], "invoice_count": row[1], "total_amount": row[2]}
                for row in daily_sales
            ],
            "top_products": [
                {
                    "product_name": row[0], "sku": row[1],
                    "quantity_sold": row[2], "sales_total": row[3]
                }
                for row in top_products
            ],
            "low_stock": [
                {
                    "product_name": row[0], "sku": row[1],
                    "stock_quantity": row[2], "minimum_stock": row[3]
                }
                for row in low_stock
            ],
            "stock_valuation": {
                "product_count": stock_valuation[0],
                "stock_quantity": stock_valuation[1],
                "cost_value": stock_valuation[2],
                "selling_value": stock_valuation[3],
            },
            "purchases": [
                {
                    "purchase_ref": row[0], "supplier": row[1],
                    "status": row[2], "total_amount": row[3], "created_at": row[4]
                }
                for row in purchases
            ],
            "categories": [
                {"name": row[0], "product_count": row[1]}
                for row in category_summary
            ],
        }
    except sqlite3.Error:
        connection.rollback()
        raise
    finally:
        connection.close()


def export_report_csv(user, report_type, start_date, end_date, destination):
    if report_type not in {"daily_sales", "top_products", "low_stock", "purchases", "categories"}:
        raise ValueError("Choose a supported report to export.")
    if not isinstance(destination, (str, Path)) or not str(destination).strip():
        raise ValueError("Choose a CSV destination.")
    report = get_reports(user, start_date, end_date)
    fieldnames = {
        "daily_sales": ("date", "invoice_count", "total_amount"),
        "top_products": ("product_name", "sku", "quantity_sold", "sales_total"),
        "low_stock": ("product_name", "sku", "stock_quantity", "minimum_stock"),
        "purchases": ("purchase_ref", "supplier", "status", "total_amount", "created_at"),
        "categories": ("name", "product_count"),
    }[report_type]
    rows = report[report_type]
    try:
        with Path(destination).open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows([
                {
                    key: "'" + value
                    if isinstance(value, str) and value.startswith(("=", "+", "-", "@"))
                    else value
                    for key, value in row.items()
                }
                for row in rows
            ])
    except OSError:
        raise
    return len(rows)
