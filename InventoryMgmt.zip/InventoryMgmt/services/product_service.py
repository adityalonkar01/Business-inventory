import math
import sqlite3

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from services.admin_access import require_roles


def _normalize_product_data(
    product_name,
    sku,
    category,
    purchase_price,
    selling_price,
    stock_quantity,
    minimum_stock
):
    """Validate and normalize product fields shared by add and update."""

    if not all(isinstance(value, str) for value in (product_name, sku, category)):
        return None, "Product name, SKU, and category are required."

    product_name = product_name.strip()
    sku = sku.strip().upper()
    category = category.strip()

    if not product_name or not sku or not category:
        return None, "Product name, SKU, and category are required."

    try:
        purchase_price = float(purchase_price)
        selling_price = float(selling_price)
        stock_quantity_value = float(stock_quantity)
        minimum_stock_value = float(minimum_stock)
    except (TypeError, ValueError, OverflowError):
        return None, "Prices and stock quantities must be valid numbers."

    if not all(math.isfinite(value) for value in (
        purchase_price,
        selling_price,
        stock_quantity_value,
        minimum_stock_value
    )):
        return None, "Prices and stock quantities must be finite numbers."

    if purchase_price < 0 or selling_price < 0:
        return None, "Prices cannot be negative."

    if selling_price <= 0:
        return None, "Selling price must be greater than zero."

    if stock_quantity_value < 0 or minimum_stock_value < 0:
        return None, "Stock quantities cannot be negative."

    if not stock_quantity_value.is_integer() or not minimum_stock_value.is_integer():
        return None, "Stock quantities must be whole numbers."

    return (
        product_name,
        sku,
        category,
        purchase_price,
        selling_price,
        int(stock_quantity_value),
        int(minimum_stock_value)
    ), None


def add_product(
    product_name,
    sku,
    category,
    purchase_price,
    selling_price,
    stock_quantity,
    minimum_stock=5
):
    """ 
    Add a new product to the database.

    Returns:
        (True, message) if successful.
        (False, message) if an error occurs.
    """

    product_data, validation_error = _normalize_product_data(
        product_name,
        sku,
        category,
        purchase_price,
        selling_price,
        stock_quantity,
        minimum_stock
    )
    if validation_error:
        return False, validation_error

    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        connection.execute("""
            INSERT INTO categories (name) VALUES (?)
            ON CONFLICT(name) DO UPDATE SET is_active = 1
        """, (product_data[2],))
        # Insert the product using parameterized SQL.
        connection.execute(
            """
            INSERT INTO products (
                product_name,
                sku,
                category,
                purchase_price,
                selling_price,
                stock_quantity,
                minimum_stock
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            product_data
        )

        # Save the new product.
        connection.commit()

        return True, "Product added successfully!"

    except sqlite3.IntegrityError as error:
        if connection is not None:
            connection.rollback()

        # Handle duplicate SKU errors separately.
        if "UNIQUE constraint failed: products.sku" in str(error):
            return False, "This SKU already exists."

        return False, f"Unable to add product: {error}"

    except sqlite3.Error as error:
        if connection is not None:
            connection.rollback()
        return False, f"Unable to add product: {error}"

    finally:
        # Always close the database connection.
        if connection is not None:
            connection.close()

def get_all_products():
    """
    Retrieve all active products from the database.

    Returns:
        A list containing product records.
    """

    # Establish a connection to the SQLite database.
    connection = get_connection()

    try:
        return _get_active_products(connection)

    finally:
        # Close the connection after retrieving the data.
        connection.close()

def search_products(search_text):
    """
    Search active products by product name or SKU.

    Args:
        search_text: Text entered by the user.

    Returns:
        A list of matching product records.
    """

    search_text = search_text.strip()
    connection = get_connection()

    try:
        return _get_active_products(connection, search_text)

    finally:
        # Close the database connection.
        connection.close()


def _get_active_products(connection, search_text=""):
    query = """
        SELECT
            id,
            product_name,
            sku,
            category,
            purchase_price,
            selling_price,
            stock_quantity,
            minimum_stock
        FROM products
        WHERE is_active = 1
    """
    parameters = ()
    search_text = search_text.strip()
    if search_text:
        search_pattern = f"%{search_text}%"
        query += """
            AND (product_name LIKE ? OR sku LIKE ?)
        """
        parameters = (search_pattern, search_pattern)
    query += " ORDER BY id DESC"
    return connection.execute(query, parameters).fetchall()


def get_manager_products(user, search_text=""):
    """List active products for a verified manager without allowing changes."""

    if not isinstance(search_text, str):
        raise ValueError("Product search must be text.")
    connection = get_connection()
    try:
        require_roles(connection, user, {"manager"})
        return _get_active_products(connection, search_text)
    finally:
        connection.close()

def update_product(
    product_id,
    product_name,
    sku,
    category,
    purchase_price,
    selling_price,
    stock_quantity,
    minimum_stock=5
):
    """
    Update an existing product using its database ID.

    Returns:
        (True, message) if successful.
        (False, message) if the update fails.
    """

    product_data, validation_error = _normalize_product_data(
        product_name,
        sku,
        category,
        purchase_price,
        selling_price,
        stock_quantity,
        minimum_stock
    )
    if validation_error:
        return False, validation_error

    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        connection.execute("""
            INSERT INTO categories (name) VALUES (?)
            ON CONFLICT(name) DO UPDATE SET is_active = 1
        """, (product_data[2],))
        # Update only an active product.
        cursor = connection.execute(
            """
            UPDATE products
            SET
                product_name = ?,
                sku = ?,
                category = ?,
                purchase_price = ?,
                selling_price = ?,
                stock_quantity = ?,
                minimum_stock = ?
            WHERE id = ?
              AND is_active = 1
            """,
            (*product_data, product_id)
        )

        # Check whether a product was actually updated.
        if cursor.rowcount == 0:
            connection.rollback()
            return False, "Product not found or is inactive."

        # Save the changes.
        connection.commit()

        return True, "Product updated successfully!"

    except sqlite3.IntegrityError as error:

        # Undo unsuccessful changes.
        connection.rollback()

        # Handle duplicate SKU errors.
        if "UNIQUE constraint failed: products.sku" in str(error):
            return False, "This SKU already exists."

        return False, f"Unable to update product: {error}"

    except sqlite3.Error as error:
        if connection is not None:
            connection.rollback()
        return False, f"Unable to update product: {error}"

    finally:
        # Always close the database connection.
        if connection is not None:
            connection.close()

def delete_product(product_id):
    """
    Deactivate a product instead of permanently deleting it.

    Returns:
        (True, message) if successful.
        (False, message) if the product cannot be deactivated.
    """

    connection = None

    try:
        connection = get_connection()
        # Deactivate the selected product.
        cursor = connection.execute(
            """
            UPDATE products
            SET is_active = 0
            WHERE id = ?
              AND is_active = 1
            """,
            (product_id,)
        )

        # Check whether an active product was found.
        if cursor.rowcount == 0:
            connection.rollback()
            return False, "Product not found or already inactive."

        # Save the change.
        connection.commit()

        return True, "Product deactivated successfully!"

    except sqlite3.Error as error:
        if connection is not None:
            connection.rollback()
        return False, f"Unable to deactivate product: {error}"

    finally:
        # Always close the database connection.
        if connection is not None:
            connection.close()