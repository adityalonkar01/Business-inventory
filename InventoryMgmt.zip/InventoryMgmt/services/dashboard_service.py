import sqlite3

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from database.inventory_schema import ensure_inventory_movement_table
from database.sales_schema import ensure_sales_schema
from services.admin_access import require_admin, require_roles


def get_admin_statistics(user):
    """
    Retrieve summary statistics for the Admin Dashboard.

    Returns a dictionary containing product, stock,
    low-stock, and sales information.
    """

    connection = get_connection()

    try:
        require_admin(connection, user)
        ensure_admin_schema(connection)
        # Count active products.
        total_products = connection.execute("""
            SELECT COUNT(*)
            FROM products
            WHERE is_active = 1
        """).fetchone()[0]

        # Calculate the total number of available stock units.
        total_stock = connection.execute("""
            SELECT COALESCE(SUM(stock_quantity), 0)
            FROM products
            WHERE is_active = 1
        """).fetchone()[0]

        # Count products that have reached or fallen below
        # their minimum stock level.
        low_stock_items = connection.execute("""
            SELECT COUNT(*)
            FROM products
            WHERE is_active = 1
              AND stock_quantity <= minimum_stock
        """).fetchone()[0]

        # Calculate total recorded sales.
        total_sales = connection.execute("""
            SELECT COALESCE(SUM(total_amount), 0)
            FROM sales
        """).fetchone()[0]
        today = connection.execute("""
            SELECT COUNT(*), COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE date(created_at) = date('now', 'localtime')
        """).fetchone()
        recent_sales = connection.execute("""
            SELECT s.invoice_number, s.total_amount, s.created_at, u.username
            FROM sales AS s
            LEFT JOIN users AS u ON u.id = s.sold_by
            ORDER BY s.created_at DESC, s.id DESC
            LIMIT 8
        """).fetchall()
        best_sellers = connection.execute("""
            SELECT product_name, sku, SUM(quantity) AS quantity_sold
            FROM sale_items
            GROUP BY product_id, product_name, sku
            ORDER BY quantity_sold DESC, product_name COLLATE NOCASE
            LIMIT 5
        """).fetchall()
        top_low_stock = connection.execute("""
            SELECT product_name, sku, stock_quantity, minimum_stock
            FROM products
            WHERE is_active = 1 AND stock_quantity <= minimum_stock
            ORDER BY stock_quantity, product_name COLLATE NOCASE
            LIMIT 8
        """).fetchall()
        inventory_value = connection.execute("""
            SELECT COALESCE(SUM(stock_quantity * purchase_price), 0)
            FROM products WHERE is_active = 1
        """).fetchone()[0]
        connection.commit()

        # Return all statistics in one dictionary.
        return {
            "total_products": total_products,
            "total_stock": total_stock,
            "low_stock_items": low_stock_items,
            "total_sales": total_sales,
            "today_invoice_count": today[0],
            "today_sales": today[1],
            "recent_sales": recent_sales,
            "best_sellers": best_sellers,
            "low_stock_products": top_low_stock,
            "inventory_cost_value": inventory_value
        }

    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        # Always close the database connection.
        connection.close()


def get_manager_statistics(user):
    """Return dashboard metrics and recent activity for an authenticated manager."""

    connection = get_connection()

    try:
        require_roles(connection, user, {"manager"})
        ensure_admin_schema(connection)
        ensure_sales_schema(connection)
        ensure_inventory_movement_table(connection)
        connection.commit()
        currency_symbol = connection.execute("""
            SELECT setting_value
            FROM app_settings
            WHERE setting_key = 'currency_symbol'
        """).fetchone()[0]

        total_active_products = connection.execute("""
            SELECT COUNT(*)
            FROM products
            WHERE is_active = 1
        """).fetchone()[0]
        total_stock_quantity = connection.execute("""
            SELECT COALESCE(SUM(stock_quantity), 0)
            FROM products
            WHERE is_active = 1
        """).fetchone()[0]
        low_stock_product_count = connection.execute("""
            SELECT COUNT(*)
            FROM products
            WHERE is_active = 1 AND stock_quantity <= minimum_stock
        """).fetchone()[0]
        inventory_valuation = connection.execute("""
            SELECT COALESCE(SUM(stock_quantity * purchase_price), 0)
            FROM products
            WHERE is_active = 1
        """).fetchone()[0]
        today_sales = connection.execute("""
            SELECT COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE date(created_at, 'localtime') = date('now', 'localtime')
        """).fetchone()[0]
        monthly_sales = connection.execute("""
            SELECT COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE strftime('%Y-%m', created_at, 'localtime')
                = strftime('%Y-%m', 'now', 'localtime')
        """).fetchone()[0]
        recent_transaction_count = connection.execute("""
            SELECT COUNT(*)
            FROM sales
            WHERE date(created_at, 'localtime')
                >= date('now', 'localtime', '-6 days')
        """).fetchone()[0]
        recent_purchases = connection.execute("""
            SELECT p.purchase_ref, s.name, p.status, p.total_amount, p.created_at
            FROM purchases AS p
            JOIN suppliers AS s ON s.id = p.supplier_id
            ORDER BY p.created_at DESC, p.id DESC
            LIMIT 5
        """).fetchall()
        recent_stock_movements = connection.execute("""
            SELECT p.product_name, p.sku, m.movement_type, m.quantity,
                   m.previous_stock, m.new_stock, u.username, m.created_at
            FROM inventory_movements AS m
            JOIN products AS p ON p.id = m.product_id
            JOIN users AS u ON u.id = m.performed_by
            ORDER BY m.created_at DESC, m.id DESC
            LIMIT 5
        """).fetchall()
        low_stock_alerts = connection.execute("""
            SELECT id, product_name, sku, stock_quantity, minimum_stock
            FROM products
            WHERE is_active = 1 AND stock_quantity <= minimum_stock
            ORDER BY stock_quantity, product_name COLLATE NOCASE
            LIMIT 8
        """).fetchall()
        return {
            "total_active_products": total_active_products,
            "total_stock_quantity": total_stock_quantity,
            "low_stock_product_count": low_stock_product_count,
            "inventory_valuation": inventory_valuation,
            "today_sales": today_sales,
            "monthly_sales": monthly_sales,
            "recent_transaction_count": recent_transaction_count,
            "recent_purchases": recent_purchases,
            "recent_stock_movements": recent_stock_movements,
            "low_stock_alerts": low_stock_alerts,
            "currency_symbol": currency_symbol,
        }
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()