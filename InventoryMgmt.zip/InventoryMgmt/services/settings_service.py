import re
import sqlite3
from decimal import Decimal, InvalidOperation

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from database.sales_schema import ensure_sales_schema
from services.admin_access import require_admin


_DEFAULTS = {
    "business_name": "",
    "business_address": "",
    "business_phone": "",
    "business_email": "",
    "currency_symbol": "₹",
    "default_gst_percent": "0",
    "invoice_prefix": "INV-",
    "minimum_stock_default": "5",
}


def _read_settings(connection):
    ensure_admin_schema(connection)
    values = dict(connection.execute(
        "SELECT setting_key, setting_value FROM app_settings"
    ).fetchall())
    result = {**_DEFAULTS, **values}
    result["default_gst_percent"] = float(result["default_gst_percent"])
    result["minimum_stock_default"] = int(result["minimum_stock_default"])
    return result


def get_public_settings():
    connection = get_connection()
    try:
        settings = _read_settings(connection)
        connection.commit()
        return settings
    except sqlite3.Error:
        connection.rollback()
        raise
    finally:
        connection.close()


def get_admin_settings(user):
    connection = get_connection()
    try:
        ensure_admin_schema(connection)
        require_admin(connection, user)
        result = _read_settings(connection)
        connection.commit()
        return result
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()


def update_settings(user, values):
    if not isinstance(values, dict):
        return False, "Settings must be provided as a mapping."
    allowed = set(_DEFAULTS)
    if set(values) - allowed:
        return False, "Unknown settings were provided."
    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        ensure_sales_schema(connection)
        require_admin(connection, user)
        normalized = {
            **_DEFAULTS,
            **dict(connection.execute(
                "SELECT setting_key, setting_value FROM app_settings"
            ).fetchall()),
            **values,
        }
        previous_currency = connection.execute(
            "SELECT setting_value FROM app_settings WHERE setting_key = 'currency_symbol'"
        ).fetchone()[0]
        completed_sales = connection.execute(
            "SELECT EXISTS(SELECT 1 FROM sales LIMIT 1)"
        ).fetchone()[0]
        if completed_sales and normalized["currency_symbol"] != previous_currency:
            raise ValueError(
                "Currency cannot be changed after sales have been recorded."
            )
        for key in (
            "business_name", "business_address", "business_phone",
            "business_email", "currency_symbol", "invoice_prefix"
        ):
            value = normalized[key]
            if not isinstance(value, str) or len(value.strip()) > 200:
                raise ValueError(
                    f"{key.replace('_', ' ').title()} must be text of at most 200 characters."
                )
            normalized[key] = value.strip()
        if not normalized["currency_symbol"] or len(normalized["currency_symbol"]) > 4:
            raise ValueError("Currency symbol must contain between 1 and 4 characters.")
        if normalized["business_email"] and (
            "@" not in normalized["business_email"]
            or " " in normalized["business_email"]
        ):
            raise ValueError("Enter a valid business email address.")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,12}", normalized["invoice_prefix"]):
            raise ValueError(
                "Invoice prefix may contain up to 12 letters, numbers, underscores, or hyphens."
            )
        try:
            gst = Decimal(str(normalized["default_gst_percent"]))
            minimum_value = Decimal(str(normalized["minimum_stock_default"]))
            if (
                not minimum_value.is_finite()
                or minimum_value != minimum_value.to_integral_value()
            ):
                raise ValueError
            minimum = int(minimum_value)
            if not gst.is_finite() or not Decimal(0) <= gst <= Decimal(100):
                raise ValueError
            if isinstance(normalized["minimum_stock_default"], bool) or minimum < 0:
                raise ValueError
        except (InvalidOperation, TypeError, ValueError, OverflowError):
            raise ValueError(
                "GST must be 0–100 and minimum stock must be a non-negative whole number."
            ) from None
        normalized["default_gst_percent"] = format(gst.normalize(), "f")
        normalized["minimum_stock_default"] = str(minimum)
        connection.executemany(
            """
            INSERT INTO app_settings (setting_key, setting_value)
            VALUES (?, ?)
            ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value
            """,
            [(key, str(value)) for key, value in normalized.items()]
        )
        connection.commit()
        return True, "Settings saved."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()
