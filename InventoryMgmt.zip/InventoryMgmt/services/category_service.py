import sqlite3

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from services.admin_access import require_admin


def list_categories(user, include_inactive=False):
    connection = get_connection()
    try:
        ensure_admin_schema(connection)
        require_admin(connection, user)
        query = "SELECT id, name, is_active FROM categories"
        if not include_inactive:
            query += " WHERE is_active = 1"
        query += " ORDER BY name COLLATE NOCASE"
        rows = connection.execute(query).fetchall()
        connection.commit()
        return rows
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()


def create_category(user, name):
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 80:
        return False, "Category name is required (maximum 80 characters)."
    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        require_admin(connection, user)
        connection.execute("INSERT INTO categories (name) VALUES (?)", (name.strip(),))
        connection.commit()
        return True, "Category created."
    except sqlite3.IntegrityError:
        if connection is not None:
            connection.rollback()
        return False, "A category with that name already exists."
    except (sqlite3.Error, PermissionError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def rename_category(user, category_id, name):
    if isinstance(category_id, bool) or not isinstance(category_id, int) or category_id < 1:
        return False, "A valid category is required."
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 80:
        return False, "Category name is required (maximum 80 characters)."
    connection = None
    try:
        connection = get_connection()
        connection.execute("BEGIN IMMEDIATE")
        ensure_admin_schema(connection)
        require_admin(connection, user)
        old = connection.execute(
            "SELECT name FROM categories WHERE id = ? AND is_active = 1",
            (category_id,)
        ).fetchone()
        if old is None:
            raise ValueError("Category not found.")
        connection.execute(
            "UPDATE categories SET name = ? WHERE id = ?",
            (name.strip(), category_id)
        )
        connection.execute(
            "UPDATE products SET category = ? WHERE category = ? COLLATE NOCASE",
            (name.strip(), old[0])
        )
        connection.commit()
        return True, "Category renamed."
    except sqlite3.IntegrityError:
        if connection is not None:
            connection.rollback()
        return False, "A category with that name already exists."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def deactivate_category(user, category_id):
    if isinstance(category_id, bool) or not isinstance(category_id, int) or category_id < 1:
        return False, "A valid category is required."
    connection = None
    try:
        connection = get_connection()
        connection.execute("BEGIN IMMEDIATE")
        ensure_admin_schema(connection)
        require_admin(connection, user)
        row = connection.execute(
            "SELECT name FROM categories WHERE id = ? AND is_active = 1",
            (category_id,)
        ).fetchone()
        if row is None:
            raise ValueError("Category not found.")
        used = connection.execute(
            "SELECT COUNT(*) FROM products WHERE category = ? COLLATE NOCASE",
            (row[0],)
        ).fetchone()[0]
        if used:
            raise ValueError("This category is assigned to products and cannot be deactivated.")
        connection.execute(
            "UPDATE categories SET is_active = 0 WHERE id = ?",
            (category_id,)
        )
        connection.commit()
        return True, "Category deactivated."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def set_category_active(user, category_id, active):
    if (
        isinstance(category_id, bool) or not isinstance(category_id, int)
        or category_id < 1 or not isinstance(active, bool)
    ):
        return False, "A valid category and status are required."
    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        require_admin(connection, user)
        if not active:
            name = connection.execute(
                "SELECT name FROM categories WHERE id = ?", (category_id,)
            ).fetchone()
            if name is not None and connection.execute(
                "SELECT COUNT(*) FROM products WHERE category = ? COLLATE NOCASE",
                (name[0],)
            ).fetchone()[0]:
                raise ValueError("This category is assigned to products and cannot be deactivated.")
        cursor = connection.execute(
            "UPDATE categories SET is_active = ? WHERE id = ?",
            (int(active), category_id)
        )
        if cursor.rowcount != 1:
            raise ValueError("Category not found.")
        connection.commit()
        return True, "Category activated." if active else "Category deactivated."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()
