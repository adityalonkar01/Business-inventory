import sqlite3

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from services.admin_access import require_admin, require_roles


def _validate_supplier(values):
    if not isinstance(values, dict):
        raise ValueError("Supplier details are required.")
    result = {}
    for field, label, maximum in (
        ("name", "Supplier name", 120),
        ("contact_name", "Contact name", 120),
        ("phone", "Phone", 40),
        ("email", "Email", 254),
        ("address", "Address", 500),
    ):
        value = values.get(field, "")
        if not isinstance(value, str):
            raise ValueError(f"{label} must be text.")
        value = value.strip()
        if field == "name" and not value:
            raise ValueError("Supplier name is required.")
        if len(value) > maximum:
            raise ValueError(f"{label} is too long.")
        result[field] = value
    if result["email"] and ("@" not in result["email"] or " " in result["email"]):
        raise ValueError("Enter a valid supplier email address.")
    return result


def list_suppliers(user, include_inactive=False):
    connection = get_connection()
    try:
        ensure_admin_schema(connection)
        require_admin(connection, user)
        query = """
            SELECT id, name, contact_name, phone, email, address, is_active, created_at
            FROM suppliers
        """
        if not include_inactive:
            query += " WHERE is_active = 1"
        query += " ORDER BY name COLLATE NOCASE"
        rows = connection.execute(query).fetchall()
        connection.commit()
        return [
            {
                "id": row[0], "name": row[1], "contact_name": row[2],
                "phone": row[3], "email": row[4], "address": row[5],
                "is_active": bool(row[6]), "created_at": row[7]
            }
            for row in rows
        ]
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()


def list_purchase_suppliers(user):
    connection = get_connection()
    try:
        ensure_admin_schema(connection)
        require_roles(connection, user, {"admin", "manager"})
        rows = connection.execute("""
            SELECT id, name, contact_name, phone, email, address, is_active, created_at
            FROM suppliers
            WHERE is_active = 1
            ORDER BY name COLLATE NOCASE
        """).fetchall()
        connection.commit()
        return [
            {
                "id": row[0], "name": row[1], "contact_name": row[2],
                "phone": row[3], "email": row[4], "address": row[5],
                "is_active": bool(row[6]), "created_at": row[7]
            }
            for row in rows
        ]
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()


def save_supplier(user, values, supplier_id=None):
    try:
        supplier = _validate_supplier(values)
        if supplier_id is not None and (
            isinstance(supplier_id, bool)
            or not isinstance(supplier_id, int)
            or supplier_id < 1
        ):
            raise ValueError("A valid supplier is required.")
    except ValueError as error:
        return False, str(error)
    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        require_admin(connection, user)
        if supplier_id is None:
            connection.execute("""
                INSERT INTO suppliers (name, contact_name, phone, email, address)
                VALUES (:name, :contact_name, :phone, :email, :address)
            """, supplier)
        else:
            cursor = connection.execute("""
                UPDATE suppliers
                SET name = :name, contact_name = :contact_name, phone = :phone,
                    email = :email, address = :address
                WHERE id = :supplier_id
            """, {**supplier, "supplier_id": supplier_id})
            if cursor.rowcount != 1:
                raise ValueError("Supplier not found.")
        connection.commit()
        return True, "Supplier saved."
    except sqlite3.IntegrityError:
        if connection is not None:
            connection.rollback()
        return False, "A supplier with that name already exists."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def set_supplier_active(user, supplier_id, active):
    if (
        isinstance(supplier_id, bool) or not isinstance(supplier_id, int)
        or supplier_id < 1 or not isinstance(active, bool)
    ):
        return False, "A valid supplier and status are required."
    connection = None
    try:
        connection = get_connection()
        ensure_admin_schema(connection)
        require_admin(connection, user)
        cursor = connection.execute(
            "UPDATE suppliers SET is_active = ? WHERE id = ?",
            (int(active), supplier_id)
        )
        if cursor.rowcount != 1:
            raise ValueError("Supplier not found.")
        connection.commit()
        return True, "Supplier status updated."
    except (sqlite3.Error, PermissionError, ValueError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()
