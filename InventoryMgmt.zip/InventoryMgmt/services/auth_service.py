# Import SQLite connection function.
from database.db_connection import get_connection

# Import hashlib to verify password hashes.
import hashlib
import hmac


def verify_password(password, stored_password):
    """
    Check whether the entered password matches
    the password hash stored in the database.
    """

    # Our stored value contains the salt and hash,
    # separated by the '$' character.
    salt_hex, stored_hash = stored_password.split("$")

    # Convert the hexadecimal salt back into bytes.
    salt = bytes.fromhex(salt_hex)

    # Hash the entered password using the same method
    # and number of iterations used during account creation.
    entered_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        600_000
    )

    # Compare the newly calculated hash with the stored hash.
    # compare_digest helps avoid timing-based comparison leaks.
    return hmac.compare_digest(
    entered_hash.hex(),
    stored_hash
)


def authenticate_user(username, password):
    """
    Verify the user's credentials.

    Returns the user's account information if the credentials
    are correct and the account is active.
    Otherwise, returns None.
    """

    # Open a connection to our SQLite database.
    connection = get_connection()

    try:
        # Search for the account using its username.
        # The question mark is a parameter placeholder.
        user = connection.execute(
            """
            SELECT id, username, password_hash, role, is_active
            FROM users
            WHERE username = ?
            """,
            (username,)
        ).fetchone()

    finally:
        # Close the connection even if the query fails.
        connection.close()

    # Reject unknown usernames.
    if user is None:
        return None

    user_id, db_username, stored_hash, role, is_active = user

    # Reject disabled accounts.
    if not is_active:
        return None

    # Verify the entered password.
    if verify_password(password, stored_hash):
        # Return the account details without its password hash.
        return {
            "id": user_id,
            "username": db_username,
            "role": role
        }

    # Incorrect password.
    return None