import csv
import html
import sqlite3
import uuid
from collections.abc import Mapping
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

from database.db_connection import get_connection
from database.admin_schema import ensure_admin_schema
from database.inventory_schema import ensure_inventory_movement_table
from database.sales_schema import ensure_sales_schema


SALES_ROLES = frozenset({"admin", "manager", "salesperson"})
SALE_CREATE_ROLES = frozenset({"admin", "salesperson"})
MAX_SQLITE_INTEGER = (1 << 63) - 1
CENT = Decimal("0.01")


def _connect():
    connection = get_connection()
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        ensure_admin_schema(connection)
        ensure_inventory_movement_table(connection)
        ensure_sales_schema(connection)
        connection.commit()
        return connection
    except sqlite3.Error:
        connection.close()
        raise


def _validate_user(connection, user):
    if not isinstance(user, Mapping):
        raise PermissionError("A valid authenticated user is required.")
    user_id = user.get("id")
    role = user.get("role")
    if (
        isinstance(user_id, bool)
        or not isinstance(user_id, int)
        or not 1 <= user_id <= MAX_SQLITE_INTEGER
        or not isinstance(role, str)
        or role not in SALES_ROLES
    ):
        raise PermissionError("Your role is not authorized to access sales.")

    account = connection.execute(
        "SELECT role, is_active FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()
    if account is None or not account[1] or account[0] != role:
        raise PermissionError("The authenticated account is no longer active or valid.")
    return user_id


def _decimal_percent(value, label):
    if isinstance(value, bool):
        raise ValueError(f"{label} must be a number from 0 to 100.")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f"{label} must be a number from 0 to 100.") from None
    if not result.is_finite() or result < 0 or result > 100:
        raise ValueError(f"{label} must be a number from 0 to 100.")
    return result


def _validate_cart_items(items):
    if not isinstance(items, (list, tuple)) or not items:
        raise ValueError("Add at least one product to the bill.")

    quantities = {}
    for item in items:
        if not isinstance(item, Mapping):
            raise ValueError("Each bill item must contain a product ID and quantity.")
        product_id = item.get("product_id")
        quantity = item.get("quantity")
        if (
            isinstance(product_id, bool)
            or not isinstance(product_id, int)
            or not 1 <= product_id <= MAX_SQLITE_INTEGER
        ):
            raise ValueError("Product IDs must be positive whole numbers.")
        if (
            isinstance(quantity, bool)
            or not isinstance(quantity, int)
            or not 1 <= quantity <= MAX_SQLITE_INTEGER
        ):
            raise ValueError("Sale quantities must be positive whole numbers.")
        quantities[product_id] = quantities.get(product_id, 0) + quantity
        if quantities[product_id] > MAX_SQLITE_INTEGER:
            raise ValueError("Combined quantity is too large.")
    return quantities


def _money(value):
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def _generate_invoice_number(prefix="INV-"):
    return f"{prefix}{datetime.now():%Y%m%d}-{uuid.uuid4().hex.upper()}"


def search_sellable_products(user, search_text=""):
    """Search active, in-stock products using their current selling prices."""

    if not isinstance(search_text, str):
        raise ValueError("Product search text must be text.")
    pattern = f"%{search_text.strip()}%"
    connection = _connect()
    try:
        _validate_user(connection, user)
        if user["role"] not in SALE_CREATE_ROLES:
            raise PermissionError("Your role is not authorized to create sales.")
        rows = connection.execute("""
            SELECT id, product_name, sku, category, selling_price, stock_quantity
            FROM products
            WHERE is_active = 1
              AND stock_quantity > 0
              AND (product_name LIKE ? OR sku LIKE ?)
            ORDER BY product_name COLLATE NOCASE, id
        """, (pattern, pattern)).fetchall()
        return [
            {
                "id": row[0],
                "product_name": row[1],
                "sku": row[2],
                "category": row[3],
                "selling_price": row[4],
                "stock_quantity": row[5]
            }
            for row in rows
        ]
    finally:
        connection.close()


def create_sale(user, items, gst_percent=0, discount_percent=0, invoice_number=None):
    """Create an invoice and atomically deduct stock and record sale movements."""

    try:
        quantities = _validate_cart_items(items)
        gst_rate = _decimal_percent(gst_percent, "GST")
        discount = _decimal_percent(discount_percent, "Discount")
        if invoice_number is not None and (
            not isinstance(invoice_number, str) or not invoice_number.strip()
        ):
            raise ValueError("Invoice number must be non-empty text.")
    except ValueError as error:
        return False, str(error), None

    connection = None
    try:
        connection = _connect()
        connection.execute("BEGIN IMMEDIATE")
        user_id = _validate_user(connection, user)
        if user["role"] not in SALE_CREATE_ROLES:
            raise PermissionError("Your role is not authorized to create sales.")

        settings = dict(connection.execute(
            "SELECT setting_key, setting_value FROM app_settings"
        ).fetchall())
        invoice_prefix = settings.get("invoice_prefix", "INV-")
        bill_lines = []
        subtotal = Decimal("0.00")
        item_tax_rates = {}
        for item in items:
            product_id = item["product_id"]
            item_tax_rates[product_id] = _decimal_percent(
                item.get("tax_rate", gst_rate),
                "GST"
            )

        for product_id, quantity in sorted(quantities.items()):
            product = connection.execute("""
                SELECT product_name, sku, selling_price, stock_quantity
                FROM products
                WHERE id = ? AND is_active = 1
            """, (product_id,)).fetchone()
            if product is None:
                raise ValueError(f"Product {product_id} is not available for sale.")
            name, sku, price_value, stock = product
            if stock < quantity:
                raise ValueError(
                    f"Insufficient stock for {name} ({sku}): "
                    f"{stock} available, {quantity} requested."
                )
            price = Decimal(str(price_value))
            if not price.is_finite() or price < 0:
                raise ValueError(f"Product {name} has an invalid selling price.")
            price = _money(price)
            line_total = _money(price * quantity)
            subtotal += line_total
            bill_lines.append({
                "product_id": product_id,
                "product_name": name,
                "sku": sku,
                "quantity": quantity,
                "unit_price": price,
                "line_subtotal": line_total,
                "previous_stock": stock
            })

        subtotal = _money(subtotal)
        discount_amount = _money(subtotal * discount / Decimal("100"))
        remaining_discount = discount_amount
        gst_amount = Decimal("0.00")
        for index, line in enumerate(bill_lines):
            if index == len(bill_lines) - 1:
                line_discount = remaining_discount
            elif subtotal:
                line_discount = _money(
                    discount_amount * line["line_subtotal"] / subtotal
                )
                remaining_discount -= line_discount
            else:
                line_discount = Decimal("0.00")
            line["discount_amount"] = line_discount
            line["tax_rate"] = item_tax_rates[line["product_id"]]
            taxable_line = line["line_subtotal"] - line_discount
            line["line_total"] = _money(taxable_line)
            line["tax_amount"] = _money(
                taxable_line * line["tax_rate"] / Decimal("100")
            )
            gst_amount += line["tax_amount"]
        taxable_amount = subtotal - discount_amount
        gst_amount = _money(gst_amount)
        effective_gst = (
            gst_amount * Decimal("100") / taxable_amount
            if taxable_amount
            else Decimal("0")
        )
        total = _money(taxable_amount + gst_amount)
        invoice = (
            invoice_number.strip()
            if invoice_number
            else _generate_invoice_number(invoice_prefix)
        )

        cursor = connection.execute("""
            INSERT INTO sales (
                invoice_number, subtotal, gst_percent, gst_amount,
                discount_percent, discount_amount, total_amount, sold_by,
                business_name, business_address, business_phone,
                business_email, currency_symbol
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            invoice,
            float(subtotal),
            float(effective_gst),
            float(gst_amount),
            float(discount),
            float(discount_amount),
            float(total),
            user_id,
            settings.get("business_name", ""),
            settings.get("business_address", ""),
            settings.get("business_phone", ""),
            settings.get("business_email", ""),
            settings.get("currency_symbol", "₹")
        ))
        sale_id = cursor.lastrowid

        for line in bill_lines:
            new_stock = line["previous_stock"] - line["quantity"]
            connection.execute("""
                INSERT INTO sale_items (
                    sale_id, product_id, product_name, sku, quantity,
                    unit_price, discount_amount, tax_rate, tax_amount,
                    tax_rate_recorded, line_total
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                sale_id,
                line["product_id"],
                line["product_name"],
                line["sku"],
                line["quantity"],
                float(line["unit_price"]),
                float(line["discount_amount"]),
                float(line["tax_rate"]),
                float(line["tax_amount"]),
                1,
                float(line["line_total"])
            ))
            updated = connection.execute("""
                UPDATE products
                SET stock_quantity = stock_quantity - ?
                WHERE id = ? AND is_active = 1 AND stock_quantity >= ?
            """, (line["quantity"], line["product_id"], line["quantity"]))
            if updated.rowcount != 1:
                raise ValueError(
                    f"Stock changed while processing {line['product_name']}; retry the sale."
                )
            connection.execute("""
                INSERT INTO inventory_movements (
                    product_id, movement_type, quantity, previous_stock,
                    new_stock, notes, performed_by
                )
                VALUES (?, 'sale', ?, ?, ?, ?, ?)
            """, (
                line["product_id"],
                line["quantity"],
                line["previous_stock"],
                new_stock,
                f"Invoice {invoice}",
                user_id
            ))

        connection.commit()
        return True, f"Sale completed. Invoice {invoice}.", invoice
    except (
        sqlite3.Error,
        PermissionError,
        ValueError,
        OverflowError,
        InvalidOperation
    ) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error), None
    finally:
        if connection is not None:
            connection.close()


def _validated_date_range(start_date, end_date):
    normalized = []
    for value in (start_date, end_date):
        if value in (None, ""):
            normalized.append(None)
            continue
        if not isinstance(value, str):
            raise ValueError("Enter dates in YYYY-MM-DD format.")
        try:
            parsed = date.fromisoformat(value)
        except ValueError:
            raise ValueError("Enter dates in YYYY-MM-DD format.") from None
        if parsed.isoformat() != value:
            raise ValueError("Enter dates in YYYY-MM-DD format.")
        normalized.append(value)
    start, end = normalized
    if start and end and end < start:
        raise ValueError("End date must be on or after start date.")
    return start, end


def search_sales(user, search_text="", start_date=None, end_date=None):
    """Find authorized invoices by invoice, username, and optional date range."""

    if not isinstance(search_text, str):
        raise ValueError("Invoice search text must be text.")
    start_date, end_date = _validated_date_range(start_date, end_date)
    pattern = f"%{search_text.strip()}%"
    connection = _connect()
    try:
        user_id = _validate_user(connection, user)
        role = user["role"]
        if role == "manager":
            raise PermissionError("Managers may view sales summaries, not individual invoices.")
        query = """
            SELECT s.id, s.invoice_number, s.subtotal, s.gst_percent,
                   s.gst_amount, s.discount_percent, s.discount_amount,
                   s.total_amount, s.created_at, u.username,
                   COUNT(si.id) AS item_count, s.currency_symbol
            FROM sales AS s
            LEFT JOIN users AS u ON u.id = s.sold_by
            LEFT JOIN sale_items AS si ON si.sale_id = s.id
            WHERE (s.invoice_number LIKE ? OR u.username LIKE ?)
        """
        parameters = [pattern, pattern]
        if role == "salesperson":
            query += " AND s.sold_by = ?"
            parameters.append(user_id)
        if start_date:
            query += " AND date(s.created_at, 'localtime') >= ?"
            parameters.append(start_date)
        if end_date:
            query += " AND date(s.created_at, 'localtime') <= ?"
            parameters.append(end_date)
        query += """
            GROUP BY s.id
            ORDER BY s.created_at DESC, s.id DESC
            LIMIT 200
        """
        rows = connection.execute(query, parameters).fetchall()
        return [
            {
                "id": row[0],
                "invoice_number": row[1],
                "subtotal": row[2],
                "gst_percent": row[3],
                "gst_amount": row[4],
                "discount_percent": row[5],
                "discount_amount": row[6],
                "total_amount": row[7],
                "created_at": row[8],
                "sold_by_username": row[9],
                "item_count": row[10],
                "currency_symbol": row[11] or "₹"
            }
            for row in rows
        ]
    finally:
        connection.close()


def get_sale_details(user, invoice_number):
    """Retrieve a saved invoice and its historical line-item snapshots."""

    if not isinstance(invoice_number, str) or not invoice_number.strip():
        raise ValueError("Invoice number must be non-empty text.")
    connection = _connect()
    try:
        user_id = _validate_user(connection, user)
        if user["role"] == "manager":
            raise PermissionError("Managers may view sales summaries, not invoice details.")
        query = """
            SELECT s.id, s.invoice_number, s.subtotal, s.gst_percent,
                   s.gst_amount, s.discount_percent, s.discount_amount,
                   s.total_amount, s.created_at, u.username,
                   s.business_name, s.business_address, s.business_phone,
                   s.business_email, s.currency_symbol
            FROM sales AS s
            LEFT JOIN users AS u ON u.id = s.sold_by
            WHERE s.invoice_number = ?
        """
        parameters = [invoice_number.strip()]
        if user["role"] == "salesperson":
            query += " AND s.sold_by = ?"
            parameters.append(user_id)
        sale = connection.execute(query, parameters).fetchone()
        if sale is None:
            return None
        items = connection.execute("""
            SELECT product_id, product_name, sku, quantity, unit_price,
                   discount_amount, tax_rate, tax_amount, line_total,
                   tax_rate_recorded
            FROM sale_items
            WHERE sale_id = ?
            ORDER BY id
        """, (sale[0],)).fetchall()
        return {
            "id": sale[0],
            "invoice_number": sale[1],
            "subtotal": sale[2],
            "gst_percent": sale[3],
            "gst_amount": sale[4],
            "discount_percent": sale[5],
            "discount_amount": sale[6],
            "total_amount": sale[7],
            "created_at": sale[8],
            "sold_by_username": sale[9],
            "business_name": sale[10],
            "business_address": sale[11],
            "business_phone": sale[12],
            "business_email": sale[13],
            "currency_symbol": sale[14] or "₹",
            "items": [
                {
                    "product_id": row[0],
                    "product_name": row[1],
                    "sku": row[2],
                    "quantity": row[3],
                    "unit_price": row[4],
                    "discount_amount": row[5],
                    "tax_rate": row[6] if row[9] else None,
                    "tax_amount": row[7] if row[9] else None,
                    "line_total": row[8],
                    "tax_rate_recorded": bool(row[9])
                }
                for row in items
            ]
        }
    finally:
        connection.close()


def get_sales_summary(user):
    """Return aggregate sales totals for admins, managers, and the current seller."""

    connection = _connect()
    try:
        user_id = _validate_user(connection, user)
        query = """
            SELECT
                COUNT(*),
                COALESCE(SUM(subtotal), 0),
                COALESCE(SUM(discount_amount), 0),
                COALESCE(SUM(gst_amount), 0),
                COALESCE(SUM(total_amount), 0)
            FROM sales
        """
        parameters = ()
        if user["role"] == "salesperson":
            query += " WHERE sold_by = ?"
            parameters = (user_id,)
        row = connection.execute(query, parameters).fetchone()
        return {
            "invoice_count": row[0],
            "subtotal": row[1],
            "discount_amount": row[2],
            "tax_amount": row[3],
            "total_amount": row[4]
        }
    finally:
        connection.close()


def get_salesperson_dashboard_statistics(user):
    """Return live dashboard data scoped to the authenticated salesperson."""

    connection = _connect()
    try:
        user_id = _validate_user(connection, user)
        if user["role"] != "salesperson":
            raise PermissionError("Salesperson dashboard access is required.")

        today = connection.execute("""
            SELECT COUNT(*), COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE sold_by = ?
              AND date(created_at, 'localtime') = date('now', 'localtime')
        """, (user_id,)).fetchone()
        weekly_sales = connection.execute("""
            SELECT COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE sold_by = ?
              AND date(created_at, 'localtime')
                  >= date('now', 'localtime', '-6 days')
        """, (user_id,)).fetchone()[0]
        monthly_sales = connection.execute("""
            SELECT COALESCE(SUM(total_amount), 0)
            FROM sales
            WHERE sold_by = ?
              AND strftime('%Y-%m', created_at, 'localtime')
                  = strftime('%Y-%m', 'now', 'localtime')
        """, (user_id,)).fetchone()[0]
        today_items_sold = connection.execute("""
            SELECT COALESCE(SUM(si.quantity), 0)
            FROM sale_items AS si
            JOIN sales AS s ON s.id = si.sale_id
            WHERE s.sold_by = ?
              AND date(s.created_at, 'localtime') = date('now', 'localtime')
        """, (user_id,)).fetchone()[0]
        recent_transactions = connection.execute("""
            SELECT s.invoice_number, s.created_at, s.total_amount,
                   COUNT(si.id), s.currency_symbol
            FROM sales AS s
            LEFT JOIN sale_items AS si ON si.sale_id = s.id
            WHERE s.sold_by = ?
            GROUP BY s.id
            ORDER BY s.created_at DESC, s.id DESC
            LIMIT 8
        """, (user_id,)).fetchall()
        low_stock = connection.execute("""
            SELECT product_name, sku, stock_quantity, minimum_stock
            FROM products
            WHERE is_active = 1 AND stock_quantity <= minimum_stock
            ORDER BY stock_quantity, product_name COLLATE NOCASE
            LIMIT 8
        """).fetchall()
        currency_symbol = connection.execute("""
            SELECT setting_value
            FROM app_settings
            WHERE setting_key = 'currency_symbol'
        """).fetchone()[0]
        return {
            "today_invoice_count": today[0],
            "today_sales": today[1],
            "today_items_sold": today_items_sold,
            "weekly_sales": weekly_sales,
            "monthly_sales": monthly_sales,
            "recent_transactions": [
                {
                    "invoice_number": row[0],
                    "created_at": row[1],
                    "total_amount": row[2],
                    "item_count": row[3],
                    "currency_symbol": row[4] or currency_symbol,
                }
                for row in recent_transactions
            ],
            "low_stock": [
                {
                    "product_name": row[0],
                    "sku": row[1],
                    "stock_quantity": row[2],
                    "minimum_stock": row[3],
                }
                for row in low_stock
            ],
            "currency_symbol": currency_symbol,
        }
    finally:
        connection.close()


def get_salesperson_report(user, start_date, end_date):
    """Return report data for the authenticated salesperson's own sales."""

    start_date, end_date = _validated_date_range(start_date, end_date)
    if not start_date or not end_date:
        raise ValueError("Choose both a start date and an end date.")
    connection = _connect()
    try:
        user_id = _validate_user(connection, user)
        if user["role"] != "salesperson":
            raise PermissionError("Salesperson reports are available only to salespeople.")

        parameters = (user_id, start_date, end_date)
        totals = connection.execute("""
            SELECT COUNT(*), COALESCE(SUM(s.subtotal), 0),
                   COALESCE(SUM(s.discount_amount), 0),
                   COALESCE(SUM(s.gst_amount), 0),
                   COALESCE(SUM(s.total_amount), 0)
            FROM sales AS s
            WHERE s.sold_by = ?
              AND date(s.created_at, 'localtime') BETWEEN ? AND ?
        """, parameters).fetchone()
        items_sold = connection.execute("""
            SELECT COALESCE(SUM(si.quantity), 0)
            FROM sale_items AS si
            JOIN sales AS s ON s.id = si.sale_id
            WHERE s.sold_by = ?
              AND date(s.created_at, 'localtime') BETWEEN ? AND ?
        """, parameters).fetchone()[0]
        daily_sales = connection.execute("""
            SELECT date(s.created_at, 'localtime'), COUNT(*),
                   COALESCE(SUM(s.total_amount), 0)
            FROM sales AS s
            WHERE s.sold_by = ?
              AND date(s.created_at, 'localtime') BETWEEN ? AND ?
            GROUP BY date(s.created_at, 'localtime')
            ORDER BY date(s.created_at, 'localtime')
        """, parameters).fetchall()
        top_products = connection.execute("""
            SELECT si.product_name, si.sku, SUM(si.quantity),
                   SUM(si.line_total + COALESCE(si.tax_amount, 0))
            FROM sale_items AS si
            JOIN sales AS s ON s.id = si.sale_id
            WHERE s.sold_by = ?
              AND date(s.created_at, 'localtime') BETWEEN ? AND ?
            GROUP BY si.product_id, si.product_name, si.sku
            ORDER BY SUM(si.quantity) DESC, SUM(si.line_total) DESC
            LIMIT 20
        """, parameters).fetchall()
        sales_history = connection.execute("""
            SELECT s.invoice_number, s.created_at, s.subtotal,
                   s.discount_amount, s.gst_amount, s.total_amount,
                   COUNT(si.id), s.currency_symbol
            FROM sales AS s
            LEFT JOIN sale_items AS si ON si.sale_id = s.id
            WHERE s.sold_by = ?
              AND date(s.created_at, 'localtime') BETWEEN ? AND ?
            GROUP BY s.id
            ORDER BY s.created_at DESC, s.id DESC
        """, parameters).fetchall()
        currency_symbol = connection.execute("""
            SELECT setting_value
            FROM app_settings
            WHERE setting_key = 'currency_symbol'
        """).fetchone()[0]
        connection.commit()
        return {
            "start_date": start_date,
            "end_date": end_date,
            "currency_symbol": currency_symbol,
            "summary": {
                "invoice_count": totals[0],
                "subtotal": totals[1],
                "discount_amount": totals[2],
                "tax_amount": totals[3],
                "total_amount": totals[4],
                "items_sold": items_sold,
            },
            "daily_sales": [
                {
                    "date": row[0],
                    "invoice_count": row[1],
                    "total_amount": row[2],
                }
                for row in daily_sales
            ],
            "top_products": [
                {
                    "product_name": row[0],
                    "sku": row[1],
                    "quantity_sold": row[2],
                    "sales_total": row[3],
                }
                for row in top_products
            ],
            "sales_history": [
                {
                    "invoice_number": row[0],
                    "created_at": row[1],
                    "subtotal": row[2],
                    "discount_amount": row[3],
                    "tax_amount": row[4],
                    "total_amount": row[5],
                    "item_count": row[6],
                    "currency_symbol": row[7] or currency_symbol,
                }
                for row in sales_history
            ],
        }
    except sqlite3.Error:
        connection.rollback()
        raise
    finally:
        connection.close()


def export_salesperson_report_csv(user, report_type, start_date, end_date, destination):
    """Export only the current salesperson's date-filtered report rows."""

    fields = {
        "daily_sales": ("date", "invoice_count", "total_amount"),
        "top_products": ("product_name", "sku", "quantity_sold", "sales_total"),
        "sales_history": (
            "invoice_number",
            "created_at",
            "subtotal",
            "discount_amount",
            "tax_amount",
            "total_amount",
            "item_count",
        ),
    }
    if report_type not in fields:
        raise ValueError("Choose a supported salesperson report to export.")
    if not isinstance(destination, (str, Path)) or not str(destination).strip():
        raise ValueError("Choose a CSV destination.")
    report = get_salesperson_report(user, start_date, end_date)
    try:
        with Path(destination).open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields[report_type])
            writer.writeheader()
            for row in report[report_type]:
                writer.writerow({
                    key: (
                        "'" + value
                        if isinstance(value, str)
                        and value.startswith(("=", "+", "-", "@"))
                        else value
                    )
                    for key, value in row.items()
                    if key in fields[report_type]
                })
    except OSError:
        raise
    return len(report[report_type])


def render_invoice_html(invoice):
    """Render saved invoice data as a standalone, print-ready HTML document."""

    if not isinstance(invoice, Mapping) or not invoice.get("invoice_number"):
        raise ValueError("A saved invoice is required.")
    escape = html.escape
    currency = escape(str(invoice.get("currency_symbol", "₹")))
    rows = []
    for item in invoice["items"]:
        if item["tax_rate"] is None or item["tax_amount"] is None:
            tax_rate = "Not recorded"
            tax_amount = "—"
        else:
            tax_rate = f"{item['tax_rate']:g}%"
            tax_amount = f"{currency}{item['tax_amount']:,.2f}"
        rows.append(
            "<tr>"
            f"<td>{escape(str(item['product_name']))}</td>"
            f"<td>{escape(str(item['sku']))}</td>"
            f"<td class='number'>{item['quantity']}</td>"
            f"<td class='number'>{currency}{item['unit_price']:,.2f}</td>"
            f"<td class='number'>{tax_rate}</td>"
            f"<td class='number'>{tax_amount}</td>"
            f"<td class='number'>{currency}{item['line_total']:,.2f}</td>"
            "</tr>"
        )
    rows = "".join(rows)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Invoice {escape(str(invoice['invoice_number']))}</title>
<style>
body {{ color: #172b4d; font: 14px Arial, sans-serif; margin: 36px auto; max-width: 850px; }}
h1 {{ margin-bottom: 4px; }} .muted {{ color: #64748b; }}
table {{ border-collapse: collapse; margin-top: 24px; width: 100%; }}
th, td {{ border-bottom: 1px solid #dbe3ef; padding: 10px; text-align: left; }}
th {{ background: #f1f5f9; }} .number {{ text-align: right; }}
.totals {{ margin: 22px 0 0 auto; width: 320px; }}
.totals td {{ border: 0; padding: 5px; }} .grand {{ border-top: 2px solid #172b4d !important; font-weight: bold; }}
@media print {{ body {{ margin: 0; }} }}
</style>
</head>
<body>
<h1>INVOICE</h1>
<div class="muted">{escape(str(invoice.get('business_name') or 'Inventory Management System'))}</div>
<div class="muted">{escape(str(invoice.get('business_address') or ''))}</div>
<div class="muted">{escape(str(invoice.get('business_phone') or ''))} {escape(str(invoice.get('business_email') or ''))}</div>
<p><strong>Invoice:</strong> {escape(str(invoice['invoice_number']))}<br>
<strong>Date:</strong> {escape(str(invoice['created_at']))}<br>
<strong>Sold by:</strong> {escape(str(invoice['sold_by_username'] or ''))}</p>
<table><thead><tr><th>Product</th><th>SKU</th><th class="number">Qty</th>
<th class="number">Unit price</th><th class="number">GST</th>
<th class="number">Tax</th><th class="number">Line amount before tax</th></tr></thead>
<tbody>{rows}</tbody></table>
<table class="totals">
<tr><td>Subtotal</td><td class="number">{currency}{invoice['subtotal']:,.2f}</td></tr>
<tr><td>Discount ({invoice['discount_percent']:g}%)</td>
<td class="number">- {currency}{invoice['discount_amount']:,.2f}</td></tr>
<tr><td>GST (effective rate {invoice['gst_percent']:g}%)</td>
<td class="number">{currency}{invoice['gst_amount']:,.2f}</td></tr>
<tr class="grand"><td>Total</td><td class="number">{currency}{invoice['total_amount']:,.2f}</td></tr>
</table>
</body>
</html>"""
