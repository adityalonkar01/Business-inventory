import sqlite3
import math
from collections.abc import Mapping
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from database.admin_schema import ensure_admin_schema
from database.db_connection import get_connection
from database.inventory_schema import ensure_inventory_movement_table
from services.admin_access import require_roles


PURCHASE_ROLES = frozenset({"admin", "manager"})
CENT = Decimal("0.01")
MAX_SQLITE_INTEGER = (1 << 63) - 1


def _validate_items(items):
    if not isinstance(items, (list, tuple)) or not items:
        raise ValueError("Add at least one product to the purchase.")
    result = {}
    for item in items:
        if not isinstance(item, Mapping):
            raise ValueError("Each purchase item must include a product and quantity.")
        product_id, quantity = item.get("product_id"), item.get("quantity")
        if (
            isinstance(product_id, bool) or not isinstance(product_id, int)
            or not 1 <= product_id <= MAX_SQLITE_INTEGER
        ):
            raise ValueError("Product IDs must be positive whole numbers.")
        if (
            isinstance(quantity, bool) or not isinstance(quantity, int)
            or not 1 <= quantity <= MAX_SQLITE_INTEGER
        ):
            raise ValueError("Purchase quantities must be positive whole numbers.")
        try:
            unit_cost = Decimal(str(item.get("unit_cost")))
        except (InvalidOperation, TypeError, ValueError):
            raise ValueError("Unit costs must be valid non-negative amounts.") from None
        try:
            unit_cost_float = float(unit_cost)
        except (OverflowError, ValueError):
            unit_cost_float = float("inf")
        if not unit_cost.is_finite() or unit_cost < 0 or not math.isfinite(unit_cost_float):
            raise ValueError("Unit costs must be valid non-negative amounts.")
        try:
            rounded_cost = unit_cost.quantize(CENT, rounding=ROUND_HALF_UP)
        except (InvalidOperation, OverflowError):
            raise ValueError("Unit costs are too large to store.") from None
        result[product_id] = (
            result.get(product_id, (0, Decimal("0")))[0] + quantity,
            rounded_cost
        )
        if result[product_id][0] != quantity:
            raise ValueError("Each product may appear only once in a purchase.")
    if any(quantity > MAX_SQLITE_INTEGER for quantity, _cost in result.values()):
        raise ValueError("Combined purchase quantity is too large.")
    return result


def _connect():
    connection = get_connection()
    connection.execute("PRAGMA foreign_keys = ON")
    ensure_admin_schema(connection)
    ensure_inventory_movement_table(connection)
    connection.commit()
    return connection


def create_purchase(user, purchase_ref, supplier_id, items, notes=""):
    try:
        if not isinstance(purchase_ref, str) or not purchase_ref.strip() or len(purchase_ref.strip()) > 80:
            raise ValueError("Purchase reference is required (maximum 80 characters).")
        if isinstance(supplier_id, bool) or not isinstance(supplier_id, int) or supplier_id < 1:
            raise ValueError("Choose a valid supplier.")
        if not isinstance(notes, str) or len(notes.strip()) > 500:
            raise ValueError("Purchase notes must be text of at most 500 characters.")
        normalized_items = _validate_items(items)
    except ValueError as error:
        return False, str(error), None

    connection = None
    try:
        connection = _connect()
        connection.execute("BEGIN IMMEDIATE")
        actor_id = require_roles(connection, user, PURCHASE_ROLES)
        supplier = connection.execute(
            "SELECT id FROM suppliers WHERE id = ? AND is_active = 1",
            (supplier_id,)
        ).fetchone()
        if supplier is None:
            raise ValueError("Supplier is not active or does not exist.")
        lines = []
        total = Decimal("0")
        for product_id, (quantity, unit_cost) in sorted(normalized_items.items()):
            product = connection.execute("""
                SELECT product_name, sku
                FROM products WHERE id = ? AND is_active = 1
            """, (product_id,)).fetchone()
            if product is None:
                raise ValueError(f"Product {product_id} is not active or does not exist.")
            line_total = (unit_cost * quantity).quantize(CENT, rounding=ROUND_HALF_UP)
            if not math.isfinite(float(line_total)):
                raise ValueError("Purchase total is too large to store.")
            total += line_total
            lines.append((product_id, product[0], product[1], quantity, unit_cost, line_total))
        if not math.isfinite(float(total)):
            raise ValueError("Purchase total is too large to store.")
        cursor = connection.execute("""
            INSERT INTO purchases (purchase_ref, supplier_id, total_amount, notes, created_by)
            VALUES (?, ?, ?, ?, ?)
        """, (
            purchase_ref.strip(), supplier_id, float(total),
            notes.strip(), actor_id
        ))
        purchase_id = cursor.lastrowid
        connection.executemany("""
            INSERT INTO purchase_items (
                purchase_id, product_id, product_name, sku, quantity, unit_cost, line_total
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, [
            (purchase_id, product_id, name, sku, quantity, float(cost), float(line_total))
            for product_id, name, sku, quantity, cost, line_total in lines
        ])
        connection.commit()
        return True, f"Purchase {purchase_ref.strip()} saved as a draft.", purchase_id
    except sqlite3.IntegrityError as error:
        if connection is not None:
            connection.rollback()
        if "purchases.purchase_ref" in str(error):
            return False, "That purchase reference already exists.", None
        return False, f"Unable to save purchase: {error}", None
    except (
        sqlite3.Error, PermissionError, ValueError, OverflowError, InvalidOperation
    ) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error), None
    finally:
        if connection is not None:
            connection.close()


def receive_purchase(user, purchase_id):
    if isinstance(purchase_id, bool) or not isinstance(purchase_id, int) or purchase_id < 1:
        return False, "A valid purchase is required."
    connection = None
    try:
        connection = _connect()
        connection.execute("BEGIN IMMEDIATE")
        actor_id = require_roles(connection, user, PURCHASE_ROLES)
        purchase = connection.execute(
            "SELECT purchase_ref, status FROM purchases WHERE id = ?",
            (purchase_id,)
        ).fetchone()
        if purchase is None:
            raise ValueError("Purchase not found.")
        if purchase[1] != "draft":
            raise ValueError("This purchase has already been received.")
        items = connection.execute("""
            SELECT product_id, product_name, quantity, unit_cost
            FROM purchase_items WHERE purchase_id = ? ORDER BY id
        """, (purchase_id,)).fetchall()
        if not items:
            raise ValueError("This purchase has no items.")
        for product_id, name, quantity, unit_cost in items:
            product = connection.execute(
                "SELECT stock_quantity FROM products WHERE id = ? AND is_active = 1",
                (product_id,)
            ).fetchone()
            if product is None:
                raise ValueError(f"Product {name} is not active or no longer exists.")
            previous = product[0]
            if previous > MAX_SQLITE_INTEGER - quantity:
                raise ValueError(f"Receiving {name} would exceed the supported stock limit.")
            new_stock = previous + quantity
            connection.execute("""
                UPDATE products SET stock_quantity = ?, purchase_price = ?
                WHERE id = ? AND is_active = 1 AND stock_quantity = ?
            """, (new_stock, float(unit_cost), product_id, previous))
            if connection.execute("SELECT changes()").fetchone()[0] != 1:
                raise ValueError(f"Stock changed while receiving {name}; retry the operation.")
            connection.execute("""
                INSERT INTO inventory_movements (
                    product_id, movement_type, quantity, previous_stock,
                    new_stock, notes, performed_by
                ) VALUES (?, 'receipt', ?, ?, ?, ?, ?)
            """, (
                product_id, quantity, previous, new_stock,
                f"Purchase {purchase[0]}", actor_id
            ))
        connection.execute("""
            UPDATE purchases
            SET status = 'received', received_by = ?, received_at = CURRENT_TIMESTAMP
            WHERE id = ? AND status = 'draft'
        """, (actor_id, purchase_id))
        if connection.execute("SELECT changes()").fetchone()[0] != 1:
            raise ValueError("Purchase status changed; reload and retry.")
        connection.commit()
        return True, f"Purchase {purchase[0]} received and stock updated."
    except (sqlite3.Error, PermissionError, ValueError, OverflowError) as error:
        if connection is not None:
            connection.rollback()
        return False, str(error)
    finally:
        if connection is not None:
            connection.close()


def list_purchases(user, search_text=""):
    if not isinstance(search_text, str):
        raise ValueError("Purchase search text must be text.")
    connection = _connect()
    try:
        require_roles(connection, user, PURCHASE_ROLES)
        pattern = f"%{search_text.strip()}%"
        rows = connection.execute("""
            SELECT p.id, p.purchase_ref, s.name, p.status, p.total_amount,
                   p.created_at, p.received_at, u.username
            FROM purchases AS p
            JOIN suppliers AS s ON s.id = p.supplier_id
            JOIN users AS u ON u.id = p.created_by
            WHERE p.purchase_ref LIKE ? OR s.name LIKE ?
            ORDER BY p.created_at DESC, p.id DESC LIMIT 200
        """, (pattern, pattern)).fetchall()
        connection.commit()
        return [
            {
                "id": row[0], "purchase_ref": row[1], "supplier": row[2],
                "status": row[3], "total_amount": row[4], "created_at": row[5],
                "received_at": row[6], "created_by": row[7]
            }
            for row in rows
        ]
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()


def get_purchase_details(user, purchase_id):
    if isinstance(purchase_id, bool) or not isinstance(purchase_id, int) or purchase_id < 1:
        raise ValueError("A valid purchase is required.")
    connection = _connect()
    try:
        require_roles(connection, user, PURCHASE_ROLES)
        header = connection.execute("""
            SELECT p.id, p.purchase_ref, p.status, p.total_amount, p.notes,
                   p.created_at, p.received_at, s.name
            FROM purchases AS p JOIN suppliers AS s ON s.id = p.supplier_id
            WHERE p.id = ?
        """, (purchase_id,)).fetchone()
        if header is None:
            return None
        lines = connection.execute("""
            SELECT product_id, product_name, sku, quantity, unit_cost, line_total
            FROM purchase_items WHERE purchase_id = ? ORDER BY id
        """, (purchase_id,)).fetchall()
        connection.commit()
        return {
            "id": header[0], "purchase_ref": header[1], "status": header[2],
            "total_amount": header[3], "notes": header[4], "created_at": header[5],
            "received_at": header[6], "supplier": header[7],
            "items": [
                {
                    "product_id": row[0], "product_name": row[1], "sku": row[2],
                    "quantity": row[3], "unit_cost": row[4], "line_total": row[5]
                }
                for row in lines
            ]
        }
    except (sqlite3.Error, PermissionError):
        connection.rollback()
        raise
    finally:
        connection.close()
