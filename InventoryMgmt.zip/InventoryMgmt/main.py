import customtkinter as ctk

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


class InventoryApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        # Window configuration
        self.title("Inventory Management System")
        self.geometry("1100x650")
        self.minsize(900, 550)

        # Main grid configuration
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Sidebar
        self.sidebar = ctk.CTkFrame(
            self,
            width=220,
            corner_radius=0
        )
        self.sidebar.grid(
            row=0,
            column=0,
            sticky="nsew"
        )
        self.sidebar.grid_propagate(False)

        # Application title
        self.logo = ctk.CTkLabel(
            self.sidebar,
            text="INVENTORY\nMANAGER",
            font=("Arial", 22, "bold")
        )
        self.logo.pack(pady=(30, 40))

        # Navigation buttons
        self.create_nav_button("Dashboard")
        self.create_nav_button("Products")
        self.create_nav_button("Inventory")
        self.create_nav_button("Sales")
        self.create_nav_button("Reports")
        self.create_nav_button("Settings")

        # Main content container
        self.main_content = ctk.CTkFrame(
            self,
            corner_radius=0,
            fg_color="transparent"
        )
        self.main_content.grid(
            row=0,
            column=1,
            sticky="nsew",
            padx=25,
            pady=25
        )

        # Initial page
        self.show_section("Dashboard")

    def create_nav_button(self, name):

        button = ctk.CTkButton(
            self.sidebar,
            text=name,
            height=40,
            anchor="w",
            corner_radius=8,
            command=lambda: self.show_section(name)
        )

        button.pack(
            fill="x",
            padx=15,
            pady=6
        )

    def clear_content(self):
        """Remove widgets from the main content area."""

        for widget in self.main_content.winfo_children():
            widget.destroy()

    def show_section(self, section):

        if section == "Products":
            self.show_products_page()
        else:
            self.clear_content()

            heading = ctk.CTkLabel(
                self.main_content,
                text=section,
                font=("Arial", 26, "bold")
            )
            heading.pack(anchor="w", pady=(10, 20))

            description = ctk.CTkLabel(
                self.main_content,
                text=f"Welcome to the {section} section.",
                font=("Arial", 14)
            )
            description.pack(anchor="w")

    def show_products_page(self):

        # Clear the previous page
        self.clear_content()

        # Header row
        header = ctk.CTkFrame(
            self.main_content,
            fg_color="transparent"
        )
        header.pack(fill="x", pady=(10, 20))

        title = ctk.CTkLabel(
            header,
            text="Products",
            font=("Arial", 26, "bold")
        )
        title.pack(side="left")

        add_button = ctk.CTkButton(
            header,
            text="+ Add Product",
            width=140,
            height=38,
            command=self.add_product
        )
        add_button.pack(side="right")

        # Search field
        self.search_entry = ctk.CTkEntry(
            self.main_content,
            placeholder_text="Search products by name...",
            height=38
        )
        self.search_entry.pack(fill="x", pady=(0, 20))

        # Product table heading
        table = ctk.CTkFrame(self.main_content)
        table.pack(fill="both", expand=True)

        columns = [
            ("Product ID", 1),
            ("Product Name", 2),
            ("Category", 2),
            ("Price", 1),
            ("Quantity", 1)
        ]

        for column, (text, weight) in enumerate(columns):
            table.grid_columnconfigure(column, weight=weight)

            label = ctk.CTkLabel(
                table,
                text=text,
                font=("Arial", 13, "bold"),
                anchor="w"
            )
            label.grid(
                row=0,
                column=column,
                sticky="ew",
                padx=12,
                pady=15
            )

        # Empty state
        self.empty_label = ctk.CTkLabel(
            table,
            text="No products added yet.",
            font=("Arial", 14)
        )
        self.empty_label.grid(
            row=1,
            column=0,
            columnspan=len(columns),
            pady=40
        )

    def add_product(self):
        """Temporary placeholder until we implement the product form."""

        dialog = ctk.CTkToplevel(self)
        dialog.title("Add Product")
        dialog.geometry("350x200")
        dialog.transient(self)
        dialog.grab_set()

        label = ctk.CTkLabel(
            dialog,
            text="Product form will be added next!",
            font=("Arial", 15)
        )
        label.pack(pady=30)

        close_button = ctk.CTkButton(
            dialog,
            text="Close",
            command=dialog.destroy
        )
        close_button.pack()


if __name__ == "__main__":
    app = InventoryApp()
    app.mainloop()