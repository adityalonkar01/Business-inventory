from services.product_service import get_all_products, search_products


def main():
    """Manually inspect active products and search by name or SKU."""

    print("\n========== ALL PRODUCTS ==========\n")
    products = get_all_products()

    if not products:
        print("No products found in the database.")
    else:
        print("Products retrieved successfully!")
        print("-" * 70)

        for product in products:
            print(f"ID: {product[0]}")
            print(f"Name: {product[1]}")
            print(f"SKU: {product[2]}")
            print(f"Category: {product[3]}")
            print(f"Purchase Price: ₹{product[4]:,.2f}")
            print(f"Selling Price: ₹{product[5]:,.2f}")
            print(f"Available Stock: {product[6]}")
            print(f"Minimum Stock: {product[7]}")
            print("-" * 70)

        print(f"Total active products: {len(products)}")

    print("\n========== SEARCH PRODUCTS ==========\n")
    search_text = input("Enter product name or SKU: ")
    search_results = search_products(search_text)

    if not search_results:
        print("No matching products found.")
    else:
        print("\nMatching Products")
        print("-" * 70)
        for product in search_results:
            print(
                f"ID: {product[0]} | "
                f"Name: {product[1]} | "
                f"SKU: {product[2]} | "
                f"Category: {product[3]} | "
                f"Price: ₹{product[5]:,.2f} | "
                f"Stock: {product[6]}"
            )
        print("-" * 70)
        print(f"Total matching products: {len(search_results)}")


if __name__ == "__main__":
    main()
