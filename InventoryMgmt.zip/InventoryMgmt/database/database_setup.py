# Import the function that connects to our database.
from database.db_connection import get_connection
from database.inventory_schema import ensure_inventory_movement_table
from database.sales_schema import ensure_sales_schema
from database.admin_schema import ensure_admin_schema


def create_tables():
    """
    Create the tables required by our application.

    Initially, we will create the users table
    for login and authentication.
    """

    # Open a connection to the database.
    connection = get_connection()

    # A cursor allows us to execute SQL commands.
    cursor = connection.cursor()

    # Create the users table if it doesn't already exist.
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (

            -- Unique ID for every user.
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            -- Username used during login.
            username TEXT NOT NULL UNIQUE,

            -- Store the password hash, not the plain password.
            password_hash TEXT NOT NULL,

            -- Defines the user's role in the application.
            role TEXT NOT NULL
                CHECK (role IN ('admin', 'manager', 'salesperson')),

            -- Determines whether the account is active.
            is_active INTEGER NOT NULL DEFAULT 1
                CHECK (is_active IN (0, 1)),

            -- Records when the account was created.
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

        # Create the products table.
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            sku TEXT NOT NULL UNIQUE,
            category TEXT NOT NULL,
            purchase_price REAL NOT NULL DEFAULT 0,
            selling_price REAL NOT NULL DEFAULT 0,
            stock_quantity INTEGER NOT NULL DEFAULT 0,
            minimum_stock INTEGER NOT NULL DEFAULT 5,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create the sales table.
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_number TEXT NOT NULL UNIQUE,
            total_amount REAL NOT NULL DEFAULT 0,
            sold_by INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (sold_by) REFERENCES users(id)
        )
    """)

    ensure_inventory_movement_table(connection)
    ensure_sales_schema(connection)
    ensure_admin_schema(connection)

    # Save the database changes.
    connection.commit()

    # Close the cursor and connection after use.
    cursor.close()
    connection.close()

    print("Users table created successfully!")


# Run the setup function when this file is executed directly.
if __name__ == "__main__":
    create_tables()