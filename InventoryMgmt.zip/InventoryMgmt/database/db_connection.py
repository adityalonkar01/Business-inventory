# Import sqlite3 to work with SQLite databases.
import sqlite3

# Import Path to construct file paths safely.
from pathlib import Path


# Find the project's root directory.
# This file is inside the "database" folder,
# so its parent directory is the project root.
PROJECT_DIR = Path(__file__).resolve().parent.parent


# Define where our database file will be stored.
# SQLite will create this file when we connect to it
# if the file does not already exist.
DATABASE_PATH = PROJECT_DIR / "database" / "inventory.db"


def get_connection():
    """
    Create and return a connection to our SQLite database.

    We will call this function whenever another part
    of our application needs to access the database.
    """

    # Connect to the database file.
    # If the file doesn't exist, SQLite creates it.
    connection = sqlite3.connect(DATABASE_PATH)

    # Return the connection so other functions
    # can execute SQL queries.
    return connection