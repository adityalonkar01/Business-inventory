def ensure_sales_schema(connection):
    """Apply additive sales schema changes without replacing existing records."""

    connection.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_number TEXT NOT NULL UNIQUE,
            subtotal REAL NOT NULL DEFAULT 0,
            gst_percent REAL NOT NULL DEFAULT 0,
            gst_amount REAL NOT NULL DEFAULT 0,
            discount_percent REAL NOT NULL DEFAULT 0,
            discount_amount REAL NOT NULL DEFAULT 0,
            total_amount REAL NOT NULL DEFAULT 0,
            sold_by INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sold_by) REFERENCES users(id)
        )
    """)

    existing_columns = {
        row[1] for row in connection.execute("PRAGMA table_info(sales)")
    }
    for column_name in (
        "subtotal",
        "gst_percent",
        "gst_amount",
        "discount_percent",
        "discount_amount",
        "business_name",
        "business_address",
        "business_phone",
        "business_email",
        "currency_symbol"
    ):
        if column_name not in existing_columns:
            definition = (
                "TEXT NOT NULL DEFAULT '₹'"
                if column_name == "currency_symbol"
                else "TEXT NOT NULL DEFAULT ''"
                if column_name.startswith("business_")
                else "REAL NOT NULL DEFAULT 0"
            )
            connection.execute(
                f"ALTER TABLE sales ADD COLUMN {column_name} {definition}"
            )

    connection.execute("""
        CREATE TABLE IF NOT EXISTS sale_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            sku TEXT NOT NULL,
            quantity INTEGER NOT NULL CHECK (quantity > 0),
            unit_price REAL NOT NULL CHECK (unit_price >= 0),
            discount_amount REAL NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
            tax_rate REAL CHECK (tax_rate >= 0 AND tax_rate <= 100),
            tax_amount REAL CHECK (tax_amount >= 0),
            tax_rate_recorded INTEGER NOT NULL DEFAULT 0
                CHECK (tax_rate_recorded IN (0, 1)),
            line_total REAL NOT NULL CHECK (line_total >= 0),
            FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
        )
    """)
    existing_item_columns = {
        row[1] for row in connection.execute("PRAGMA table_info(sale_items)")
    }
    for column_name, definition in (
        ("discount_amount", "REAL NOT NULL DEFAULT 0"),
        ("tax_rate", "REAL"),
        ("tax_amount", "REAL"),
        ("tax_rate_recorded", "INTEGER NOT NULL DEFAULT 0")
    ):
        if column_name not in existing_item_columns:
            connection.execute(
                f"ALTER TABLE sale_items ADD COLUMN {column_name} {definition}"
            )
    connection.execute("""
        CREATE INDEX IF NOT EXISTS idx_sales_created
        ON sales (created_at DESC, id DESC)
    """)
    connection.execute("""
        CREATE INDEX IF NOT EXISTS idx_sale_items_sale
        ON sale_items (sale_id, id)
    """)
