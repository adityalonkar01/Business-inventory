def ensure_admin_schema(connection):
    """Apply additive schema changes for administrative modules."""

    connection.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    connection.execute("""
        INSERT OR IGNORE INTO categories (name)
        SELECT DISTINCT TRIM(category)
        FROM products
        WHERE TRIM(category) <> ''
    """)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS suppliers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            contact_name TEXT NOT NULL DEFAULT '',
            phone TEXT NOT NULL DEFAULT '',
            email TEXT NOT NULL DEFAULT '',
            address TEXT NOT NULL DEFAULT '',
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            purchase_ref TEXT NOT NULL UNIQUE,
            supplier_id INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'draft'
                CHECK (status IN ('draft', 'received')),
            total_amount REAL NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
            notes TEXT NOT NULL DEFAULT '',
            created_by INTEGER NOT NULL,
            received_by INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            received_at TEXT,
            FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE RESTRICT,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
            FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE RESTRICT
        )
    """)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS purchase_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            purchase_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            sku TEXT NOT NULL,
            quantity INTEGER NOT NULL CHECK (quantity > 0),
            unit_cost REAL NOT NULL CHECK (unit_cost >= 0),
            line_total REAL NOT NULL CHECK (line_total >= 0),
            FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
        )
    """)
    connection.execute("""
        CREATE INDEX IF NOT EXISTS idx_purchases_created
        ON purchases (created_at DESC, id DESC)
    """)
    connection.execute("""
        CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase
        ON purchase_items (purchase_id, id)
    """)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS app_settings (
            setting_key TEXT PRIMARY KEY,
            setting_value TEXT NOT NULL
        )
    """)
    defaults = {
        "business_name": "",
        "business_address": "",
        "business_phone": "",
        "business_email": "",
        "currency_symbol": "₹",
        "default_gst_percent": "0",
        "invoice_prefix": "INV-",
        "minimum_stock_default": "5",
    }
    connection.executemany(
        "INSERT OR IGNORE INTO app_settings (setting_key, setting_value) VALUES (?, ?)",
        defaults.items()
    )
