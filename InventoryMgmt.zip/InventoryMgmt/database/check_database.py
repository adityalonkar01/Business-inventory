# Import our database connection function.
from db_connection import get_connection


# Connect to the SQLite database.
connection = get_connection()

# Create a cursor to execute SQL commands.
cursor = connection.cursor()

# Ask SQLite to list all tables in our database.
cursor.execute("""
    SELECT name
    FROM sqlite_master
    WHERE type = 'table'
""")

# Retrieve all table names returned by the query.
tables = cursor.fetchall()

# Display the results.
print("Tables in our database:")

for table in tables:
    print(table[0])

# Close the cursor and database connection.
cursor.close()
connection.close()