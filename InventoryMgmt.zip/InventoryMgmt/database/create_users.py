# Import SQLite connection function from our existing file.
from db_connection import get_connection

# Import hashlib for password hashing.
import hashlib

# Import secrets for generating a random salt.
import secrets

# Import getpass to enter passwords without displaying them.
from getpass import getpass


def hash_password(password, salt):
    """
    Convert a password into a secure hash.

    The salt is a random value added to the password
    before hashing, making password hashes harder to attack.
    """

    # Use PBKDF2 with SHA-256 to derive a password hash.
    password_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        600_000
    )

    # Return the salt and hash in a format we can store.
    return salt.hex() + "$" + password_hash.hex()


def create_user(username, role):
    """
    Create one user account and store it in SQLite.
    """

    # Ask the user to enter a password without displaying it.
    password = getpass(f"Enter password for {username}: ")

    # Ask for the password again to confirm it.
    confirm_password = getpass("Confirm password: ")

    # Make sure both password entries match.
    if password != confirm_password:
        print("Passwords do not match. Account not created.")
        return

    # Prevent an empty password.
    if not password:
        print("Password cannot be empty.")
        return

    # Generate a unique random salt for this password.
    salt = secrets.token_bytes(16)

    # Create the salted password hash.
    stored_password = hash_password(password, salt)

    # Connect to the database.
    connection = get_connection()

    try:
        # Insert the new user using a parameterized SQL query.
        # Parameterized queries help prevent SQL injection.
        connection.execute(
            """
            INSERT INTO users (username, password_hash, role)
            VALUES (?, ?, ?)
            """,
            (username, stored_password, role)
        )

        # Save the changes to the database.
        connection.commit()

        print(f"Account created successfully for: {username}")

    except Exception as error:
        # Display a useful message if account creation fails.
        print(f"Could not create account: {error}")

    finally:
        # Always close the database connection.
        connection.close()


def main():
    """
    Create the three accounts required by our application.
    """

    # Each account is associated with a specific role.
    users = [
        ("admin", "admin"),
        ("manager", "manager"),
        ("salesman", "salesperson")
    ]

    # Create each account one at a time.
    for username, role in users:

        # Ask SQLite whether this username already exists.
        connection = get_connection()

        try:
            result = connection.execute(
                "SELECT id FROM users WHERE username = ?",
                (username,)
            ).fetchone()
        finally:
            connection.close()

        # Avoid attempting to create duplicate usernames.
        if result:
            print(f"User '{username}' already exists. Skipping.")
            continue

        # Create the account if it doesn't already exist.
        print(f"\nCreating account: {username}")
        create_user(username, role)


# Run the program only when this file is executed directly.
if __name__ == "__main__":
    main()