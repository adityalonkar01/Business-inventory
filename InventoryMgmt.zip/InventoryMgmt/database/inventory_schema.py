def ensure_inventory_movement_table(connection):
    """Create the additive stock-history table when it is not present."""

    connection.execute("""
        CREATE TABLE IF NOT EXISTS inventory_movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            movement_type TEXT NOT NULL
                CHECK (movement_type IN ('receipt', 'adjustment_in', 'adjustment_out', 'sale')),
            quantity INTEGER NOT NULL CHECK (quantity > 0),
            previous_stock INTEGER NOT NULL CHECK (previous_stock >= 0),
            new_stock INTEGER NOT NULL CHECK (new_stock >= 0),
            notes TEXT NOT NULL DEFAULT '',
            performed_by INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (
                (movement_type IN ('receipt', 'adjustment_in')
                    AND new_stock = previous_stock + quantity)
                OR
                (movement_type IN ('adjustment_out', 'sale')
                    AND new_stock = previous_stock - quantity)
            ),
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
            FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE RESTRICT
        )
    """)

    table_sql = connection.execute("""
        SELECT sql
        FROM sqlite_master
        WHERE type = 'table' AND name = 'inventory_movements'
    """).fetchone()[0]

    if "'sale'" not in table_sql:
        connection.execute("""
            CREATE TABLE inventory_movements_migration (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                movement_type TEXT NOT NULL
                    CHECK (movement_type IN ('receipt', 'adjustment_in', 'adjustment_out', 'sale')),
                quantity INTEGER NOT NULL CHECK (quantity > 0),
                previous_stock INTEGER NOT NULL CHECK (previous_stock >= 0),
                new_stock INTEGER NOT NULL CHECK (new_stock >= 0),
                notes TEXT NOT NULL DEFAULT '',
                performed_by INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CHECK (
                    (movement_type IN ('receipt', 'adjustment_in')
                        AND new_stock = previous_stock + quantity)
                    OR
                    (movement_type IN ('adjustment_out', 'sale')
                        AND new_stock = previous_stock - quantity)
                ),
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
                FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE RESTRICT
            )
        """)
        connection.execute("""
            INSERT INTO inventory_movements_migration (
                id, product_id, movement_type, quantity, previous_stock,
                new_stock, notes, performed_by, created_at
            )
            SELECT
                id, product_id, movement_type, quantity, previous_stock,
                new_stock, notes, performed_by, created_at
            FROM inventory_movements
        """)
        connection.execute("DROP TABLE inventory_movements")
        connection.execute("""
            ALTER TABLE inventory_movements_migration
            RENAME TO inventory_movements
        """)

    connection.execute("""
        CREATE INDEX IF NOT EXISTS idx_inventory_movements_product_created
        ON inventory_movements (product_id, created_at DESC, id DESC)
    """)
